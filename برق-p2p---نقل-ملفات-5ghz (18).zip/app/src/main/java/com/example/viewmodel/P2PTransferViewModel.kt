package com.example.viewmodel

import android.Manifest
import android.app.Application
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DeviceMediaRepository
import com.example.data.InstalledAppsRepository
import com.example.model.AppScreen
import com.example.model.BluetoothPeerDevice
import com.example.model.BluetoothState
import com.example.model.ChunkSizeOption
import com.example.model.ConnectionApprovalStatus
import com.example.model.DeviceMediaItem
import com.example.model.DiscoveredPeerSession
import com.example.model.FileCategory
import com.example.model.FileTransferStatus
import com.example.model.FilesSubTab
import com.example.model.FolderBatchInfo
import com.example.model.FolderStatsStatus
import com.example.model.HotspotNetworkStatus
import com.example.model.IncomingConnectionRequest
import com.example.model.InstalledAppItem
import com.example.model.MediaViewMode
import com.example.model.PersistedSafFolderItem
import com.example.model.ReceivedApkItem
import com.example.model.ReceiverConnectionPhase
import com.example.model.SafUriStatus
import com.example.model.SafValidationResult
import com.example.model.SenderSessionPhase
import com.example.model.SortOption
import com.example.model.StorageFolderItem
import com.example.model.TransferDirection
import com.example.model.TransferFileItem
import com.example.model.TransferHistoryRecord
import com.example.model.TransportMode
import com.example.model.computeTotalChunksForSize
import com.example.network.BluetoothP2PManager
import com.example.network.P2PChunkServer
import com.example.service.BarqTransferForegroundService
import com.example.util.Sha256Util
import android.webkit.MimeTypeMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max
import kotlin.random.Random

data class InspectedItemDetails(
    val title: String,
    val pathOrUri: String,
    val sizeBytes: Long,
    val categoryLabel: String,
    val lastModifiedMillis: Long,
    val isDirectory: Boolean = false,
    val extraDetails: String = ""
)

data class P2PUiState(
    val currentScreen: AppScreen = AppScreen.HOME,
    val networkStatus: HotspotNetworkStatus = HotspotNetworkStatus(),
    val connectionCode: String = "BRQ-4301",
    val sessionId: String = "SES-1001",
    val sessionExpiresAtMillis: Long = Long.MAX_VALUE,
    val sessionRemainingSeconds: Int = 600,
    val senderSessionPhase: SenderSessionPhase = SenderSessionPhase.IDLE,
    val incomingConnectionRequest: IncomingConnectionRequest? = null,
    val requireReceiverApproval: Boolean = true,
    val enteredReceiveCode: String = "",
    val isSenderReady: Boolean = false,
    val isPreparingHashes: Boolean = false,
    val remoteHostIp: String = "",
    val remoteHostPort: Int = 8989,
    val remoteSessionCode: String = "",
    val remoteSessionId: String = "",
    val remoteSenderDeviceName: String = "",
    val remoteRequiresApproval: Boolean = true,
    val remoteAuthToken: String = "",
    val receiverConnectionPhase: ReceiverConnectionPhase = ReceiverConnectionPhase.IDLE,
    val receiverDiagnosticError: String? = null,
    val remoteChunkSizeBytes: Int = ChunkSizeOption.AUTO_MAX.bytes,
    val pendingIncomingFiles: List<TransferFileItem> = emptyList(),
    val showReceiveConfirmationDialog: Boolean = false,
    val isConnectingToSender: Boolean = false,
    val discoveredPeers: List<DiscoveredPeerSession> = emptyList(),
    val selectedChunkSize: ChunkSizeOption = ChunkSizeOption.AUTO_MAX,
    val transferDirection: TransferDirection = TransferDirection.SENDING,
    val files: List<TransferFileItem> = emptyList(),
    val folderBatches: List<FolderBatchInfo> = emptyList(),
    val isScanningFolder: Boolean = false,
    val isTransferRunning: Boolean = false,
    val isPaused: Boolean = false,
    val isBackgroundServiceActive: Boolean = false,
    val liveOverallSpeedBytesPerSec: Double = 0.0,
    val averageSpeedBytesPerSec: Double = 0.0,
    val peakSpeedBytesPerSec: Double = 0.0,
    val statusBannerMessage: String? = null,
    val showHotspotGuideSheet: Boolean = false,
    val showPermissionRationaleDialog: Boolean = false,
    val showAndroidStoragePolicySheet: Boolean = false,
    val connectedPeerLabel: String = "بانتظار اتصال الجهاز الآخر...",
    // Installed Apps & Received APKs State
    val installedApps: List<InstalledAppItem> = emptyList(),
    val isLoadingApps: Boolean = false,
    val includeSystemApps: Boolean = false,
    val appsSearchQuery: String = "",
    val selectedAppPackages: Set<String> = emptySet(),
    val receivedApks: List<ReceivedApkItem> = emptyList(),
    val isLoadingReceivedApks: Boolean = false,
    // Device Media & File Manager State
    val hasMediaPermissions: Boolean = false,
    val hasImagePermission: Boolean = false,
    val hasVideoPermission: Boolean = false,
    val hasAudioPermission: Boolean = false,
    val hasPartialMediaPermission: Boolean = false,
    val permissionDeniedMessage: String? = null,
    val isLoadingMedia: Boolean = false,
    val isLoadingImages: Boolean = false,
    val isLoadingVideos: Boolean = false,
    val isLoadingAudio: Boolean = false,
    val hasCompletedInitialImageScan: Boolean = false,
    val hasCompletedInitialVideoScan: Boolean = false,
    val hasCompletedInitialAudioScan: Boolean = false,
    val videoScanErrorMessage: String? = null,
    val mediaViewMode: MediaViewMode = MediaViewMode.LIST,
    val mediaVisiblePageLimit: Int = 120,
    val isLoadingMoreMedia: Boolean = false,
    val deviceImages: List<DeviceMediaItem> = emptyList(),
    val deviceVideos: List<DeviceMediaItem> = emptyList(),
    val deviceAudio: List<DeviceMediaItem> = emptyList(),
    val deviceGeneralFiles: List<DeviceMediaItem> = emptyList(),
    val storageFolders: List<StorageFolderItem> = emptyList(),
    val persistedSafFolders: List<PersistedSafFolderItem> = emptyList(),
    val revokedSafFolders: List<PersistedSafFolderItem> = emptyList(),
    val activeSafTreeUri: Uri? = null,
    val activeSafDocumentId: String? = null,
    val activeSafPathLabel: String? = null,
    val safBrowsingFolders: List<StorageFolderItem> = emptyList(),
    val safBrowsingFiles: List<DeviceMediaItem> = emptyList(),
    val safFolderFiles: List<DeviceMediaItem> = emptyList(),
    val activeFilesSubTab: FilesSubTab = FilesSubTab.ALL,
    val browsingFolderFilter: String? = null,
    val currentBrowsingFolders: List<StorageFolderItem> = emptyList(),
    val currentBrowsingFiles: List<DeviceMediaItem> = emptyList(),
    val isBrowsingDirectoryLoading: Boolean = false,
    val browsingDirectoryError: String? = null,
    val mediaSearchQuery: String = "",
    val sortOption: SortOption = SortOption.DATE_DESC,
    val selectedFolderPaths: Set<String> = emptySet(),
    val selectedMediaIds: Set<String> = emptySet(),
    val inspectedItemDetails: InspectedItemDetails? = null,
    // Bluetooth & Transport Mode State
    val transportMode: TransportMode = TransportMode.AUTO_SMART,
    val bluetoothState: BluetoothState = BluetoothState.READY,
    val bluetoothPeers: List<BluetoothPeerDevice> = emptyList(),
    val connectedBluetoothAddress: String = "",
    val bluetoothStatusMessage: String? = null,
    // Transfer History & Direct Media Preview State
    val transferHistory: List<TransferHistoryRecord> = emptyList(),
    val previewingHistoryRecord: TransferHistoryRecord? = null
) {
    private val activeOrCompletedFiles: List<TransferFileItem>
        get() = files.filterNot { it.status == FileTransferStatus.CANCELLED }.ifEmpty { files }

    val totalBytes: Long
        get() = activeOrCompletedFiles.sumOf { it.sizeBytes }

    val transferredBytes: Long
        get() = activeOrCompletedFiles.sumOf { it.transferredBytes }

    val remainingBytes: Long
        get() = (totalBytes - transferredBytes).coerceAtLeast(0L)

    val estimatedRemainingSeconds: Long
        get() = if (liveOverallSpeedBytesPerSec > 1024.0 && remainingBytes > 0L) {
            (remainingBytes.toDouble() / liveOverallSpeedBytesPerSec).toLong().coerceAtLeast(1L)
        } else 0L

    val formattedEtaLabel: String
        get() {
            if (!isTransferRunning || remainingBytes <= 0L) return "مكتمل"
            val secs = estimatedRemainingSeconds
            if (secs <= 0L) return "جاري الحساب..."
            val hours = secs / 3600
            val mins = (secs % 3600) / 60
            val remSecs = secs % 60
            return when {
                hours > 0 -> String.format(Locale.US, "%d س و %d د", hours, mins)
                mins > 0 -> String.format(Locale.US, "%d د و %d ث", mins, remSecs)
                else -> String.format(Locale.US, "%d ثانية", remSecs)
            }
        }

    val formattedSessionRemainingTime: String
        get() {
            val mins = (sessionRemainingSeconds / 60).coerceAtLeast(0)
            val secs = (sessionRemainingSeconds % 60).coerceAtLeast(0)
            return String.format(Locale.US, "%02d:%02d", mins, secs)
        }

    val overallProgressFraction: Float
        get() = when {
            activeOrCompletedFiles.isNotEmpty() && activeOrCompletedFiles.all { it.status == FileTransferStatus.COMPLETED } -> 1f
            totalBytes <= 0L -> if (totalChunksCount > 0) (completedChunksCount.toDouble() / totalChunksCount.toDouble()).toFloat().coerceIn(0f, 0.999f) else 0f
            else -> (transferredBytes.toDouble() / totalBytes.toDouble()).toFloat().coerceIn(0f, 0.999f)
        }

    val totalChunksCount: Int
        get() = activeOrCompletedFiles.sumOf { it.totalChunks.toLong() }.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()

    val completedChunksCount: Int
        get() = activeOrCompletedFiles.sumOf { it.completedChunks.toLong() }.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()

    val totalFilesOnlyCount: Int
        get() = activeOrCompletedFiles.count { !it.isDirectory }

    val completedFilesOnlyCount: Int
        get() = files.count { !it.isDirectory && it.status == FileTransferStatus.COMPLETED }

    val remainingFilesOnlyCount: Int
        get() = files.count { !it.isDirectory && it.status != FileTransferStatus.COMPLETED && it.status != FileTransferStatus.CANCELLED }

    val failedFilesOnlyCount: Int
        get() = files.count { !it.isDirectory && (it.status == FileTransferStatus.FAILED || it.status == FileTransferStatus.CANCELLED) }

    val activeTransferringFile: TransferFileItem?
        get() = files.firstOrNull {
            !it.isDirectory && (
                it.status == FileTransferStatus.TRANSFERRING ||
                    it.status == FileTransferStatus.RETRYING ||
                    it.status == FileTransferStatus.VERIFYING
                )
        }
            ?: files.firstOrNull { !it.isDirectory && it.status == FileTransferStatus.PAUSED }
            ?: files.firstOrNull { !it.isDirectory && it.status.isWaitingOrQueued }

    val totalEmptyDirsCount: Int
        get() = files.count { it.isDirectory }

    val standaloneFilesInQueue: List<TransferFileItem>
        get() = files.filter { it.folderBatchId.isBlank() }

    val totalSelectedUnitsInSendQueue: Int
        get() = folderBatches.size + standaloneFilesInQueue.size

    val activeFolderNames: List<String>
        get() = files.mapNotNull { it.rootFolderName.takeIf { name -> name.isNotBlank() } }.distinct()

    val pendingTotalBytes: Long
        get() = pendingIncomingFiles.sumOf { it.sizeBytes }

    val pendingFolderNames: List<String>
        get() = pendingIncomingFiles.mapNotNull { it.rootFolderName.takeIf { name -> name.isNotBlank() } }.distinct()

    val liveOverallSpeedMbps: Double
        get() = liveOverallSpeedBytesPerSec / (1024.0 * 1024.0)

    val averageSpeedMbps: Double
        get() = averageSpeedBytesPerSec / (1024.0 * 1024.0)

    val peakSpeedMbps: Double
        get() = peakSpeedBytesPerSec / (1024.0 * 1024.0)

    val qrPayload: String
        get() = "BARQP2P|$connectionCode|${networkStatus.localIp}|${networkStatus.port}|$sessionId|$sessionExpiresAtMillis"

    val selectedFoldersCount: Int
        get() = selectedFolderPaths.size

    val selectedFilesAndAppsCount: Int
        get() = selectedAppPackages.size + selectedMediaIds.size

    val totalSelectedCountInManager: Int
        get() = selectedFolderPaths.size + selectedAppPackages.size + selectedMediaIds.size

    val totalSelectedBytesInManager: Long
        get() {
            if (selectedFolderPaths.isEmpty() && selectedAppPackages.isEmpty() && selectedMediaIds.isEmpty()) {
                return 0L
            }
            var total = 0L
            if (selectedFolderPaths.isNotEmpty()) {
                val seenPaths = HashSet<String>(selectedFolderPaths.size * 2)
                for (f in currentBrowsingFolders) {
                    if (f.path in selectedFolderPaths && seenPaths.add(f.path)) total += f.totalBytes
                }
                for (f in storageFolders) {
                    if (f.path in selectedFolderPaths && seenPaths.add(f.path)) total += f.totalBytes
                }
                for (f in safBrowsingFolders) {
                    if (f.path in selectedFolderPaths && seenPaths.add(f.path)) total += f.totalBytes
                }
            }
            if (selectedAppPackages.isNotEmpty()) {
                for (app in installedApps) {
                    if (app.packageName in selectedAppPackages) total += app.sizeBytes
                }
            }
            if (selectedMediaIds.isNotEmpty()) {
                val seenIds = HashSet<String>(selectedMediaIds.size * 2)
                val sources = arrayOf(
                    currentBrowsingFiles,
                    deviceGeneralFiles,
                    deviceImages,
                    deviceVideos,
                    deviceAudio,
                    safFolderFiles,
                    safBrowsingFiles
                )
                for (list in sources) {
                    for (item in list) {
                        if (item.id in selectedMediaIds && seenIds.add(item.id)) {
                            total += item.sizeBytes
                        }
                    }
                }
            }
            return total
        }
}

class P2PTransferViewModel(application: Application) : AndroidViewModel(application) {

    // Process-level transfer engine scope so screen-off or Activity recreation never aborts an active transfer
    private val transferEngineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _uiState = MutableStateFlow(
        if (retainedSessionAppIdentity === application && retainedActiveState != null &&
            (retainedActiveState!!.isTransferRunning || retainedActiveState!!.isSenderReady)
        ) {
            retainedActiveState!!
        } else {
            P2PUiState()
        }
    )
    val uiState: StateFlow<P2PUiState> = _uiState.asStateFlow()

    private var chunkServer: P2PChunkServer? = if (retainedSessionAppIdentity === application) retainedChunkServer else null
    private var bluetoothManager: BluetoothP2PManager? = null
    private var activeTransferJob: Job? = if (retainedSessionAppIdentity === application) retainedTransferJob else null
    private var sessionTimerJob: Job? = null
    private var approvalPollingJob: Job? = null
    private var mediaLoadJob: Job? = null
    private var directoryBrowseJob: Job? = null
    private var folderStatsCalculationJob: Job? = null
    private val directoryBrowseGeneration = AtomicLong(0L)
    private val directoryContentsCache = ConcurrentHashMap<String, Pair<List<StorageFolderItem>, List<DeviceMediaItem>>>()
    private val receiverClientId: String = "RCV-${UUID.randomUUID().toString().take(8).uppercase(Locale.US)}"
    private val senderFileStartNanoMap = ConcurrentHashMap<String, Long>()
    private val senderFileServedBytesMap = ConcurrentHashMap<String, Long>()
    private val cancelledFileIds = ConcurrentHashMap.newKeySet<String>()
    private val pausedFileIds = ConcurrentHashMap.newKeySet<String>()
    private val transferControlLock = Any()
    @Volatile
    private var lastStartSendSessionElapsedMs: Long = -10_000L
    @Volatile
    private var lastStartReceiveSessionElapsedMs: Long = -10_000L
    private var senderSessionStartNano: Long = 0L
    private val senderSessionServedBytes = AtomicLong(0L)
    private var lastSenderUiUpdateNano: Long = 0L
    private val safNavigationStack = ArrayDeque<Pair<String?, String>>()

    init {
        retainedSessionAppIdentity = application
        BarqTransferForegroundService.onPauseResumeRequested = { togglePauseResume() }
        BarqTransferForegroundService.onCancelRequested = { cancelActiveTransfer() }
        initBluetoothManager()
        checkMediaPermissionsStatus()
        loadPersistedHistory()
        if (chunkServer == null) {
            startLocalP2PServerAndInspectNetwork()
        }
        loadInstalledApps()
        loadAllDeviceMediaAndFiles()
        loadReceivedApks()
    }

    private fun initBluetoothManager() {
        val ctx = getApplication<Application>().applicationContext
        val mgr = BluetoothP2PManager(
            context = ctx,
            scope = viewModelScope,
            onStateChanged = { state, message ->
                _uiState.update { s ->
                    s.copy(
                        bluetoothState = state,
                        bluetoothStatusMessage = message ?: s.bluetoothStatusMessage,
                        statusBannerMessage = message ?: s.statusBannerMessage
                    )
                }
            },
            onDevicesUpdated = { peers ->
                _uiState.update { it.copy(bluetoothPeers = peers) }
            },
            onHandshakeReceivedFromPeer = { hostIp, port, sessionCode, sessionId, peerName, peerBtAddress ->
                _uiState.update { s ->
                    s.copy(
                        connectedBluetoothAddress = peerBtAddress,
                        remoteSenderDeviceName = peerName,
                        enteredReceiveCode = sessionCode.ifBlank { s.enteredReceiveCode },
                        bluetoothStatusMessage = "تم استلام جلسة الإرسال من «$peerName» عبر البلوتوث ($sessionCode)"
                    )
                }
                if (_uiState.value.transportMode != TransportMode.BLUETOOTH_DIRECT &&
                    sessionCode.isNotBlank() && hostIp.isNotBlank()
                ) {
                    connectAndReceiveFromInput("BARQP2P|$sessionCode|$hostIp|$port|$sessionId")
                }
            }
        )
        bluetoothManager = mgr
        _uiState.update { it.copy(bluetoothState = mgr.inspectBluetoothState()) }
        mgr.refreshPairedAndDiscoveredDevices()
    }

    fun setTransportMode(mode: TransportMode) {
        _uiState.update {
            it.copy(
                transportMode = mode,
                statusBannerMessage = "وضع النقل النشط: ${mode.arabicTitle} — ${mode.arabicSubtitle}"
            )
        }
    }

    fun refreshBluetoothDevices() {
        bluetoothManager?.refreshPairedAndDiscoveredDevices()
    }

    fun startBluetoothDiscovery() {
        bluetoothManager?.startDeviceDiscovery()
    }

    fun pairWithBluetoothDevice(peer: BluetoothPeerDevice) {
        bluetoothManager?.pairWithDevice(peer)
    }

    fun openBluetoothSettings() {
        bluetoothManager?.openSystemBluetoothSettings()
    }

    fun onBluetoothPermissionsResult(results: Map<String, Boolean>) {
        val granted = results.values.any { it } ||
            BluetoothP2PManager.hasBluetoothPermissions(getApplication<Application>().applicationContext)
        if (granted) {
            bluetoothManager?.refreshPairedAndDiscoveredDevices()
            bluetoothManager?.startDeviceDiscovery()
        } else {
            _uiState.update {
                it.copy(
                    bluetoothState = BluetoothState.PERMISSION_REQUIRED,
                    bluetoothStatusMessage = "يلزم منح صلاحية البلوتوث لاكتشاف الأجهزة القريبة والاقتران السريع"
                )
            }
        }
    }

    fun connectToBluetoothPeer(peer: BluetoothPeerDevice) {
        _uiState.update {
            it.copy(
                connectedBluetoothAddress = peer.address,
                isConnectingToSender = true,
                statusBannerMessage = "جاري الاتصال عبر البلوتوث بـ «${peer.displayName}» لتبادل الجلسة..."
            )
        }
        bluetoothManager?.connectToPeerForHandshake(
            peer = peer,
            onManifestAlsoFetched = { btFiles, senderName ->
                if (_uiState.value.transportMode == TransportMode.BLUETOOTH_DIRECT) {
                    _uiState.update { s ->
                        s.copy(
                            isConnectingToSender = false,
                            remoteSenderDeviceName = senderName,
                            remoteRequiresApproval = false,
                            pendingIncomingFiles = btFiles,
                            showReceiveConfirmationDialog = true,
                            receiverConnectionPhase = ReceiverConnectionPhase.MANIFEST_PREVIEW,
                            currentScreen = AppScreen.RECEIVE,
                            statusBannerMessage = "تم جلب قائمة الملفات (${btFiles.size}) مباشرة عبر البلوتوث من «$senderName»"
                        )
                    }
                }
            }
        )
    }

    fun checkMediaPermissionsStatus(): Boolean {
        val ctx = getApplication<Application>().applicationContext
        val imgGranted: Boolean
        val vidGranted: Boolean
        val audGranted: Boolean
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            imgGranted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
            vidGranted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
            audGranted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
        } else {
            val extGranted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            imgGranted = extGranted
            vidGranted = extGranted
            audGranted = extGranted
        }
        val fullGranted = imgGranted || vidGranted || audGranted
        val partialGranted = if (Build.VERSION.SDK_INT >= 34) {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
        } else false
        val anyGranted = fullGranted || partialGranted
        _uiState.update {
            it.copy(
                hasMediaPermissions = anyGranted,
                hasImagePermission = imgGranted || partialGranted,
                hasVideoPermission = vidGranted || partialGranted,
                hasAudioPermission = audGranted,
                hasPartialMediaPermission = partialGranted && !fullGranted
            )
        }
        return anyGranted
    }

    /**
     * Restores persisted SAF permissions from ContentResolver and SharedPreferences ("barq_saf_prefs"),
     * verifying each URI's validity and preserving user choices without overwriting them.
     */
    fun restorePersistedSafFolders(): List<PersistedSafFolderItem> {
        val ctx = getApplication<Application>().applicationContext
        val allSaved = DeviceMediaRepository.loadAllSavedSafFoldersWithStatus(ctx)
        val valid = allSaved.filter { it.isValid }
        val revoked = allSaved.filter { !it.isValid }
        val warningMsg = revoked.firstOrNull()?.statusMessage
        _uiState.update { state ->
            state.copy(
                persistedSafFolders = valid,
                revokedSafFolders = revoked,
                statusBannerMessage = if (warningMsg != null && state.statusBannerMessage == null) {
                    warningMsg
                } else state.statusBannerMessage
            )
        }
        return valid
    }

    /**
     * Returns true ONLY if the user needs to pick a SAF folder (i.e. no valid persisted permission exists
     * for [targetUri] or no valid SAF folder is saved at all). Prevents repeated SAF prompts.
     */
    fun shouldRequestSafFolderSelection(targetUri: Uri? = null): Boolean {
        val ctx = getApplication<Application>().applicationContext
        if (targetUri != null) {
            return !DeviceMediaRepository.hasValidPersistedSafPermission(ctx, targetUri)
        }
        val validFolders = DeviceMediaRepository.loadPersistedSafFolders(ctx)
        if (validFolders.isNotEmpty()) {
            _uiState.update { it.copy(persistedSafFolders = validFolders) }
            return false
        }
        return true
    }

    fun setMediaViewMode(mode: MediaViewMode) {
        _uiState.update { it.copy(mediaViewMode = mode) }
    }

    fun toggleMediaViewMode() {
        _uiState.update {
            val next = if (it.mediaViewMode == MediaViewMode.LIST) MediaViewMode.GRID else MediaViewMode.LIST
            it.copy(mediaViewMode = next)
        }
    }

    /**
     * Loads the next paginated batch of media items when scrolling near the end of the list/grid
     * or tapping the Load More button.
     */
    fun loadNextMediaBatch(category: FileCategory = FileCategory.IMAGE) {
        val currentState = _uiState.value
        val nextLimit = currentState.mediaVisiblePageLimit + 120
        _uiState.update { it.copy(mediaVisiblePageLimit = nextLimit) }

        val ctx = getApplication<Application>().applicationContext
        when (category) {
            FileCategory.IMAGE -> {
                val loadedCount = currentState.deviceImages.size
                if (loadedCount >= 250 && nextLimit >= loadedCount - 60 && !currentState.isLoadingMoreMedia) {
                    _uiState.update { it.copy(isLoadingMoreMedia = true) }
                    viewModelScope.launch(Dispatchers.IO) {
                        val more = DeviceMediaRepository.loadImages(
                            context = ctx,
                            maxItems = 500,
                            offset = loadedCount
                        )
                        _uiState.update { s ->
                            val merged = if (more.isNotEmpty()) {
                                (s.deviceImages + more).distinctBy { it.id }
                            } else s.deviceImages
                            s.copy(
                                deviceImages = merged,
                                isLoadingMoreMedia = false
                            )
                        }
                    }
                }
            }
            FileCategory.VIDEO -> {
                val loadedCount = currentState.deviceVideos.size
                if (loadedCount >= 150 && nextLimit >= loadedCount - 60 && !currentState.isLoadingMoreMedia) {
                    _uiState.update { it.copy(isLoadingMoreMedia = true) }
                    viewModelScope.launch(Dispatchers.IO) {
                        val more = DeviceMediaRepository.loadVideos(
                            context = ctx,
                            maxItems = 400,
                            offset = loadedCount
                        )
                        _uiState.update { s ->
                            val merged = if (more.isNotEmpty()) {
                                (s.deviceVideos + more).distinctBy { it.id }
                            } else s.deviceVideos
                            s.copy(
                                deviceVideos = merged,
                                isLoadingMoreMedia = false
                            )
                        }
                    }
                }
            }
            else -> Unit
        }
    }

    /**
     * Called automatically when MainActivity resumes (e.g. after returning from Android System Settings,
     * Permission Dialogs, or the System Package Installer) to refresh permissions, media, files, and APKs.
     */
    fun onAppResumed() {
        val hadPermBefore = _uiState.value.hasMediaPermissions
        val hadVidPermBefore = _uiState.value.hasVideoPermission
        val hasPermNow = checkMediaPermissionsStatus()
        val hasVidPermNow = _uiState.value.hasVideoPermission
        restorePersistedSafFolders()
        if ((!hadPermBefore && hasPermNow) ||
            (!hadVidPermBefore && hasVidPermNow) ||
            (hasPermNow && _uiState.value.deviceImages.isEmpty() && _uiState.value.deviceVideos.isEmpty())
        ) {
            loadAllDeviceMediaAndFiles()
        }
        loadReceivedApks()
    }

    fun togglePermissionRationaleDialog(show: Boolean) {
        _uiState.update { it.copy(showPermissionRationaleDialog = show) }
    }

    fun toggleAndroidStoragePolicySheet(show: Boolean) {
        _uiState.update { it.copy(showAndroidStoragePolicySheet = show) }
    }

    fun onMediaPermissionsResult(results: Map<String, Boolean>) {
        val anyGranted = results.values.any { it } || checkMediaPermissionsStatus()
        _uiState.update {
            it.copy(
                hasMediaPermissions = anyGranted,
                showPermissionRationaleDialog = false,
                permissionDeniedMessage = if (!anyGranted) {
                    "تم رفض صلاحية قراءة الوسائط. لا يزال بإمكانك اختيار أي ملف أو إرسال مجلد كامل عبر متصفح ملفات النظام الآمن (SAF)."
                } else null
            )
        }
        loadAllDeviceMediaAndFiles()
    }

    fun inspectMediaItem(item: DeviceMediaItem) {
        val pathOrUri = item.localFile?.absolutePath
            ?: item.relativePathInStorage.takeIf { it.isNotBlank() }
            ?: item.uri?.toString()
            ?: item.name
        val extra = buildString {
            append("الفئة: ${item.category.arabicLabel}")
            if (!item.mimeType.isNullOrBlank()) append(" • النوع: ${item.mimeType}")
            if (item.bucketOrFolderName.isNotBlank()) append("\nالمجلد الحاوي: ${item.bucketOrFolderName}")
            if (item.durationMillis > 0L) append("\nالمدة: ${item.durationMillis / 1000} ثانية")
        }
        _uiState.update {
            it.copy(
                inspectedItemDetails = InspectedItemDetails(
                    title = item.name,
                    pathOrUri = pathOrUri,
                    sizeBytes = item.sizeBytes,
                    categoryLabel = item.category.arabicLabel,
                    lastModifiedMillis = item.dateModifiedMillis,
                    isDirectory = false,
                    extraDetails = extra
                )
            )
        }
    }

    fun inspectFolderItem(folder: StorageFolderItem) {
        fun buildFolderExtraText(f: StorageFolderItem, isCalculating: Boolean): String = buildString {
            val filePrefix = if (f.statsStatus == FolderStatsStatus.APPROXIMATE_CAPPED) "+${f.fileCount}" else "${f.fileCount}"
            append("عدد الملفات: $filePrefix ملف")
            append(" • المجلدات الفرعية: ${f.subfolderCount}")
            if (f.emptySubfolderCount > 0) {
                append(" (منها ${f.emptySubfolderCount} مجلد فارغ)")
            }
            if (f.statsStatus == FolderStatsStatus.APPROXIMATE_CAPPED) {
                append(" • (حساب تقريبي للمجلدات الضخمة)")
            }
            if (isCalculating) {
                append("\n⏳ جارٍ الحساب في الخلفية...")
            }
            if (f.isProtectedSystemFolder && !f.protectionReason.isNullOrBlank()) {
                append("\n🔒 ${f.protectionReason}")
            }
            if (f.safTreeUri != null) {
                append("\nالمصدر: إطار وصول التخزين الآمن (SAF)")
            }
        }

        val needsAsyncCalculation = !folder.isProtectedSystemFolder &&
            (folder.statsStatus == FolderStatsStatus.CALCULATING ||
                folder.statsStatus == FolderStatsStatus.NOT_CALCULATED ||
                (folder.fileCount == 0 && folder.totalBytes == 0L))

        _uiState.update {
            it.copy(
                inspectedItemDetails = InspectedItemDetails(
                    title = folder.name,
                    pathOrUri = folder.relativeDisplayPath.ifBlank { folder.path },
                    sizeBytes = folder.totalBytes,
                    categoryLabel = "مجلد كامل",
                    lastModifiedMillis = folder.lastModifiedMillis,
                    isDirectory = true,
                    extraDetails = buildFolderExtraText(folder, needsAsyncCalculation)
                )
            )
        }

        if (needsAsyncCalculation) {
            viewModelScope.launch(Dispatchers.IO) {
                val ctx = getApplication<Application>().applicationContext
                val updated = DeviceMediaRepository.computeFolderStatsLazy(
                    folder = folder,
                    context = ctx,
                    maxFilesCap = 5000,
                    isCancelled = { !isActive }
                )
                _uiState.update { state ->
                    val currentDetails = state.inspectedItemDetails
                    val updatedDetails = if (currentDetails != null && currentDetails.isDirectory && currentDetails.title == folder.name) {
                        currentDetails.copy(
                            sizeBytes = updated.totalBytes,
                            extraDetails = buildFolderExtraText(updated, false)
                        )
                    } else currentDetails
                    state.copy(
                        inspectedItemDetails = updatedDetails,
                        storageFolders = state.storageFolders.map { if (it.path == updated.path) updated else it },
                        currentBrowsingFolders = state.currentBrowsingFolders.map { if (it.path == updated.path) updated else it },
                        safBrowsingFolders = state.safBrowsingFolders.map { if (it.path == updated.path) updated else it }
                    )
                }
            }
        }
    }

    fun dismissInspectedItemDetails() {
        _uiState.update { it.copy(inspectedItemDetails = null) }
    }

    fun loadReceivedApks() {
        _uiState.update { it.copy(isLoadingReceivedApks = true) }
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            val downloadDir = resolveBarqSherDownloadsDir(ctx)
            val apks = DeviceMediaRepository.loadReceivedApkFiles(
                context = ctx,
                downloadDir = downloadDir,
                historyRecords = _uiState.value.transferHistory
            )
            _uiState.update {
                it.copy(
                    receivedApks = apks,
                    isLoadingReceivedApks = false
                )
            }
        }
    }

    /**
     * Verifies a received APK file and launches the official Android Package Installer requiring
     * explicit user confirmation. Never bypasses OS security protections.
     */
    fun installReceivedApk(context: Context, apkItem: ReceivedApkItem) {
        val file = apkItem.file
        if (!file.exists() || !file.canRead() || file.length() <= 0L) {
            _uiState.update {
                it.copy(statusBannerMessage = "تعذر تثبيت «${apkItem.fileName}»: الملف غير موجود أو حجمه 0 بايت.")
            }
            return
        }
        if (file.name.endsWith(".part", ignoreCase = true) || !apkItem.isValidApk) {
            _uiState.update {
                it.copy(statusBannerMessage = "لا يمكن تثبيت «${apkItem.fileName}»: ${apkItem.installStatusLabel}")
            }
            return
        }

        try {
            val apkUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(installIntent)
            _uiState.update {
                it.copy(
                    statusBannerMessage = "تم فتح مثبت نظام Android الرسمي لتثبيت «${apkItem.appName}» بموافقتك."
                )
            }
        } catch (anf: ActivityNotFoundException) {
            android.util.Log.e(LOG_TAG, "No package installer activity found: ${anf.message}")
            _uiState.update {
                it.copy(statusBannerMessage = "تعذر العثور على مثبت الحزم الرسمي على هذا الجهاز.")
            }
        } catch (se: SecurityException) {
            android.util.Log.e(LOG_TAG, "SecurityException launching APK installer: ${se.message}")
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val settingsIntent = Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${context.packageName}")
                    ).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(settingsIntent)
                    _uiState.update {
                        it.copy(statusBannerMessage = "يرجى السماح بتثبيت التطبيقات من هذا المصدر في إعدادات Android ثم المحاولة مرة أخرى.")
                    }
                }
            } catch (_: Exception) {
                _uiState.update {
                    it.copy(statusBannerMessage = "رفض النظام فتح المثبت؛ يرجى تفعيل إذن تثبيت التطبيقات من الإعدادات.")
                }
            }
        } catch (t: Throwable) {
            android.util.Log.e(LOG_TAG, "Error launching APK installer for ${file.absolutePath}: ${t.message}", t)
            _uiState.update {
                it.copy(statusBannerMessage = "تعذر بدء تثبيت التطبيق: ${t.localizedMessage ?: "خطأ في قراءة الحزمة"}")
            }
        }
    }

    private fun startLocalP2PServerAndInspectNetwork() {
        transferEngineScope.launch {
            val appContext = getApplication<Application>().applicationContext
            val server = P2PChunkServer(
                context = appContext,
                scope = transferEngineScope,
                sessionCodeProvider = { _uiState.value.connectionCode },
                sessionIdProvider = { _uiState.value.sessionId },
                sessionExpiresAtProvider = { _uiState.value.sessionExpiresAtMillis },
                isSenderReadyProvider = { _uiState.value.isSenderReady },
                requireReceiverApprovalProvider = { _uiState.value.requireReceiverApproval },
                chunkSizeProvider = { _uiState.value.selectedChunkSize },
                filesProvider = { _uiState.value.files },
                onChunkServed = { fileId, chunkIdx, bytesCount ->
                    onRemotePeerPulledChunk(fileId, chunkIdx, bytesCount)
                },
                onPeerDiscovered = { peerSession ->
                    _uiState.update { state ->
                        val updated = (listOf(peerSession) + state.discoveredPeers.filterNot {
                            it.sessionCode.equals(peerSession.sessionCode, ignoreCase = true)
                        }).take(8)
                        state.copy(discoveredPeers = updated)
                    }
                },
                onReceiverVerifiedFile = { fileId, verified ->
                    if (verified) {
                        onReceiverSyncedFileStatus(
                            fileId = fileId,
                            status = FileTransferStatus.COMPLETED,
                            verified = true,
                            transferredBytes = -1L,
                            errorMessage = null
                        )
                    }
                },
                onReceiverFileStateSynced = { fileId, status, verified, transferredBytes, errorMessage ->
                    onReceiverSyncedFileStatus(
                        fileId = fileId,
                        status = status,
                        verified = verified,
                        transferredBytes = transferredBytes,
                        errorMessage = errorMessage
                    )
                },
                onIncomingConnectionRequest = { incomingReq ->
                    onReceiverRequestedConnection(incomingReq)
                },
                isPausedProvider = { _uiState.value.isPaused },
                isFileCancelledProvider = { fileId -> fileId in cancelledFileIds },
                isFilePausedProvider = { fileId -> fileId in pausedFileIds }
            )
            val port = server.startServer()
            chunkServer = server
            retainedChunkServer = server
            val net = P2PChunkServer.inspectNetworkStatus(appContext, port, isServerRunning = true)
            val initialCode = buildShortCodeFromIp(net.localIp)
            _uiState.update {
                it.copy(
                    networkStatus = net,
                    connectionCode = initialCode,
                    enteredReceiveCode = ""
                )
            }
        }
    }

    /**
     * Synchronizes the Sender's per-file status with the exact state reported by the Receiver
     * (WAITING/QUEUED, TRANSFERRING, PAUSED, RETRYING, VERIFYING, COMPLETED, FAILED, CANCELLED).
     * Guarantees a file is never marked COMPLETED on the Sender unless verified by the Receiver.
     */
    internal fun onReceiverSyncedFileStatus(
        fileId: String,
        status: FileTransferStatus,
        verified: Boolean,
        transferredBytes: Long,
        errorMessage: String?
    ) {
        var newlyCompletedItem: TransferFileItem? = null
        var newlyFailedItem: TransferFileItem? = null

        _uiState.update { state ->
            val updated = state.files.map { f ->
                if (f.id != fileId) {
                    f
                } else {
                    val effectiveStatus = if (verified) FileTransferStatus.COMPLETED else status
                    val updatedBytes = when {
                        effectiveStatus == FileTransferStatus.COMPLETED || effectiveStatus == FileTransferStatus.VERIFYING -> f.sizeBytes
                        transferredBytes >= 0L -> minOf(f.sizeBytes, transferredBytes)
                        else -> f.transferredBytes
                    }
                    val updatedChunks = when {
                        effectiveStatus == FileTransferStatus.COMPLETED || effectiveStatus == FileTransferStatus.VERIFYING -> f.totalChunks
                        transferredBytes >= 0L && state.selectedChunkSize.bytes > 0 -> {
                            val cBytes = state.selectedChunkSize.bytes.toLong().coerceAtLeast(1L)
                            ((updatedBytes + cBytes - 1L) / cBytes).coerceIn(0L, (f.totalChunks - 1).coerceAtLeast(0).toLong()).toInt()
                        }
                        else -> f.completedChunks
                    }
                    val nextItem = f.copy(
                        completedChunks = updatedChunks,
                        transferredBytes = updatedBytes,
                        status = effectiveStatus,
                        currentSpeedBytesPerSec = if (
                            effectiveStatus == FileTransferStatus.COMPLETED ||
                            effectiveStatus == FileTransferStatus.FAILED ||
                            effectiveStatus == FileTransferStatus.PAUSED ||
                            effectiveStatus == FileTransferStatus.CANCELLED ||
                            effectiveStatus == FileTransferStatus.VERIFYING
                        ) 0.0 else f.currentSpeedBytesPerSec,
                        sha256Verified = if (effectiveStatus == FileTransferStatus.COMPLETED) true else f.sha256Verified,
                        errorMessage = when (effectiveStatus) {
                            FileTransferStatus.COMPLETED, FileTransferStatus.TRANSFERRING, FileTransferStatus.VERIFYING, FileTransferStatus.QUEUED, FileTransferStatus.WAITING -> null
                            FileTransferStatus.FAILED -> errorMessage ?: f.errorMessage ?: "فشل النقل لدى جهاز المستلم"
                            FileTransferStatus.RETRYING -> errorMessage ?: "جاري إعادة المحاولة تلقائياً..."
                            FileTransferStatus.CANCELLED -> errorMessage ?: f.errorMessage ?: "تم إلغاء نقل هذا الملف"
                            FileTransferStatus.PAUSED -> null
                        }
                    )
                    if (effectiveStatus == FileTransferStatus.COMPLETED && f.status != FileTransferStatus.COMPLETED) {
                        newlyCompletedItem = nextItem
                    } else if (effectiveStatus == FileTransferStatus.FAILED && f.status != FileTransferStatus.FAILED) {
                        newlyFailedItem = nextItem
                    }
                    nextItem
                }
            }

            val nonCancelled = updated.filterNot { it.status == FileTransferStatus.CANCELLED }
            val allCompleted = nonCancelled.isNotEmpty() && nonCancelled.all { it.status == FileTransferStatus.COMPLETED }
            val allFinishedOrFailed = nonCancelled.isNotEmpty() && nonCancelled.all {
                it.status == FileTransferStatus.COMPLETED || it.status == FileTransferStatus.FAILED
            }
            val anyFailed = nonCancelled.any { it.status == FileTransferStatus.FAILED }

            state.copy(
                files = updated,
                isTransferRunning = if (allFinishedOrFailed) false else state.isTransferRunning,
                isBackgroundServiceActive = if (allCompleted) false else state.isBackgroundServiceActive,
                senderSessionPhase = if (allCompleted) SenderSessionPhase.COMPLETED else state.senderSessionPhase,
                liveOverallSpeedBytesPerSec = if (allFinishedOrFailed || state.isPaused) 0.0 else state.liveOverallSpeedBytesPerSec,
                connectedPeerLabel = when {
                    allCompleted -> "اكتمل إرسال جميع الملفات والمجلدات وتم التحقق من سلامتها (SHA-256) لدى المستلم"
                    allFinishedOrFailed && anyFailed -> "انتهت الجلسة مع تعذر إكمال بعض الملفات — راجع حالة كل ملف بالأسفل"
                    else -> state.connectedPeerLabel
                },
                statusBannerMessage = when {
                    allCompleted -> "اكتمل إرسال جميع الملفات والمجلدات إلى الجهاز المستلم وتم التحقق من سلامتها بنجاح!"
                    newlyFailedItem != null -> "تعذر نقل «${newlyFailedItem!!.name}»: ${newlyFailedItem!!.errorMessage ?: ""}"
                    else -> state.statusBannerMessage
                }
            )
        }
        retainedActiveState = _uiState.value

        newlyCompletedItem?.let { completed ->
            if (!completed.isDirectory) {
                recordHistoryItem(
                    item = completed,
                    direction = TransferDirection.SENDING,
                    peerAddress = "Receiver",
                    avgSpeedBytesPerSec = _uiState.value.averageSpeedBytesPerSec
                )
            }
        }
        newlyFailedItem?.let { failed ->
            if (!failed.isDirectory) {
                recordHistoryItem(
                    item = failed,
                    direction = TransferDirection.SENDING,
                    peerAddress = "Receiver",
                    avgSpeedBytesPerSec = 0.0,
                    errorMessage = failed.errorMessage
                )
            }
        }
    }

    private fun buildShortCodeFromIp(ip: String): String {
        val parts = ip.split(".")
        val lastOctet = parts.lastOrNull()?.toIntOrNull() ?: Random.nextInt(10, 99)
        val thirdOctet = parts.getOrNull(2)?.toIntOrNull() ?: 43
        val suffix = String.format(Locale.US, "%02d%02d", thirdOctet % 100, lastOctet % 100)
        return "BRQ-$suffix"
    }

    fun refreshNetworkStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>().applicationContext
            val port = chunkServer?.boundPort ?: 8989
            val net = P2PChunkServer.inspectNetworkStatus(appContext, port, isServerRunning = true)
            val updatedCode = buildShortCodeFromIp(net.localIp)
            _uiState.update {
                it.copy(
                    networkStatus = net,
                    connectionCode = if (!it.isSenderReady) updatedCode else it.connectionCode,
                    statusBannerMessage = "تم تحديث الشبكة: ${net.localIp}:${net.port} (${net.networkTypeLabel})"
                )
            }
        }
    }

    fun regenerateConnectionCode() {
        val ip = _uiState.value.networkStatus.localIp
        val parts = ip.split(".")
        val lastOctet = parts.lastOrNull()?.toIntOrNull() ?: 1
        val thirdOctet = parts.getOrNull(2)?.toIntOrNull() ?: 43
        val newCode = String.format(Locale.US, "BRQ-%02d%02d", thirdOctet % 100, lastOctet % 100)
        _uiState.update {
            it.copy(
                connectionCode = newCode,
                statusBannerMessage = "تم تحديث كود الاتصال المباشر: $newCode (العنوان: $ip:${it.networkStatus.port})"
            )
        }
    }

    fun loadInstalledApps(includeSystem: Boolean = _uiState.value.includeSystemApps) {
        _uiState.update { it.copy(isLoadingApps = true, includeSystemApps = includeSystem) }
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            val apps = InstalledAppsRepository.loadInstalledSharableApps(ctx, includeSystem)
            _uiState.update {
                it.copy(
                    installedApps = apps,
                    isLoadingApps = false
                )
            }
        }
    }

    /**
     * Loads device media and files progressively and concurrently across independent background coroutines:
     * - Restores persisted SAF permissions immediately without prompting the user.
     * - Streams progressive batches of Images and Videos as soon as each batch of 80 items is ready,
     *   without waiting for the entire library scan to finish.
     * - Tracks per-category loading flags (isLoadingImages, isLoadingVideos, isLoadingAudio) and completion flags
     *   (hasCompletedInitialVideoScan, hasCompletedInitialImageScan) so Empty State is never shown prematurely.
     */
    fun loadAllDeviceMediaAndFiles() {
        mediaLoadJob?.cancel()
        directoryContentsCache.clear()
        _uiState.update {
            it.copy(
                isLoadingMedia = true,
                isLoadingImages = true,
                isLoadingVideos = true,
                isLoadingAudio = true,
                videoScanErrorMessage = null
            )
        }
        // Immediately load the active browsing directory (or Root of Internal Storage) on Dispatchers.IO
        refreshCurrentBrowsingDirectoryAsync(_uiState.value.browsingFolderFilter, useCacheFirst = false)

        mediaLoadJob = viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            checkMediaPermissionsStatus()
            restorePersistedSafFolders()

            // 1. Progressive batch image loading on Dispatchers.IO
            val imagesJob = launch(Dispatchers.IO) {
                try {
                    val fullImages = DeviceMediaRepository.loadImages(
                        context = ctx,
                        maxItems = 2500,
                        offset = 0,
                        batchSize = 80,
                        onBatchLoaded = { progressiveBatch ->
                            if (isActive && progressiveBatch.isNotEmpty()) {
                                _uiState.update { it.copy(deviceImages = progressiveBatch) }
                            }
                        },
                        isCancelled = { !isActive }
                    )
                    if (isActive) {
                        _uiState.update {
                            it.copy(
                                deviceImages = fullImages,
                                isLoadingImages = false,
                                hasCompletedInitialImageScan = true
                            )
                        }
                    }
                } catch (ce: CancellationException) {
                    throw ce
                } catch (t: Throwable) {
                    _uiState.update {
                        it.copy(
                            isLoadingImages = false,
                            hasCompletedInitialImageScan = true
                        )
                    }
                }
            }

            // 2. Comprehensive, progressive video discovery on Dispatchers.IO (MediaStore.Video + MediaStore.Files + Subfolders + SAF)
            val videosJob = launch(Dispatchers.IO) {
                try {
                    val fullVideos = DeviceMediaRepository.loadVideos(
                        context = ctx,
                        maxItems = 1500,
                        offset = 0,
                        batchSize = 60,
                        onBatchLoaded = { progressiveBatch ->
                            if (isActive && progressiveBatch.isNotEmpty()) {
                                _uiState.update {
                                    it.copy(
                                        deviceVideos = progressiveBatch,
                                        videoScanErrorMessage = null
                                    )
                                }
                            }
                        },
                        isCancelled = { !isActive }
                    )
                    if (isActive) {
                        _uiState.update {
                            it.copy(
                                deviceVideos = fullVideos,
                                isLoadingVideos = false,
                                hasCompletedInitialVideoScan = true,
                                videoScanErrorMessage = null
                            )
                        }
                    }
                } catch (ce: CancellationException) {
                    throw ce
                } catch (t: Throwable) {
                    _uiState.update {
                        it.copy(
                            isLoadingVideos = false,
                            hasCompletedInitialVideoScan = true,
                            videoScanErrorMessage = "حدث خطأ مؤقت أثناء فحص الفيديوهات: ${t.localizedMessage ?: "يرجى المحاولة مرة أخرى"}"
                        )
                    }
                }
            }

            // 3. Audio query in parallel on Dispatchers.IO
            val audioJob = launch(Dispatchers.IO) {
                try {
                    val audio = DeviceMediaRepository.loadAudioFiles(
                        context = ctx,
                        maxItems = 1500,
                        offset = 0,
                        batchSize = 80,
                        onBatchLoaded = { progressiveBatch ->
                            if (isActive && progressiveBatch.isNotEmpty()) {
                                _uiState.update { it.copy(deviceAudio = progressiveBatch) }
                            }
                        },
                        isCancelled = { !isActive }
                    )
                    if (isActive) {
                        _uiState.update {
                            it.copy(
                                deviceAudio = audio,
                                isLoadingAudio = false,
                                hasCompletedInitialAudioScan = true
                            )
                        }
                    }
                } catch (ce: CancellationException) {
                    throw ce
                } catch (_: Throwable) {
                    _uiState.update {
                        it.copy(
                            isLoadingAudio = false,
                            hasCompletedInitialAudioScan = true
                        )
                    }
                }
            }

            // 4. General files, folders, SAF, and APKs in parallel
            val filesJob = launch(Dispatchers.IO) {
                val (generalFiles, folders) = DeviceMediaRepository.loadGeneralFilesAndFolders(ctx)
                val allSavedSaf = DeviceMediaRepository.loadAllSavedSafFoldersWithStatus(ctx)
                val persistedSaf = allSavedSaf.filter { it.isValid }
                val revokedSaf = allSavedSaf.filter { !it.isValid }
                val downloadDir = resolveBarqSherDownloadsDir(ctx)
                val apks = DeviceMediaRepository.loadReceivedApkFiles(ctx, downloadDir, _uiState.value.transferHistory)
                _uiState.update {
                    it.copy(
                        deviceGeneralFiles = generalFiles,
                        storageFolders = folders,
                        persistedSafFolders = persistedSaf,
                        revokedSafFolders = revokedSaf,
                        receivedApks = apks
                    )
                }
                directoryContentsCache.clear()
                refreshCurrentBrowsingDirectoryAsync(_uiState.value.browsingFolderFilter, useCacheFirst = false)
            }

            imagesJob.join()
            videosJob.join()
            audioJob.join()
            filesJob.join()

            // Merge preloaded media items into File Manager index in background
            val currentMedia = _uiState.value.let { it.deviceImages + it.deviceVideos + it.deviceAudio }
            if (currentMedia.isNotEmpty()) {
                val (mergedFiles, mergedFolders) = DeviceMediaRepository.loadGeneralFilesAndFolders(
                    context = ctx,
                    extraMediaItems = currentMedia
                )
                _uiState.update {
                    it.copy(
                        deviceGeneralFiles = mergedFiles,
                        storageFolders = mergedFolders,
                        isLoadingMedia = false,
                        isLoadingImages = false,
                        isLoadingVideos = false,
                        isLoadingAudio = false,
                        hasCompletedInitialImageScan = true,
                        hasCompletedInitialVideoScan = true,
                        hasCompletedInitialAudioScan = true
                    )
                }
                directoryContentsCache.clear()
                refreshCurrentBrowsingDirectoryAsync(_uiState.value.browsingFolderFilter, useCacheFirst = false)
            } else {
                _uiState.update {
                    it.copy(
                        isLoadingMedia = false,
                        isLoadingImages = false,
                        isLoadingVideos = false,
                        isLoadingAudio = false,
                        hasCompletedInitialImageScan = true,
                        hasCompletedInitialVideoScan = true,
                        hasCompletedInitialAudioScan = true
                    )
                }
            }
        }
    }

    /**
     * Asynchronously loads the immediate folders and files for the current path (or Root of Internal Storage when null)
     * on Dispatchers.IO, cancelling any previous folder load and using an in-memory cache for instant Back navigation.
     */
    private fun refreshCurrentBrowsingDirectoryAsync(
        targetRelPath: String?,
        useCacheFirst: Boolean = true
    ) {
        directoryBrowseJob?.cancel()
        folderStatsCalculationJob?.cancel()
        val genId = directoryBrowseGeneration.incrementAndGet()
        val cleanRel = targetRelPath?.trim()?.trim('/')?.replace('\\', '/') ?: ""
        val cacheKey = cleanRel.lowercase(Locale.ROOT)

        // Check if this is a restricted Android 11+ system directory (Android/data or Android/obb)
        val isRestrictedTarget = cleanRel.equals("Android/data", ignoreCase = true) ||
            cleanRel.equals("Android/obb", ignoreCase = true) ||
            cleanRel.startsWith("Android/data/", ignoreCase = true) ||
            cleanRel.startsWith("Android/obb/", ignoreCase = true)

        val cached = if (useCacheFirst) directoryContentsCache[cacheKey] else null
        if (cached != null) {
            _uiState.update {
                it.copy(
                    browsingFolderFilter = cleanRel.ifEmpty { null },
                    currentBrowsingFolders = cached.first,
                    currentBrowsingFiles = cached.second,
                    isBrowsingDirectoryLoading = false,
                    browsingDirectoryError = null
                )
            }
            launchLazyFolderStatsCalculation(cached.first, cacheKey)
            return
        }

        _uiState.update {
            it.copy(
                browsingFolderFilter = cleanRel.ifEmpty { null },
                isBrowsingDirectoryLoading = true,
                browsingDirectoryError = null
            )
        }

        directoryBrowseJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                if (isRestrictedTarget) {
                    @Suppress("DEPRECATION")
                    val extRoot = Environment.getExternalStorageDirectory()
                    val targetDir = extRoot?.let { File(it, cleanRel) }
                    val canReadDir = targetDir != null && targetDir.exists() && targetDir.canRead() && (targetDir.listFiles() != null)
                    if (!canReadDir) {
                        if (directoryBrowseGeneration.get() == genId) {
                            _uiState.update {
                                it.copy(
                                    currentBrowsingFolders = emptyList(),
                                    currentBrowsingFiles = emptyList(),
                                    isBrowsingDirectoryLoading = false,
                                    browsingDirectoryError = "يقيد نظام Android 11+ (API 30+) الوصول المباشر إلى المجلد المحمي ($cleanRel) لحماية خصوصية التطبيقات ولا يسمح بتجاوزه. يمكنك استخدام زر (📁 مجلد SAF) لاختيار أي مجلد مسموح من النظام."
                                )
                            }
                        }
                        return@launch
                    }
                }

                val stateSnap = _uiState.value
                val (folders, files) = DeviceMediaRepository.browseLocalDirectoryChildren(
                    browsingRelOrAbsPath = cleanRel,
                    allKnownFolders = stateSnap.storageFolders,
                    allKnownFiles = stateSnap.deviceGeneralFiles,
                    onPartialResult = { partialFolders, partialFiles ->
                        if (directoryBrowseGeneration.get() == genId) {
                            _uiState.update {
                                it.copy(
                                    currentBrowsingFolders = partialFolders,
                                    currentBrowsingFiles = partialFiles,
                                    isBrowsingDirectoryLoading = true
                                )
                            }
                        }
                    },
                    isCancelled = { !isActive || directoryBrowseGeneration.get() != genId }
                )

                if (!isActive || directoryBrowseGeneration.get() != genId) return@launch

                directoryContentsCache[cacheKey] = folders to files
                _uiState.update {
                    it.copy(
                        currentBrowsingFolders = folders,
                        currentBrowsingFiles = files,
                        isBrowsingDirectoryLoading = false,
                        browsingDirectoryError = null
                    )
                }
                launchLazyFolderStatsCalculation(folders, cacheKey)
            } catch (t: Throwable) {
                if (directoryBrowseGeneration.get() == genId) {
                    _uiState.update {
                        it.copy(
                            isBrowsingDirectoryLoading = false,
                            browsingDirectoryError = "تعذر قراءة محتويات المجلد (${cleanRel.ifEmpty { "التخزين الداخلي" }}): ${t.localizedMessage ?: "خطأ في الصلاحيات"}"
                        )
                    }
                }
            }
        }
    }

    /**
     * Lazily computes folder sizes and file counts in the background on Dispatchers.IO for visible/browsed
     * folders whose stats were not yet calculated, cancelling automatically if the user navigates to another folder.
     */
    private fun launchLazyFolderStatsCalculation(
        folders: List<StorageFolderItem>,
        cacheKey: String? = null
    ) {
        folderStatsCalculationJob?.cancel()
        val pendingFolders = folders.filter { f ->
            !f.isProtectedSystemFolder &&
                (f.statsStatus == FolderStatsStatus.CALCULATING || f.statsStatus == FolderStatsStatus.NOT_CALCULATED)
        }
        if (pendingFolders.isEmpty()) return

        folderStatsCalculationJob = viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            for (folder in pendingFolders) {
                if (!isActive) break
                val computed = DeviceMediaRepository.computeFolderStatsLazy(
                    folder = folder,
                    context = ctx,
                    maxFilesCap = 5000,
                    isCancelled = { !isActive }
                )
                if (!isActive) break
                if (cacheKey != null) {
                    directoryContentsCache.computeIfPresent(cacheKey) { _, pair ->
                        val updatedList = pair.first.map { if (it.path == computed.path) computed else it }
                        updatedList to pair.second
                    }
                }
                _uiState.update { s ->
                    s.copy(
                        currentBrowsingFolders = s.currentBrowsingFolders.map { if (it.path == computed.path) computed else it },
                        storageFolders = s.storageFolders.map { if (it.path == computed.path) computed else it },
                        safBrowsingFolders = s.safBrowsingFolders.map { if (it.path == computed.path) computed else it }
                    )
                }
            }
        }
    }

    /**
     * Opens a SAF tree URI inside the internal File Manager for interactive browsing & selection,
     * validating URI permissions first, persisting access permissions via ContentResolver + SharedPreferences,
     * cancelling any prior directory load, and maintaining a multi-level backstack.
     */
    fun browseSafTreeFolder(
        treeUri: Uri,
        displayName: String? = null,
        docId: String? = null,
        pushHistory: Boolean = true,
        isNewlyPickedFromSystem: Boolean = false
    ) {
        directoryBrowseJob?.cancel()
        folderStatsCalculationJob?.cancel()
        val genId = directoryBrowseGeneration.incrementAndGet()
        val prevState = _uiState.value
        if (pushHistory && prevState.activeSafTreeUri == treeUri && prevState.activeSafPathLabel != null) {
            if (prevState.activeSafDocumentId != docId) {
                safNavigationStack.addLast(prevState.activeSafDocumentId to prevState.activeSafPathLabel)
            }
        } else if (prevState.activeSafTreeUri != treeUri || docId == null) {
            safNavigationStack.clear()
        }

        _uiState.update {
            it.copy(
                isLoadingMedia = true,
                isBrowsingDirectoryLoading = true,
                browsingDirectoryError = null,
                statusBannerMessage = "جاري التحقق من صلاحية المجلد وفتحه عبر (SAF)..."
            )
        }
        directoryBrowseJob = viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            val validation = if (isNewlyPickedFromSystem) {
                DeviceMediaRepository.persistAndSaveSafFolder(ctx, treeUri, displayName)
            } else {
                val existingCheck = DeviceMediaRepository.validateSafTreeUri(ctx, treeUri)
                if (existingCheck.isValid) {
                    DeviceMediaRepository.persistAndSaveSafFolder(ctx, treeUri, displayName ?: existingCheck.displayName)
                } else {
                    existingCheck
                }
            }

            val allSavedSaf = DeviceMediaRepository.loadAllSavedSafFoldersWithStatus(ctx)
            val persistedSaf = allSavedSaf.filter { it.isValid }
            val revokedSaf = allSavedSaf.filter { !it.isValid }

            if (!validation.isValid) {
                if (directoryBrowseGeneration.get() == genId) {
                    _uiState.update {
                        it.copy(
                            isLoadingMedia = false,
                            isBrowsingDirectoryLoading = false,
                            persistedSafFolders = persistedSaf,
                            revokedSafFolders = revokedSaf,
                            activeSafTreeUri = null,
                            browsingDirectoryError = validation.message,
                            statusBannerMessage = validation.message
                        )
                    }
                }
                return@launch
            }

            val label = displayName
                ?: validation.displayName.takeIf { it.isNotBlank() }
                ?: persistedSaf.find { it.treeUri == treeUri }?.displayName
                ?: "مجلد النظام (SAF)"

            val (childFolders, childFiles) = DeviceMediaRepository.browseSafDirectoryChildren(
                context = ctx,
                treeUri = treeUri,
                parentDocId = docId,
                parentDisplayPath = label,
                onPartialResult = { partialFolders, partialFiles ->
                    if (directoryBrowseGeneration.get() == genId) {
                        _uiState.update {
                            it.copy(
                                activeSafTreeUri = treeUri,
                                activeSafDocumentId = docId,
                                activeSafPathLabel = label,
                                safBrowsingFolders = partialFolders,
                                safBrowsingFiles = partialFiles,
                                isBrowsingDirectoryLoading = true
                            )
                        }
                    }
                },
                isCancelled = { !isActive || directoryBrowseGeneration.get() != genId }
            )

            if (!isActive || directoryBrowseGeneration.get() != genId) return@launch

            _uiState.update {
                it.copy(
                    isLoadingMedia = false,
                    isBrowsingDirectoryLoading = false,
                    persistedSafFolders = persistedSaf,
                    revokedSafFolders = revokedSaf,
                    activeSafTreeUri = treeUri,
                    activeSafDocumentId = docId,
                    activeSafPathLabel = label,
                    safBrowsingFolders = childFolders,
                    safBrowsingFiles = childFiles,
                    browsingFolderFilter = null,
                    browsingDirectoryError = null,
                    statusBannerMessage = "تم فتح «$label» للتصفح (${childFolders.size} مجلد فرعي و ${childFiles.size} ملف)"
                )
            }
            launchLazyFolderStatsCalculation(childFolders, null)
        }
    }

    fun exitSafBrowser() {
        directoryBrowseJob?.cancel()
        folderStatsCalculationJob?.cancel()
        safNavigationStack.clear()
        _uiState.update {
            it.copy(
                activeSafTreeUri = null,
                activeSafDocumentId = null,
                activeSafPathLabel = null,
                safBrowsingFolders = emptyList(),
                safBrowsingFiles = emptyList()
            )
        }
        refreshCurrentBrowsingDirectoryAsync(null, useCacheFirst = true)
    }

    /**
     * Navigates up one directory level in the internal File Manager (breadcrumbs / Up button),
     * restoring parent folder contents from the in-memory cache without reloading all storage.
     */
    fun navigateUpDirectory(): Boolean {
        val state = _uiState.value
        if (state.activeSafTreeUri != null) {
            if (safNavigationStack.isNotEmpty()) {
                val (prevDocId, prevLabel) = safNavigationStack.removeLast()
                browseSafTreeFolder(
                    treeUri = state.activeSafTreeUri,
                    displayName = prevLabel,
                    docId = prevDocId,
                    pushHistory = false
                )
                return true
            }
            val currentLabel = state.activeSafPathLabel ?: ""
            if (currentLabel.contains('/')) {
                val rootLabel = currentLabel.substringBefore('/')
                browseSafTreeFolder(state.activeSafTreeUri, displayName = rootLabel, docId = null, pushHistory = false)
            } else {
                exitSafBrowser()
            }
            return true
        }
        val currentFilter = state.browsingFolderFilter
        if (!currentFilter.isNullOrBlank()) {
            val cleaned = currentFilter.trim().trim('/')
            val parentFilter = if (cleaned.contains('/')) {
                cleaned.substringBeforeLast('/')
            } else {
                null
            }
            refreshCurrentBrowsingDirectoryAsync(parentFilter, useCacheFirst = true)
            return true
        }
        return false
    }

    /**
     * Inspects Android/obb or Android/data honestly according to Android 11+ (API 30+) OS security policies.
     */
    fun inspectProtectedAndroidFolder(folderType: String) {
        val normalized = folderType.trim().lowercase(Locale.ROOT)
        val isObb = normalized.contains("obb")
        val targetRel = if (isObb) "Android/obb" else "Android/data"
        @Suppress("DEPRECATION")
        val extRoot = Environment.getExternalStorageDirectory()
        val targetDir = extRoot?.let { File(it, targetRel) }
        val canListDirectly = targetDir != null && targetDir.exists() && targetDir.canRead() && (targetDir.listFiles() != null)

        if (canListDirectly) {
            _uiState.update {
                it.copy(
                    browsingFolderFilter = targetRel,
                    statusBannerMessage = "تم فتح مجلد $targetRel المتاح على هذا الإصدار من أندرويد"
                )
            }
        } else {
            val accessibleObbFiles = _uiState.value.deviceGeneralFiles.filter {
                it.name.endsWith(".obb", ignoreCase = true) ||
                    it.relativePath.contains("obb", ignoreCase = true)
            }
            val msg = if (isObb && accessibleObbFiles.isNotEmpty()) {
                "مجلد Android/obb مقيد من نظام أندرويد 11+ للتصفح المباشر، ولكن تم العثور على ${accessibleObbFiles.size} ملفات توسعة ألعاب (.obb) متاحة في تبويب (ملفات APK و OBB)."
            } else {
                "يقيد نظام Android 11+ (API 30+) الوصول المباشر إلى المجلد المحمي ($targetRel) لحماية خصوصية التطبيقات ولا يسمح بتجاوزه. يمكنك إرسال ملفات التثبيت (.apk / .xapk / .obb) الموجودة في التنزيلات أو استخدام زر (تحديد مجلد عبر النظام SAF) للمجلدات المسموحة."
            }
            _uiState.update {
                it.copy(
                    activeFilesSubTab = if (isObb) FilesSubTab.APKS else it.activeFilesSubTab,
                    showAndroidStoragePolicySheet = true,
                    statusBannerMessage = msg
                )
            }
        }
    }

    /**
     * Dedicated "إرسال مجلد" (Send Entire Folder) feature via ACTION_OPEN_DOCUMENT_TREE.
     * Automatically persists URI access in ContentResolver and SharedPreferences, recursively reads all files,
     * subfolders, and empty folders, adds the entire folder hierarchy to the Send Queue as one operation,
     * and opens the Send screen.
     */
    fun onSendEntireFolderTreePicked(treeUri: Uri) {
        _uiState.update {
            it.copy(
                isScanningFolder = true,
                statusBannerMessage = "جاري حفظ صلاحية المجلد وفحص بنيته الفرعية بالكامل لإرساله كوحدة واحدة..."
            )
        }
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            DeviceMediaRepository.persistAndSaveSafFolder(ctx, treeUri)
            val chunkBytes = _uiState.value.selectedChunkSize.bytes
            val scanResult = DeviceMediaRepository.scanDocumentTreeForTransfer(ctx, treeUri, chunkBytes)
            val persistedSaf = DeviceMediaRepository.loadPersistedSafFolders(ctx)
            if (scanResult.errorMessage != null || scanResult.batchInfo == null) {
                _uiState.update {
                    it.copy(
                        isScanningFolder = false,
                        persistedSafFolders = persistedSaf,
                        statusBannerMessage = scanResult.errorMessage ?: "تعذر قراءة المجلد المختار"
                    )
                }
                return@launch
            }
            val batch = scanResult.batchInfo
            var addedForActiveSession: List<TransferFileItem> = emptyList()
            _uiState.update { state ->
                val sessionActive = state.isSenderReady || state.isTransferRunning
                val existingFiltered = state.files.filterNot { it.rootFolderName == batch.rootFolderName }
                val existingBatches = state.folderBatches.filterNot { it.rootFolderName == batch.rootFolderName }
                addedForActiveSession = scanResult.transferItems
                val skippedNote = if (batch.skippedUnreadableCount > 0) {
                    " (تم تخطي ${batch.skippedUnreadableCount} عنصر محمي من النظام)"
                } else ""
                state.copy(
                    isScanningFolder = false,
                    persistedSafFolders = persistedSaf,
                    files = existingFiltered + scanResult.transferItems,
                    folderBatches = existingBatches + batch,
                    safFolderFiles = scanResult.previewMediaItems,
                    isSenderReady = sessionActive,
                    senderSessionPhase = if (sessionActive) {
                        if (state.senderSessionPhase == SenderSessionPhase.COMPLETED) SenderSessionPhase.APPROVED_TRANSFERRING else state.senderSessionPhase
                    } else SenderSessionPhase.IDLE,
                    sessionExpiresAtMillis = if (sessionActive) max(state.sessionExpiresAtMillis, System.currentTimeMillis() + 1800_000L) else state.sessionExpiresAtMillis,
                    transferDirection = TransferDirection.SENDING,
                    currentScreen = if (sessionActive && state.currentScreen == AppScreen.LIVE_TRANSFER) AppScreen.LIVE_TRANSFER else AppScreen.SEND,
                    statusBannerMessage = if (sessionActive) {
                        "تمت إضافة المجلد «${batch.rootFolderName}» (${batch.totalFilesCount} ملف)$skippedNote إلى جلسة النقل النشطة مباشرة!"
                    } else {
                        "تم تجهيز المجلد «${batch.rootFolderName}» بالكامل (${batch.totalFilesCount} ملف و ${batch.totalSubfoldersCount} مجلد فرعي)$skippedNote. اضغط (بدء جلسة الإرسال) الآن!"
                    }
                )
            }
            syncActiveSenderSessionAfterQueueChange(addedForActiveSession)
        }
    }

    /**
     * Sends a local accessible StorageFolderItem directory as a complete folder hierarchy
     * without requiring the user to pick individual files inside it.
     */
    fun sendLocalFolderDirectly(folderPath: String) {
        _uiState.update {
            it.copy(
                isScanningFolder = true,
                statusBannerMessage = "جاري قراءة المجلد وبنيته الفرعية لإرساله كاملاً..."
            )
        }
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            val chunkBytes = _uiState.value.selectedChunkSize.bytes
            val allKnownFolders = (_uiState.value.storageFolders + _uiState.value.safBrowsingFolders).distinctBy { it.path }
            val folderItem = allKnownFolders.find {
                it.path == folderPath || it.relativeDisplayPath.equals(folderPath, ignoreCase = true)
            }
            val scanResult = if (folderItem != null) {
                DeviceMediaRepository.scanStorageFolderItemForTransfer(folderItem, chunkBytes, ctx)
            } else {
                DeviceMediaRepository.scanLocalFolderForTransfer(File(folderPath), chunkBytes)
            }
            if (scanResult.errorMessage != null || scanResult.batchInfo == null) {
                _uiState.update {
                    it.copy(
                        isScanningFolder = false,
                        statusBannerMessage = scanResult.errorMessage ?: "تعذر قراءة المجلد المحلي"
                    )
                }
                return@launch
            }
            val batch = scanResult.batchInfo
            var addedForActiveSession: List<TransferFileItem> = emptyList()
            _uiState.update { state ->
                val sessionActive = state.isSenderReady || state.isTransferRunning
                val existingFiltered = state.files.filterNot { it.rootFolderName == batch.rootFolderName }
                val existingBatches = state.folderBatches.filterNot { it.rootFolderName == batch.rootFolderName }
                addedForActiveSession = scanResult.transferItems
                state.copy(
                    isScanningFolder = false,
                    files = existingFiltered + scanResult.transferItems,
                    folderBatches = existingBatches + batch,
                    isSenderReady = sessionActive,
                    senderSessionPhase = if (sessionActive) {
                        if (state.senderSessionPhase == SenderSessionPhase.COMPLETED) SenderSessionPhase.APPROVED_TRANSFERRING else state.senderSessionPhase
                    } else SenderSessionPhase.IDLE,
                    sessionExpiresAtMillis = if (sessionActive) max(state.sessionExpiresAtMillis, System.currentTimeMillis() + 1800_000L) else state.sessionExpiresAtMillis,
                    transferDirection = TransferDirection.SENDING,
                    currentScreen = if (sessionActive && state.currentScreen == AppScreen.LIVE_TRANSFER) AppScreen.LIVE_TRANSFER else AppScreen.SEND,
                    statusBannerMessage = if (sessionActive) {
                        "تمت إضافة المجلد «${batch.rootFolderName}» (${batch.totalFilesCount} ملف) إلى جلسة النقل النشطة مباشرة!"
                    } else {
                        "تم تجهيز المجلد «${batch.rootFolderName}» بالكامل (${batch.totalFilesCount} ملف و ${batch.totalSubfoldersCount} مجلد فرعي). اضغط (بدء جلسة الإرسال) الآن!"
                    }
                )
            }
            syncActiveSenderSessionAfterQueueChange(addedForActiveSession)
        }
    }

    fun removeFolderBatch(batchId: String) = synchronized(transferControlLock) {
        val removedIds = _uiState.value.files.filter { it.folderBatchId == batchId }.map { it.id }
        if (removedIds.isEmpty() && _uiState.value.folderBatches.none { it.batchId == batchId }) return
        removedIds.forEach { id ->
            cancelledFileIds.add(id)
            pausedFileIds.remove(id)
            senderFileStartNanoMap.remove(id)
            senderFileServedBytesMap.remove(id)
        }
        _uiState.update { state ->
            val remainingFiles = state.files.filterNot { it.folderBatchId == batchId }
            val remainingBatches = state.folderBatches.filterNot { it.batchId == batchId }
            if (remainingFiles.isEmpty()) {
                state.copy(
                    files = emptyList(),
                    folderBatches = emptyList(),
                    isSenderReady = false,
                    isTransferRunning = false,
                    isPaused = false,
                    isBackgroundServiceActive = false,
                    liveOverallSpeedBytesPerSec = 0.0,
                    senderSessionPhase = if (state.isSenderReady || state.isTransferRunning) SenderSessionPhase.CANCELLED else SenderSessionPhase.IDLE
                )
            } else {
                val nonCancelled = remainingFiles.filterNot { it.status == FileTransferStatus.CANCELLED }
                val allCompleted = state.isTransferRunning && state.transferDirection == TransferDirection.SENDING &&
                    nonCancelled.isNotEmpty() && nonCancelled.all { it.status == FileTransferStatus.COMPLETED }
                state.copy(
                    files = remainingFiles,
                    folderBatches = remainingBatches,
                    isTransferRunning = if (allCompleted) false else state.isTransferRunning,
                    isBackgroundServiceActive = if (allCompleted) false else state.isBackgroundServiceActive,
                    senderSessionPhase = if (allCompleted) SenderSessionPhase.COMPLETED else state.senderSessionPhase,
                    liveOverallSpeedBytesPerSec = if (allCompleted) 0.0 else state.liveOverallSpeedBytesPerSec
                )
            }
        }
        if (_uiState.value.files.isEmpty()) {
            sessionTimerJob?.cancel()
            chunkServer?.resetSessionHandshake()
            BarqTransferForegroundService.stopTransferService(getApplication())
            retainedActiveState = null
        } else {
            syncActiveSenderSessionAfterQueueChange()
        }
    }

    /**
     * Kept for backward compatibility: picking a folder from SAF immediately prepares the entire folder for sending.
     */
    fun onSafFolderPicked(treeUri: Uri) {
        onSendEntireFolderTreePicked(treeUri)
    }

    fun updateAppsSearchQuery(query: String) {
        _uiState.update { it.copy(appsSearchQuery = query) }
    }

    fun updateMediaSearchQuery(query: String) {
        _uiState.update { it.copy(mediaSearchQuery = query) }
    }

    fun setSortOption(option: SortOption) {
        _uiState.update { it.copy(sortOption = option) }
    }

    fun setActiveFilesSubTab(subTab: FilesSubTab) {
        _uiState.update { it.copy(activeFilesSubTab = subTab, browsingFolderFilter = null) }
        if (subTab == FilesSubTab.ALL || subTab == FilesSubTab.FOLDERS) {
            refreshCurrentBrowsingDirectoryAsync(null, useCacheFirst = true)
        }
    }

    fun setBrowsingFolderFilter(folderRelativePath: String?) {
        _uiState.update { it.copy(activeSafTreeUri = null) }
        refreshCurrentBrowsingDirectoryAsync(folderRelativePath, useCacheFirst = true)
    }

    fun toggleFolderSelection(folderPath: String) {
        var wasAdded = false
        _uiState.update { state ->
            val next = state.selectedFolderPaths.toMutableSet()
            wasAdded = next.add(folderPath)
            if (!wasAdded) next.remove(folderPath)
            state.copy(selectedFolderPaths = next)
        }
        if (wasAdded) {
            val stateSnap = _uiState.value
            val folder = stateSnap.currentBrowsingFolders.find { it.path == folderPath }
                ?: stateSnap.storageFolders.find { it.path == folderPath }
                ?: stateSnap.safBrowsingFolders.find { it.path == folderPath }
            if (folder != null && !folder.isProtectedSystemFolder &&
                (folder.statsStatus == FolderStatsStatus.CALCULATING || folder.statsStatus == FolderStatsStatus.NOT_CALCULATED || (folder.fileCount == 0 && folder.totalBytes == 0L))
            ) {
                viewModelScope.launch(Dispatchers.IO) {
                    val ctx = getApplication<Application>().applicationContext
                    val computed = DeviceMediaRepository.computeFolderStatsLazy(folder, ctx, maxFilesCap = 5000, isCancelled = { !isActive })
                    _uiState.update { s ->
                        s.copy(
                            storageFolders = s.storageFolders.map { if (it.path == computed.path) computed else it },
                            currentBrowsingFolders = s.currentBrowsingFolders.map { if (it.path == computed.path) computed else it },
                            safBrowsingFolders = s.safBrowsingFolders.map { if (it.path == computed.path) computed else it }
                        )
                    }
                }
            }
        }
    }

    fun selectAllVisibleFoldersAndMedia(visibleFolderPaths: List<String>, visibleMediaIds: List<String>) {
        _uiState.update { state ->
            val allFoldersSelected = visibleFolderPaths.isNotEmpty() && visibleFolderPaths.all { it in state.selectedFolderPaths }
            val allMediaSelected = visibleMediaIds.isNotEmpty() && visibleMediaIds.all { it in state.selectedMediaIds }
            val shouldDeselect = (visibleFolderPaths.isEmpty() || allFoldersSelected) &&
                (visibleMediaIds.isEmpty() || allMediaSelected) &&
                (visibleFolderPaths.isNotEmpty() || visibleMediaIds.isNotEmpty())

            if (shouldDeselect) {
                state.copy(
                    selectedFolderPaths = state.selectedFolderPaths - visibleFolderPaths.toSet(),
                    selectedMediaIds = state.selectedMediaIds - visibleMediaIds.toSet()
                )
            } else {
                state.copy(
                    selectedFolderPaths = state.selectedFolderPaths + visibleFolderPaths,
                    selectedMediaIds = state.selectedMediaIds + visibleMediaIds
                )
            }
        }
    }

    /**
     * Locates a folder by relative path (e.g. "Download/ropon" or "ropon") or absolute path,
     * registers it in storageFolders if not already listed, and selects it as a single folder transfer unit.
     */
    fun addOrSelectFolderByPath(rawInput: String) {
        val cleaned = rawInput.trim().trim('/').replace('\\', '/')
        if (cleaned.isBlank()) return
        val lower = cleaned.lowercase(Locale.ROOT)
        if (lower.contains("android/data") || lower.contains("android/obb")) {
            _uiState.update {
                it.copy(
                    showAndroidStoragePolicySheet = true,
                    statusBannerMessage = "تعذر تحديد هذا المجلد لأنه ضمن مجلدات النظام المحمية (Android/data أو Android/obb)"
                )
            }
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            val existingMatch = _uiState.value.storageFolders.firstOrNull {
                it.relativeDisplayPath.equals(cleaned, ignoreCase = true) ||
                    it.path.equals(rawInput.trim(), ignoreCase = true) ||
                    it.name.equals(cleaned, ignoreCase = true)
            }
            if (existingMatch != null) {
                _uiState.update { state ->
                    state.copy(
                        selectedFolderPaths = state.selectedFolderPaths + existingMatch.path,
                        statusBannerMessage = "تم تحديد المجلد «${existingMatch.relativeDisplayPath}» كعنصر نقل واحد"
                    )
                }
                return@launch
            }

            @Suppress("DEPRECATION")
            val extRoot = Environment.getExternalStorageDirectory()
            @Suppress("DEPRECATION")
            val pubDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val candidates = listOfNotNull(
                File(rawInput.trim()).takeIf { it.isAbsolute },
                extRoot?.let { File(it, cleaned) },
                pubDownloads?.let { File(it, cleaned.removePrefix("Download/").removePrefix("download/")) }
            )
            val foundDir = candidates.firstOrNull { it.exists() && it.isDirectory && it.canRead() }
            if (foundDir == null) {
                _uiState.update {
                    it.copy(statusBannerMessage = "تعذر العثور على المجلد ($cleaned) في التخزين المتاح")
                }
                return@launch
            }

            val chunkBytes = _uiState.value.selectedChunkSize.bytes
            val scan = DeviceMediaRepository.scanLocalFolderForTransfer(foundDir, chunkBytes)
            val batch = scan.batchInfo
            val relDisplay = if (cleaned.contains('/')) cleaned else "Download/${foundDir.name}"
            val newFolderItem = StorageFolderItem(
                name = foundDir.name,
                path = foundDir.absolutePath,
                relativeDisplayPath = relDisplay,
                parentFolderName = relDisplay.substringBeforeLast('/', ""),
                fileCount = batch?.totalFilesCount ?: 0,
                subfolderCount = batch?.totalSubfoldersCount ?: 0,
                emptySubfolderCount = batch?.emptyFoldersCount ?: 0,
                totalBytes = batch?.totalBytes ?: 0L,
                lastModifiedMillis = foundDir.lastModified()
            )
            _uiState.update { state ->
                val updatedFolders = (listOf(newFolderItem) + state.storageFolders.filterNot { it.path == newFolderItem.path })
                state.copy(
                    storageFolders = updatedFolders,
                    selectedFolderPaths = state.selectedFolderPaths + newFolderItem.path,
                    statusBannerMessage = "تم العثور على المجلد «${newFolderItem.relativeDisplayPath}» وتحديده للإرسال الكامل"
                )
            }
        }
    }

    fun toggleAppSelection(packageName: String) {
        _uiState.update { state ->
            val next = state.selectedAppPackages.toMutableSet()
            if (!next.add(packageName)) next.remove(packageName)
            state.copy(selectedAppPackages = next)
        }
    }

    fun selectAllVisibleApps(visiblePackages: List<String>) {
        _uiState.update { state ->
            state.copy(selectedAppPackages = state.selectedAppPackages + visiblePackages)
        }
    }

    fun toggleMediaSelection(mediaId: String) {
        _uiState.update { state ->
            val next = state.selectedMediaIds.toMutableSet()
            if (!next.add(mediaId)) next.remove(mediaId)
            state.copy(selectedMediaIds = next)
        }
    }

    fun selectAllVisibleMedia(visibleIds: List<String>) {
        _uiState.update { state ->
            state.copy(selectedMediaIds = state.selectedMediaIds + visibleIds)
        }
    }

    fun clearAllManagerSelections() {
        _uiState.update {
            it.copy(
                selectedFolderPaths = emptySet(),
                selectedAppPackages = emptySet(),
                selectedMediaIds = emptySet()
            )
        }
    }

    /**
     * Converts all selected Storage Folders (each treated as a unified FolderBatchInfo containing
     * all its nested files, subfolders, and empty directories), Installed Apps, and standalone files
     * into the Send Queue in one combined operation and navigates to the Send screen.
     */
    fun addManagerSelectionsToSendQueueAndGoToSend() {
        val state = _uiState.value
        val chunkBytes = state.selectedChunkSize.bytes
        val selectedFolderPathsSnap = state.selectedFolderPaths
        val selectedAppPkgsSnap = state.selectedAppPackages
        val selectedMediaIdsSnap = state.selectedMediaIds

        if (selectedFolderPathsSnap.isEmpty() && selectedAppPkgsSnap.isEmpty() && selectedMediaIdsSnap.isEmpty()) {
            _uiState.update {
                it.copy(statusBannerMessage = "الرجاء تحديد مجلد أو ملف أو تطبيق واحد على الأقل أولاً")
            }
            return
        }

        _uiState.update {
            it.copy(
                isScanningFolder = selectedFolderPathsSnap.isNotEmpty(),
                statusBannerMessage = if (selectedFolderPathsSnap.isNotEmpty()) {
                    "جاري تجهيز المجلدات والملفات المحددة ببنيتها الكاملة للإرسال..."
                } else null
            )
        }

        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            val currentState = _uiState.value
            val newTransferItems = mutableListOf<TransferFileItem>()
            val newFolderBatches = mutableListOf<FolderBatchInfo>()
            val replacedRootFolderNames = HashSet<String>()
            val allKnownFolders = (currentState.storageFolders + currentState.safBrowsingFolders).distinctBy { it.path }

            var firstFolderError: String? = null
            // 1. Scan all selected folders recursively as unified transfer batches
            for (folderPath in selectedFolderPathsSnap) {
                val folderItem = allKnownFolders.find { it.path == folderPath }
                    ?: StorageFolderItem(
                        name = File(folderPath).name.ifBlank { "Folder" },
                        path = folderPath,
                        relativeDisplayPath = File(folderPath).name,
                        fileCount = 0,
                        totalBytes = 0L,
                        lastModifiedMillis = System.currentTimeMillis()
                    )
                val scanResult = DeviceMediaRepository.scanStorageFolderItemForTransfer(folderItem, chunkBytes, ctx)
                if (scanResult.batchInfo != null && scanResult.errorMessage == null) {
                    newFolderBatches.add(scanResult.batchInfo)
                    replacedRootFolderNames.add(scanResult.batchInfo.rootFolderName)
                    newTransferItems.addAll(scanResult.transferItems)
                } else if (scanResult.errorMessage != null && firstFolderError == null) {
                    firstFolderError = scanResult.errorMessage
                }
            }

            // 2. Add all selected Installed Apps
            val selectedApps = currentState.installedApps.filter { it.packageName in selectedAppPkgsSnap }
            for (app in selectedApps) {
                val safeFileName = "${app.appName.replace(Regex("[\\\\/:*?\"<>|]"), "_")}_v${app.versionName}.apk"
                val totalChunks = computeTotalChunksForSize(app.sizeBytes, chunkBytes)
                newTransferItems.add(
                    TransferFileItem(
                        id = "apk_${UUID.randomUUID().toString().take(8)}",
                        name = safeFileName,
                        sizeBytes = app.sizeBytes,
                        category = FileCategory.GAME_APK,
                        localFile = app.apkFile,
                        packageName = app.packageName,
                        hasSplitWarning = app.hasSplitApks,
                        totalChunks = totalChunks
                    )
                )
            }

            // 3. Add all selected standalone Media / Files
            val allMedia = (currentState.deviceImages + currentState.deviceVideos + currentState.deviceAudio +
                currentState.deviceGeneralFiles + currentState.safFolderFiles + currentState.safBrowsingFiles)
                .distinctBy { it.id }
            val selectedMedia = allMedia.filter { it.id in selectedMediaIdsSnap }
            for (media in selectedMedia) {
                if (media.uri != null && media.uri.scheme.equals("content", ignoreCase = true)) {
                    runCatching {
                        ctx.contentResolver.takePersistableUriPermission(
                            media.uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    }
                }
                val verifiedSize = when {
                    media.localFile != null && media.localFile.exists() && media.localFile.isFile && media.localFile.length() > 0L ->
                        media.localFile.length()
                    media.sizeBytes > 0L -> media.sizeBytes
                    media.uri != null -> try {
                        ctx.contentResolver.openAssetFileDescriptor(media.uri, "r")?.use { afd ->
                            if (afd.length > 0L) afd.length else 0L
                        } ?: 0L
                    } catch (_: Throwable) {
                        0L
                    }
                    else -> 0L
                }
                val totalChunks = computeTotalChunksForSize(verifiedSize, chunkBytes)
                newTransferItems.add(
                    TransferFileItem(
                        id = "m_${UUID.randomUUID().toString().replace("-", "").take(12)}",
                        name = media.name.substringAfterLast('/'),
                        sizeBytes = verifiedSize,
                        category = media.category,
                        uri = media.uri,
                        localFile = media.localFile,
                        totalChunks = totalChunks,
                        sha256Expected = if (verifiedSize == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                    )
                )
            }

            if (newTransferItems.isEmpty()) {
                _uiState.update {
                    it.copy(
                        isScanningFolder = false,
                        statusBannerMessage = firstFolderError ?: "تعذر قراءة العناصر المحددة، يرجى التأكد من صلاحية الوصول"
                    )
                }
                return@launch
            }

            _uiState.update { current ->
                val sessionActive = current.isSenderReady || current.isTransferRunning
                val retainedExistingFiles = current.files.filterNot {
                    it.rootFolderName.isNotBlank() && it.rootFolderName in replacedRootFolderNames
                }
                val retainedExistingBatches = current.folderBatches.filterNot {
                    it.rootFolderName in replacedRootFolderNames
                }
                val combinedFiles = (retainedExistingFiles + newTransferItems)
                    .distinctBy { item ->
                        item.uri?.toString()?.takeIf { u -> u.isNotBlank() }
                            ?: item.localFile?.absolutePath?.takeIf { p -> p.isNotBlank() }
                            ?: if (item.relativePath.isNotBlank()) "rel:${item.relativePath}:${item.isDirectory}" else "id:${item.id}"
                    }
                    .distinctBy { it.id }
                val combinedBatches = (retainedExistingBatches + newFolderBatches)
                    .distinctBy { it.rootFolderName }

                val summaryParts = mutableListOf<String>()
                if (newFolderBatches.isNotEmpty()) {
                    val foldersNames = newFolderBatches.joinToString("، ") { "«${it.rootFolderName}»" }
                    summaryParts.add("${newFolderBatches.size} مجلد كامل ($foldersNames)")
                }
                val standaloneAddedCount = selectedApps.size + selectedMedia.size
                if (standaloneAddedCount > 0) {
                    summaryParts.add("$standaloneAddedCount ملف/تطبيق")
                }

                current.copy(
                    isScanningFolder = false,
                    files = combinedFiles,
                    folderBatches = combinedBatches,
                    selectedFolderPaths = emptySet(),
                    selectedAppPackages = emptySet(),
                    selectedMediaIds = emptySet(),
                    isSenderReady = sessionActive,
                    senderSessionPhase = if (sessionActive) {
                        if (current.senderSessionPhase == SenderSessionPhase.COMPLETED) SenderSessionPhase.APPROVED_TRANSFERRING else current.senderSessionPhase
                    } else SenderSessionPhase.IDLE,
                    sessionExpiresAtMillis = if (sessionActive) max(current.sessionExpiresAtMillis, System.currentTimeMillis() + 1800_000L) else current.sessionExpiresAtMillis,
                    transferDirection = TransferDirection.SENDING,
                    currentScreen = if (sessionActive && current.currentScreen == AppScreen.LIVE_TRANSFER) AppScreen.LIVE_TRANSFER else AppScreen.SEND,
                    statusBannerMessage = if (sessionActive) {
                        "تمت إضافة ${summaryParts.joinToString(" و ")} مباشرة إلى جلسة النقل النشطة!"
                    } else {
                        "تم تجهيز ${summaryParts.joinToString(" و ")} في قائمة الإرسال. اضغط (بدء جلسة الإرسال) الآن!"
                    }
                )
            }
            syncActiveSenderSessionAfterQueueChange(newTransferItems)
        }
    }

    fun navigateTo(screen: AppScreen) {
        if (screen == AppScreen.LIVE_TRANSFER && _uiState.value.files.isEmpty()) {
            _uiState.update {
                it.copy(statusBannerMessage = "الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال")
            }
            return
        }
        _uiState.update { it.copy(currentScreen = screen, statusBannerMessage = null) }
    }

    fun toggleHotspotGuideSheet(show: Boolean) {
        _uiState.update { it.copy(showHotspotGuideSheet = show) }
    }

    fun setChunkSize(option: ChunkSizeOption) {
        _uiState.update { state ->
            val updatedFiles = state.files.map { file ->
                val newTotalChunks = computeTotalChunksForSize(file.sizeBytes, option.bytes)
                file.copy(
                    totalChunks = newTotalChunks,
                    completedChunks = if (file.status == FileTransferStatus.COMPLETED) newTotalChunks else 0,
                    transferredBytes = if (file.status == FileTransferStatus.COMPLETED) file.sizeBytes else 0L
                )
            }
            state.copy(
                selectedChunkSize = option,
                files = updatedFiles,
                statusBannerMessage = "تم ضبط حجم الدفعة (Chunk Size) إلى ${option.label}"
            )
        }
    }

    fun updateEnteredReceiveCode(code: String) {
        _uiState.update { it.copy(enteredReceiveCode = code, receiverDiagnosticError = null) }
    }

    fun clearBannerMessage() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    fun addPickedUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val appContext = getApplication<Application>().applicationContext
        val resolver = appContext.contentResolver

        val addedItems = uris.mapNotNull { uri ->
            if (uri.scheme.equals("content", ignoreCase = true)) {
                runCatching {
                    resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
            val directLocalFile = if (uri.scheme.equals("file", ignoreCase = true)) {
                uri.path?.let { File(it) }?.takeIf { it.exists() }
            } else null
            var displayName = directLocalFile?.name
                ?: uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
                ?: "ملف_مرسل_${System.currentTimeMillis() % 10000}"
            var sizeBytes = directLocalFile?.length() ?: 0L
            if (directLocalFile == null) {
                try {
                    resolver.query(uri, null, null, null, null)?.use { cursor ->
                        val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (cursor.moveToFirst()) {
                            if (nameIdx >= 0) {
                                displayName = cursor.getString(nameIdx) ?: displayName
                            }
                            if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                                sizeBytes = cursor.getLong(sizeIdx)
                            }
                        }
                    }
                } catch (_: Exception) {
                }
                if (sizeBytes <= 0L) {
                    try {
                        resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                            if (afd.length > 0) sizeBytes = afd.length
                        }
                    } catch (_: Exception) {
                    }
                }
            }
            if (sizeBytes < 0L) return@mapNotNull null

            val mime = resolver.getType(uri)
            val category = FileCategory.fromFileName(displayName, mime)
            val totalChunks = computeTotalChunksForSize(sizeBytes, _uiState.value.selectedChunkSize.bytes)

            TransferFileItem(
                id = "f_${UUID.randomUUID().toString().replace("-", "")}",
                name = displayName,
                sizeBytes = sizeBytes,
                category = category,
                uri = uri,
                localFile = directLocalFile,
                totalChunks = totalChunks,
                sha256Expected = if (sizeBytes == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
            )
        }

        if (addedItems.isEmpty()) {
            _uiState.update {
                it.copy(statusBannerMessage = "تعذر قراءة الملف المحدد، يرجى اختيار ملف صالح من الجهاز")
            }
            return
        }

        synchronized(transferControlLock) {
            _uiState.update { state ->
                val sessionActive = state.isSenderReady || state.isTransferRunning
                val newlyPickedKeys = addedItems.mapNotNull { item ->
                    item.uri?.toString()?.takeIf { u -> u.isNotBlank() }
                        ?: item.localFile?.absolutePath?.takeIf { p -> p.isNotBlank() }
                }.toSet()
                val baseExisting = state.files.filterNot { existing ->
                    val existingKey = existing.uri?.toString()?.takeIf { u -> u.isNotBlank() }
                        ?: existing.localFile?.absolutePath?.takeIf { p -> p.isNotBlank() }
                    existing.status == FileTransferStatus.FAILED && existingKey != null && existingKey in newlyPickedKeys
                }
                val mergedFiles = (baseExisting + addedItems)
                    .distinctBy { item ->
                        val activeKey = if (item.status == FileTransferStatus.CANCELLED) "cancelled:${item.id}" else "active"
                        val srcKey = item.uri?.toString()?.takeIf { u -> u.isNotBlank() }
                            ?: item.localFile?.absolutePath?.takeIf { p -> p.isNotBlank() }
                            ?: if (item.relativePath.isNotBlank()) "rel:${item.relativePath}:${item.isDirectory}" else "id:${item.id}"
                        "$activeKey:$srcKey"
                    }
                    .distinctBy { it.id }
                state.copy(
                    files = mergedFiles,
                    isSenderReady = sessionActive,
                    senderSessionPhase = if (sessionActive) {
                        if (state.senderSessionPhase == SenderSessionPhase.COMPLETED) SenderSessionPhase.APPROVED_TRANSFERRING else state.senderSessionPhase
                    } else SenderSessionPhase.IDLE,
                    sessionExpiresAtMillis = if (sessionActive) max(state.sessionExpiresAtMillis, System.currentTimeMillis() + 1800_000L) else state.sessionExpiresAtMillis,
                    transferDirection = TransferDirection.SENDING,
                    statusBannerMessage = if (sessionActive) {
                        "تمت إضافة ${addedItems.size} ملفات مباشرة إلى جلسة النقل النشطة دون إيقاف الملفات الحالية!"
                    } else {
                        "تمت إضافة ${addedItems.size} ملفات. اضغط (بدء جلسة الإرسال) لتفعيل الربط للجوال المستلم."
                    }
                )
            }
        }
        syncActiveSenderSessionAfterQueueChange(addedItems)
    }

    private fun syncActiveSenderSessionAfterQueueChange(newlyAddedItems: List<TransferFileItem> = emptyList()) {
        if (newlyAddedItems.isNotEmpty()) {
            newlyAddedItems.forEach {
                cancelledFileIds.remove(it.id)
                pausedFileIds.remove(it.id)
            }
            if (_uiState.value.isSenderReady || _uiState.value.isTransferRunning) {
                transferEngineScope.launch {
                    try {
                        val resolver = getApplication<Application>().contentResolver
                        val maxPreHashBytes = 32L * 1024L * 1024L
                        for (item in newlyAddedItems) {
                            if (!isActive) break
                            if (item.sha256Expected.isBlank() && !item.isDirectory && item.sizeBytes in 1L..maxPreHashBytes) {
                                val sha = runCatching { Sha256Util.computeSha256(resolver, item) }.getOrDefault("")
                                if (sha.isNotBlank()) {
                                    updateFileState(item.id) { it.copy(sha256Expected = sha) }
                                }
                            }
                        }
                        chunkServer?.broadcastSenderPresence()
                    } catch (_: Throwable) {
                    }
                }
            }
        } else if (_uiState.value.isSenderReady || _uiState.value.isTransferRunning) {
            transferEngineScope.launch {
                runCatching { chunkServer?.broadcastSenderPresence() }
            }
        }

        val snap = _uiState.value
        retainedActiveState = if (snap.isSenderReady || snap.isTransferRunning) snap else null
        if (snap.isSenderReady || snap.isTransferRunning) {
            BarqTransferForegroundService.startOrUpdateTransfer(
                context = getApplication(),
                direction = snap.transferDirection,
                currentFileName = snap.activeTransferringFile?.name ?: snap.files.firstOrNull { it.status != FileTransferStatus.CANCELLED }?.name.orEmpty(),
                completedFiles = snap.completedFilesOnlyCount,
                totalFiles = snap.totalFilesOnlyCount,
                transferredBytes = snap.transferredBytes,
                totalBytes = snap.totalBytes,
                speedBytesPerSec = snap.liveOverallSpeedBytesPerSec.toLong(),
                isPaused = snap.isPaused,
                isStandbySession = !snap.isTransferRunning && snap.isSenderReady,
                forceUpdate = true
            )
        }
    }

    fun removeFileItem(fileId: String) = synchronized(transferControlLock) {
        val removedItem = _uiState.value.files.find { it.id == fileId } ?: return
        cancelledFileIds.add(fileId)
        pausedFileIds.remove(fileId)
        senderFileStartNanoMap.remove(fileId)
        senderFileServedBytesMap.remove(fileId)

        _uiState.update { state ->
            val remaining = state.files.filterNot { it.id == fileId }
            val activeBatchIds = remaining.mapNotNull { it.folderBatchId.takeIf { b -> b.isNotBlank() } }.toSet()
            val remainingBatches = state.folderBatches.filter { it.batchId in activeBatchIds }
            if (remaining.isEmpty()) {
                state.copy(
                    files = emptyList(),
                    folderBatches = emptyList(),
                    isSenderReady = false,
                    isTransferRunning = false,
                    isPaused = false,
                    isBackgroundServiceActive = false,
                    liveOverallSpeedBytesPerSec = 0.0,
                    senderSessionPhase = if (state.isSenderReady || state.isTransferRunning) SenderSessionPhase.CANCELLED else SenderSessionPhase.IDLE,
                    statusBannerMessage = "تم حذف «${removedItem.name}» من قائمة الإرسال وإيقاف الجلسة لعدم بقاء ملفات"
                )
            } else {
                val nonCancelled = remaining.filterNot { it.status == FileTransferStatus.CANCELLED }
                val allCompleted = state.isTransferRunning && state.transferDirection == TransferDirection.SENDING &&
                    nonCancelled.isNotEmpty() && nonCancelled.all { it.status == FileTransferStatus.COMPLETED }
                state.copy(
                    files = remaining,
                    folderBatches = remainingBatches,
                    isTransferRunning = if (allCompleted) false else state.isTransferRunning,
                    isBackgroundServiceActive = if (allCompleted) false else state.isBackgroundServiceActive,
                    senderSessionPhase = if (allCompleted) SenderSessionPhase.COMPLETED else state.senderSessionPhase,
                    liveOverallSpeedBytesPerSec = if (allCompleted) 0.0 else state.liveOverallSpeedBytesPerSec,
                    statusBannerMessage = if (state.isSenderReady || state.isTransferRunning) {
                        "تم حذف «${removedItem.name}» من الجلسة النشطة دون التأثير على بقية الملفات"
                    } else state.statusBannerMessage
                )
            }
        }

        if (_uiState.value.files.isEmpty()) {
            sessionTimerJob?.cancel()
            chunkServer?.resetSessionHandshake()
            BarqTransferForegroundService.stopTransferService(getApplication())
            retainedActiveState = null
        } else {
            syncActiveSenderSessionAfterQueueChange()
        }
    }

    /**
     * Pauses or resumes a single file independently without pausing or interrupting
     * other files in the active transfer session.
     */
    fun toggleSingleFilePauseResume(fileId: String) = synchronized(transferControlLock) {
        val current = _uiState.value
        val target = current.files.find { it.id == fileId } ?: return
        if (target.status == FileTransferStatus.COMPLETED ||
            target.status == FileTransferStatus.CANCELLED ||
            fileId in cancelledFileIds
        ) {
            return
        }

        val willPause = fileId !in pausedFileIds &&
            target.status != FileTransferStatus.PAUSED &&
            target.status != FileTransferStatus.FAILED
        if (willPause) {
            pausedFileIds.add(fileId)
        } else {
            pausedFileIds.remove(fileId)
        }

        _uiState.update { state ->
            val updatedFiles = state.files.map { f ->
                if (f.id != fileId || f.status == FileTransferStatus.COMPLETED || f.status == FileTransferStatus.CANCELLED) {
                    f
                } else if (willPause) {
                    f.copy(
                        status = FileTransferStatus.PAUSED,
                        currentSpeedBytesPerSec = 0.0,
                        errorMessage = null
                    )
                } else {
                    val resumedStatus = if (state.isTransferRunning &&
                        state.transferDirection == TransferDirection.SENDING &&
                        f.transferredBytes > 0L
                    ) {
                        FileTransferStatus.TRANSFERRING
                    } else {
                        FileTransferStatus.QUEUED
                    }
                    f.copy(
                        status = resumedStatus,
                        errorMessage = null
                    )
                }
            }
            state.copy(
                files = updatedFiles,
                statusBannerMessage = if (willPause) {
                    "تم إيقاف نقل «${target.name}» مؤقتاً دون التأثير على بقية الملفات"
                } else {
                    "تم استئناف نقل «${target.name}» من موضع التوقف"
                }
            )
        }
        retainedActiveState = _uiState.value

        if (!willPause &&
            _uiState.value.transferDirection == TransferDirection.RECEIVING &&
            !_uiState.value.isTransferRunning &&
            _uiState.value.files.any { it.status != FileTransferStatus.COMPLETED && it.status != FileTransferStatus.CANCELLED }
        ) {
            startLiveChunkedTransfer(TransferDirection.RECEIVING)
        }
    }

    /**
     * Cancels a single file transfer during an active session without stopping the session
     * or affecting remaining or already-completed files.
     */
    fun cancelSingleFileTransfer(fileId: String) = synchronized(transferControlLock) {
        val target = _uiState.value.files.find { it.id == fileId } ?: return
        if (target.status == FileTransferStatus.COMPLETED || target.status == FileTransferStatus.CANCELLED) {
            return
        }
        val wasReceiving = _uiState.value.transferDirection == TransferDirection.RECEIVING
        cancelledFileIds.add(fileId)
        pausedFileIds.remove(fileId)
        senderFileStartNanoMap.remove(fileId)
        senderFileServedBytesMap.remove(fileId)

        _uiState.update { state ->
            val updatedFiles = state.files.map { f ->
                if (f.id == fileId && f.status != FileTransferStatus.COMPLETED) {
                    f.copy(
                        status = FileTransferStatus.CANCELLED,
                        currentSpeedBytesPerSec = 0.0,
                        errorMessage = "تم إلغاء نقل هذا الملف"
                    )
                } else f
            }
            val nonCancelled = updatedFiles.filterNot { it.status == FileTransferStatus.CANCELLED }
            val senderAllDone = state.transferDirection == TransferDirection.SENDING && state.isTransferRunning &&
                (nonCancelled.isEmpty() || nonCancelled.all { it.status == FileTransferStatus.COMPLETED })
            state.copy(
                files = updatedFiles,
                isTransferRunning = if (senderAllDone) false else state.isTransferRunning,
                isBackgroundServiceActive = if (senderAllDone && !state.isSenderReady) false else state.isBackgroundServiceActive,
                senderSessionPhase = if (senderAllDone && nonCancelled.isNotEmpty()) SenderSessionPhase.COMPLETED else state.senderSessionPhase,
                liveOverallSpeedBytesPerSec = if (senderAllDone) 0.0 else state.liveOverallSpeedBytesPerSec,
                statusBannerMessage = "تم إلغاء نقل «${target.name}» مع استمرار بقية الملفات بشكل طبيعي"
            )
        }
        syncActiveSenderSessionAfterQueueChange()

        if (wasReceiving) {
            val safeIdSuffix = fileId.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "item" }
            transferEngineScope.launch(Dispatchers.IO) {
                runCatching {
                    val downloadDir = resolveBarqSherDownloadsDir(getApplication())
                    if (downloadDir.exists()) {
                        downloadDir.walkTopDown()
                            .filter { it.isFile && it.name.endsWith(".$safeIdSuffix.part") }
                            .forEach { partFile -> runCatching { partFile.delete() } }
                    }
                }
            }
        }
    }

    /**
     * Retries a single failed file independently without re-transferring already completed files.
     * Preserves any valid `.part` progress on disk so the transfer resumes from the exact byte offset.
     */
    fun retrySingleFailedFile(fileId: String) = synchronized(transferControlLock) {
        val current = _uiState.value
        val target = current.files.find { it.id == fileId } ?: return
        if (target.status == FileTransferStatus.COMPLETED) return

        cancelledFileIds.remove(fileId)
        pausedFileIds.remove(fileId)

        _uiState.update { state ->
            val updatedFiles = state.files.map { f ->
                if (f.id != fileId || f.status == FileTransferStatus.COMPLETED) {
                    f
                } else {
                    f.copy(
                        status = FileTransferStatus.QUEUED,
                        currentSpeedBytesPerSec = 0.0,
                        retryCount = f.retryCount + 1,
                        errorMessage = null,
                        failureDiagnosticCode = null
                    )
                }
            }
            state.copy(
                files = updatedFiles,
                statusBannerMessage = "جاري إعادة محاولة نقل «${target.name}» من آخر إزاحة صالحة دون إعادة الملفات المكتملة"
            )
        }
        retainedActiveState = _uiState.value

        if (_uiState.value.transferDirection == TransferDirection.RECEIVING) {
            if (!_uiState.value.isTransferRunning) {
                startLiveChunkedTransfer(TransferDirection.RECEIVING)
            }
        } else {
            syncActiveSenderSessionAfterQueueChange(listOf(target))
        }
    }

    /**
     * Retries all failed files in the current session while keeping completed files untouched.
     */
    fun retryAllFailedFiles() = synchronized(transferControlLock) {
        val failedIds = _uiState.value.files
            .filter { it.status == FileTransferStatus.FAILED }
            .map { it.id }
            .toSet()
        if (failedIds.isEmpty()) return

        failedIds.forEach { id ->
            cancelledFileIds.remove(id)
            pausedFileIds.remove(id)
        }

        _uiState.update { state ->
            val updatedFiles = state.files.map { f ->
                if (f.id in failedIds) {
                    f.copy(
                        status = FileTransferStatus.QUEUED,
                        currentSpeedBytesPerSec = 0.0,
                        retryCount = f.retryCount + 1,
                        errorMessage = null,
                        failureDiagnosticCode = null
                    )
                } else f
            }
            state.copy(
                files = updatedFiles,
                statusBannerMessage = "جاري إعادة محاولة ${failedIds.size} ملفات متوقفة من آخر موضع صالح (.part)"
            )
        }
        retainedActiveState = _uiState.value

        if (_uiState.value.transferDirection == TransferDirection.RECEIVING && !_uiState.value.isTransferRunning) {
            startLiveChunkedTransfer(TransferDirection.RECEIVING)
        } else if (_uiState.value.transferDirection == TransferDirection.SENDING) {
            syncActiveSenderSessionAfterQueueChange()
        }
    }

    fun clearAllFiles() = synchronized(transferControlLock) {
        activeTransferJob?.cancel()
        retainedTransferJob = null
        sessionTimerJob?.cancel()
        chunkServer?.resetSessionHandshake()
        cancelledFileIds.clear()
        pausedFileIds.clear()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()
        senderSessionServedBytes.set(0L)
        BarqTransferForegroundService.stopTransferService(getApplication())
        _uiState.update {
            it.copy(
                files = emptyList(),
                folderBatches = emptyList(),
                isSenderReady = false,
                senderSessionPhase = SenderSessionPhase.IDLE,
                incomingConnectionRequest = null,
                isTransferRunning = false,
                isPaused = false,
                isBackgroundServiceActive = false,
                liveOverallSpeedBytesPerSec = 0.0
            )
        }
        retainedActiveState = null
    }

    /**
     * Starts an authenticated local Send Session with QR Code, Pairing Code, Session ID,
     * 10-minute expiration countdown, and Sender Approval requirement.
     * Also activates BarqTransferForegroundService so the sender server stays alive when the screen turns off.
     */
    fun startSendSession(navigateToLiveScreen: Boolean = false): Unit = synchronized(transferControlLock) {
        if (_uiState.value.files.isEmpty()) {
            _uiState.update {
                it.copy(
                    statusBannerMessage = "الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال"
                )
            }
            return@synchronized
        }

        val nowElapsed = android.os.SystemClock.elapsedRealtime()
        if (_uiState.value.isSenderReady &&
            _uiState.value.isPreparingHashes &&
            nowElapsed > lastStartSendSessionElapsedMs &&
            (nowElapsed - lastStartSendSessionElapsedMs) < 350L
        ) {
            if (navigateToLiveScreen) {
                _uiState.update { it.copy(currentScreen = AppScreen.LIVE_TRANSFER) }
            }
            return@synchronized
        }
        lastStartSendSessionElapsedMs = nowElapsed

        activeTransferJob?.cancel()
        retainedTransferJob = null
        sessionTimerJob?.cancel()
        chunkServer?.resetSessionHandshake()
        cancelledFileIds.clear()
        pausedFileIds.clear()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()
        senderSessionStartNano = 0L
        senderSessionServedBytes.set(0L)

        val chunkBytes = _uiState.value.selectedChunkSize.bytes
        val newSessionId = "SES-${UUID.randomUUID().toString().take(6).uppercase(Locale.US)}"
        val ttlSeconds = 600
        val expiresAt = System.currentTimeMillis() + ttlSeconds * 1000L

        _uiState.update { state ->
            val resetFiles = state.files.map { f ->
                val totalChunks = computeTotalChunksForSize(f.sizeBytes, chunkBytes)
                f.copy(
                    totalChunks = totalChunks,
                    completedChunks = 0,
                    transferredBytes = 0L,
                    currentSpeedBytesPerSec = 0.0,
                    status = FileTransferStatus.QUEUED
                )
            }
            state.copy(
                currentScreen = if (navigateToLiveScreen) AppScreen.LIVE_TRANSFER else state.currentScreen,
                transferDirection = TransferDirection.SENDING,
                sessionId = newSessionId,
                sessionExpiresAtMillis = expiresAt,
                sessionRemainingSeconds = ttlSeconds,
                senderSessionPhase = SenderSessionPhase.PREPARING_FILES,
                incomingConnectionRequest = null,
                isSenderReady = true,
                isPreparingHashes = true,
                files = resetFiles,
                isTransferRunning = false,
                isPaused = false,
                isBackgroundServiceActive = true,
                liveOverallSpeedBytesPerSec = 0.0,
                connectedPeerLabel = "جاري تجهيز البصمات الرقمية SHA-256 وتفعيل جلسة الإرسال ($newSessionId)...",
                statusBannerMessage = "تم بدء جلسة الإرسال (${state.connectionCode}). امسح رمز QR من الجهاز المستلم ثم وافق على طلب الاتصال لبدء النقل."
            )
        }
        retainedActiveState = _uiState.value

        BarqTransferForegroundService.startOrUpdateTransfer(
            context = getApplication(),
            direction = TransferDirection.SENDING,
            currentFileName = _uiState.value.files.firstOrNull()?.name ?: "",
            completedFiles = 0,
            totalFiles = _uiState.value.totalFilesOnlyCount,
            transferredBytes = 0L,
            totalBytes = _uiState.value.totalBytes,
            speedBytesPerSec = 0L,
            isStandbySession = true,
            forceUpdate = true
        )

        // Start session expiration countdown timer (10 minutes TTL while awaiting receiver; never expires during active transfer)
        sessionTimerJob = transferEngineScope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(1000L)
                val phase = _uiState.value.senderSessionPhase
                if (phase == SenderSessionPhase.APPROVED_TRANSFERRING || _uiState.value.isTransferRunning) {
                    // Keep extending session while actively transferring large multi-GB files
                    val extendedExpiry = max(_uiState.value.sessionExpiresAtMillis, System.currentTimeMillis() + 1800_000L)
                    _uiState.update {
                        it.copy(
                            sessionExpiresAtMillis = extendedExpiry,
                            sessionRemainingSeconds = ((extendedExpiry - System.currentTimeMillis()) / 1000L).toInt().coerceAtLeast(600)
                        )
                    }
                    continue
                }
                val remMillis = _uiState.value.sessionExpiresAtMillis - System.currentTimeMillis()
                val remSecs = (remMillis / 1000L).toInt().coerceAtLeast(0)
                if (remSecs <= 0 && (phase == SenderSessionPhase.AWAITING_RECEIVER || phase == SenderSessionPhase.CONNECTION_REQUESTED || phase == SenderSessionPhase.PREPARING_FILES)) {
                    chunkServer?.resetSessionHandshake()
                    BarqTransferForegroundService.stopTransferService(getApplication())
                    _uiState.update {
                        it.copy(
                            isSenderReady = false,
                            isBackgroundServiceActive = false,
                            sessionRemainingSeconds = 0,
                            senderSessionPhase = SenderSessionPhase.EXPIRED,
                            incomingConnectionRequest = null,
                            connectedPeerLabel = "انتهت صلاحية جلسة الإرسال لعدم اتصال مستلم خلال المهلة المحددة",
                            statusBannerMessage = "انتهت صلاحية جلسة الإرسال. اضغط (بدء جلسة الإرسال) لإنشاء جلسة جديدة."
                        )
                    }
                    retainedActiveState = _uiState.value
                    break
                } else {
                    _uiState.update { it.copy(sessionRemainingSeconds = remSecs) }
                }
            }
        }

        // Start Bluetooth RFCOMM server alongside HTTP/UDP so nearby devices can pair/exchange handshake or stream via Bluetooth
        bluetoothManager?.startRfcommServer(
            localIpProvider = { _uiState.value.networkStatus.localIp },
            localPortProvider = { _uiState.value.networkStatus.port },
            sessionCodeProvider = { _uiState.value.connectionCode },
            sessionIdProvider = { _uiState.value.sessionId },
            filesProvider = { _uiState.value.files },
            onBytesServed = { fileId, bytesCount ->
                val chunkBytesNow = _uiState.value.selectedChunkSize.bytes.toLong().coerceAtLeast(1L)
                val item = _uiState.value.files.find { it.id == fileId }
                val newServed = (senderFileServedBytesMap[fileId] ?: 0L) + bytesCount
                val approxChunkIdx = (((newServed + chunkBytesNow - 1L) / chunkBytesNow).coerceIn(1L, Int.MAX_VALUE.toLong()).toInt()) - 1
                onRemotePeerPulledChunk(
                    fileId = fileId,
                    chunkIdx = approxChunkIdx.coerceAtMost((item?.totalChunks ?: 1) - 1),
                    bytesCount = bytesCount.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                )
            }
        )

        // Compute SHA-256 hashes in background for small/medium files (<= 32 MB) and broadcast UDP presence immediately.
        // Files > 32 MB (such as 3 GB – 40 GB videos) are hashed on-the-fly during streaming so session startup never lags.
        transferEngineScope.launch {
            try {
                chunkServer?.broadcastSenderPresence()
                val resolver = getApplication<Application>().contentResolver
                val currentFiles = _uiState.value.files
                val maxPreHashBytes = 32L * 1024L * 1024L
                for (item in currentFiles) {
                    if (!isActive) break
                    if (item.sha256Expected.isBlank() && !item.isDirectory && item.sizeBytes in 1L..maxPreHashBytes) {
                        val sha = runCatching { Sha256Util.computeSha256(resolver, item) }.getOrDefault("")
                        updateFileState(item.id) { it.copy(sha256Expected = sha) }
                    }
                }
                chunkServer?.broadcastSenderPresence()
            } catch (t: Throwable) {
                android.util.Log.e(LOG_TAG, "Error preparing hashes in startSendSession: ${t.message}")
            }
            _uiState.update { state ->
                val nextPhase = if (state.incomingConnectionRequest != null) {
                    SenderSessionPhase.CONNECTION_REQUESTED
                } else if (state.senderSessionPhase == SenderSessionPhase.PREPARING_FILES) {
                    SenderSessionPhase.AWAITING_RECEIVER
                } else {
                    state.senderSessionPhase
                }
                state.copy(
                    isPreparingHashes = false,
                    senderSessionPhase = nextPhase,
                    connectedPeerLabel = if (state.incomingConnectionRequest != null) {
                        "طلب اتصال وارد من «${state.incomingConnectionRequest.clientDeviceName}» — بانتظار موافقتك"
                    } else {
                        "الجلسة نشطة (${state.connectionCode}) • بانتظار اتصال المستلم عبر الواي فاي أو البلوتوث..."
                    }
                )
            }
            retainedActiveState = _uiState.value
        }
        Unit
    }

    private fun onReceiverRequestedConnection(req: IncomingConnectionRequest) {
        _uiState.update { state ->
            state.copy(
                incomingConnectionRequest = req,
                senderSessionPhase = SenderSessionPhase.CONNECTION_REQUESTED,
                connectedPeerLabel = "طلب اتصال وارد من «${req.clientDeviceName}» (${req.clientIp}) — بانتظار موافقتك",
                statusBannerMessage = "الجهاز «${req.clientDeviceName}» يطلب الاتصال لاستلام الملفات. اضغط (موافقة وبدء النقل) للسماح له."
            )
        }
        retainedActiveState = _uiState.value
    }

    /**
     * Sender explicitly approves the Receiver's incoming connection request, issuing an authorization
     * token and transitioning both devices to active transfer.
     */
    fun approveIncomingConnectionRequest() {
        val req = _uiState.value.incomingConnectionRequest
        chunkServer?.approvePendingConnectionRequest()
        val extendedExpiry = System.currentTimeMillis() + 1800_000L
        _uiState.update { state ->
            state.copy(
                incomingConnectionRequest = null,
                sessionExpiresAtMillis = extendedExpiry,
                senderSessionPhase = SenderSessionPhase.APPROVED_TRANSFERRING,
                currentScreen = AppScreen.LIVE_TRANSFER,
                isTransferRunning = true,
                isBackgroundServiceActive = true,
                connectedPeerLabel = "تمت الموافقة على اتصال «${req?.clientDeviceName ?: "المستلم"}» • جاري النقل المباشر...",
                statusBannerMessage = "تمت الموافقة على طلب الاتصال وبدأ النقل المباشر!"
            )
        }
        retainedActiveState = _uiState.value
        val s = _uiState.value
        BarqTransferForegroundService.startOrUpdateTransfer(
            context = getApplication(),
            direction = TransferDirection.SENDING,
            currentFileName = s.activeTransferringFile?.name ?: s.files.firstOrNull()?.name.orEmpty(),
            completedFiles = s.completedFilesOnlyCount,
            totalFiles = s.totalFilesOnlyCount,
            transferredBytes = s.transferredBytes,
            totalBytes = s.totalBytes,
            speedBytesPerSec = 0L,
            forceUpdate = true
        )
    }

    /**
     * Sender rejects the Receiver's incoming connection request.
     */
    fun rejectIncomingConnectionRequest() {
        val req = _uiState.value.incomingConnectionRequest
        chunkServer?.rejectPendingConnectionRequest()
        _uiState.update { state ->
            state.copy(
                incomingConnectionRequest = null,
                senderSessionPhase = SenderSessionPhase.AWAITING_RECEIVER,
                connectedPeerLabel = "تم رفض طلب «${req?.clientDeviceName ?: "المستلم"}» • بانتظار اتصال جهاز مستلم...",
                statusBannerMessage = "تم رفض طلب الاتصال من الجهاز الآخر."
            )
        }
        retainedActiveState = _uiState.value
    }

    /**
     * Stops the active Send session, invalidates tokens, and cleans up resources.
     */
    fun stopSendSession() = synchronized(transferControlLock) {
        _uiState.value.files
            .filter { it.status != FileTransferStatus.COMPLETED }
            .forEach { cancelledFileIds.add(it.id) }
        pausedFileIds.clear()
        sessionTimerJob?.cancel()
        activeTransferJob?.cancel()
        retainedTransferJob = null
        chunkServer?.resetSessionHandshake()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()
        BarqTransferForegroundService.stopTransferService(getApplication())
        _uiState.update { state ->
            state.copy(
                isSenderReady = false,
                isPreparingHashes = false,
                isTransferRunning = false,
                isPaused = false,
                isBackgroundServiceActive = false,
                liveOverallSpeedBytesPerSec = 0.0,
                senderSessionPhase = SenderSessionPhase.CANCELLED,
                incomingConnectionRequest = null,
                connectedPeerLabel = "تم إيقاف جلسة الإرسال وإلغاء صلاحية الرمز",
                statusBannerMessage = "تم إيقاف جلسة الإرسال بنجاح."
            )
        }
        retainedActiveState = null
    }

    /**
     * Cancels the active transfer session, cleans up only temporary .part files (preserving all completed files),
     * and updates state without crashing or closing the app.
     */
    fun cancelActiveTransfer() = synchronized(transferControlLock) {
        val currentState = _uiState.value
        val currentFiles = currentState.files
        val wasReceiving = currentState.transferDirection == TransferDirection.RECEIVING
        currentFiles
            .filter { it.status != FileTransferStatus.COMPLETED }
            .forEach { cancelledFileIds.add(it.id) }
        pausedFileIds.clear()

        activeTransferJob?.cancel()
        retainedTransferJob = null
        sessionTimerJob?.cancel()
        approvalPollingJob?.cancel()
        chunkServer?.resetSessionHandshake()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()
        senderSessionServedBytes.set(0L)
        BarqTransferForegroundService.stopTransferService(getApplication())
        _uiState.update { state ->
            val updatedFiles = state.files.map { f ->
                if (f.status == FileTransferStatus.COMPLETED) {
                    // Never alter or delete already completed files
                    f.copy(currentSpeedBytesPerSec = 0.0)
                } else {
                    f.copy(status = FileTransferStatus.CANCELLED, currentSpeedBytesPerSec = 0.0)
                }
            }
            state.copy(
                isSenderReady = false,
                isPreparingHashes = false,
                senderSessionPhase = SenderSessionPhase.CANCELLED,
                receiverConnectionPhase = ReceiverConnectionPhase.IDLE,
                incomingConnectionRequest = null,
                isTransferRunning = false,
                isPaused = false,
                isBackgroundServiceActive = false,
                liveOverallSpeedBytesPerSec = 0.0,
                files = updatedFiles,
                connectedPeerLabel = "تم إلغاء جلسة النقل مع الاحتفاظ بجميع الملفات المكتملة",
                statusBannerMessage = "تم إلغاء جلسة النقل بنجاح دون المساس بالملفات المكتملة"
            )
        }
        retainedActiveState = null

        if (wasReceiving) {
            transferEngineScope.launch(Dispatchers.IO) {
                runCatching {
                    val downloadDir = resolveBarqSherDownloadsDir(getApplication())
                    if (downloadDir.exists()) {
                        downloadDir.walkTopDown()
                            .filter { it.isFile && it.name.endsWith(".part") }
                            .forEach { partFile -> runCatching { partFile.delete() } }
                    }
                }
            }
        }
    }

    private fun onRemotePeerPulledChunk(fileId: String, chunkIdx: Int, bytesCount: Int) {
        if (fileId in cancelledFileIds || !_uiState.value.isSenderReady) return
        val nowNano = System.nanoTime()
        if (senderSessionStartNano == 0L) {
            senderSessionStartNano = nowNano
        }
        val startNano = senderFileStartNanoMap.getOrPut(fileId) { nowNano }
        val totalServedForFile = (senderFileServedBytesMap[fileId] ?: 0L) + bytesCount.toLong()
        senderFileServedBytesMap[fileId] = totalServedForFile
        val sessionTotalBytes = senderSessionServedBytes.addAndGet(bytesCount.toLong())

        val fileElapsedSec = max(0.002, (nowNano - startNano) / 1_000_000_000.0)
        val fileSpeedBytesPerSec = totalServedForFile.toDouble() / fileElapsedSec
        val sessionElapsedSec = max(0.002, (nowNano - senderSessionStartNano) / 1_000_000_000.0)
        val sessionAvgSpeedBytesPerSec = sessionTotalBytes.toDouble() / sessionElapsedSec
        val overallSpeedBytesPerSec = max(fileSpeedBytesPerSec, sessionAvgSpeedBytesPerSec)

        val currentItem = _uiState.value.files.find { it.id == fileId } ?: return
        if (currentItem.status == FileTransferStatus.CANCELLED) return
        val newBytes = minOf(currentItem.sizeBytes, totalServedForFile)
        val isDone = currentItem.isDirectory || currentItem.sizeBytes == 0L || newBytes >= currentItem.sizeBytes
        val maxInProgressChunks = if (isDone) currentItem.totalChunks else (currentItem.totalChunks - 1).coerceAtLeast(0)
        val newCompleted = max(currentItem.completedChunks, chunkIdx + 1).coerceAtMost(maxInProgressChunks)

        // Throttle intermediate UI StateFlow updates to ~45ms to eliminate CPU/recomposition overhead during high-speed streaming
        if (!isDone && (nowNano - lastSenderUiUpdateNano) < 45_000_000L) {
            return
        }
        lastSenderUiUpdateNano = nowNano

        var newlyCompletedItem: TransferFileItem? = null

        _uiState.update { state ->
            val updated = state.files.map { item ->
                if (item.id != fileId || item.status == FileTransferStatus.CANCELLED) item
                else {
                    val isSinglePaused = fileId in pausedFileIds
                    val isImmediateComplete = item.isDirectory || item.sizeBytes == 0L
                    val nextStatus = when {
                        item.status == FileTransferStatus.COMPLETED -> FileTransferStatus.COMPLETED
                        isDone && isImmediateComplete -> FileTransferStatus.COMPLETED
                        isDone -> FileTransferStatus.VERIFYING
                        state.isPaused || isSinglePaused -> FileTransferStatus.PAUSED
                        else -> FileTransferStatus.TRANSFERRING
                    }
                    val updatedItem = item.copy(
                        completedChunks = if (isDone) item.totalChunks else newCompleted,
                        transferredBytes = if (isDone) item.sizeBytes else newBytes,
                        status = nextStatus,
                        currentSpeedBytesPerSec = if (isDone || state.isPaused || isSinglePaused) 0.0 else fileSpeedBytesPerSec,
                        sha256Verified = if (nextStatus == FileTransferStatus.COMPLETED) true else item.sha256Verified
                    )
                    if (nextStatus == FileTransferStatus.COMPLETED && item.status != FileTransferStatus.COMPLETED) {
                        newlyCompletedItem = updatedItem
                    }
                    updatedItem
                }
            }
            val nonCancelled = updated.filterNot { it.status == FileTransferStatus.CANCELLED }
            val allCompleted = nonCancelled.isNotEmpty() && nonCancelled.all { it.status == FileTransferStatus.COMPLETED }
            state.copy(
                files = updated,
                sessionExpiresAtMillis = max(state.sessionExpiresAtMillis, System.currentTimeMillis() + 1800_000L),
                isTransferRunning = !allCompleted,
                isBackgroundServiceActive = !allCompleted,
                senderSessionPhase = if (allCompleted) SenderSessionPhase.COMPLETED else SenderSessionPhase.APPROVED_TRANSFERRING,
                connectedPeerLabel = if (allCompleted) {
                    "اكتمل إرسال جميع الملفات والمجلدات للمستلم بنجاح"
                } else {
                    "متصل بالجهاز المستلم • جاري التدفق المباشر بأقصى سرعة تلقائية (Auto Max)"
                },
                liveOverallSpeedBytesPerSec = if (allCompleted || state.isPaused) 0.0 else overallSpeedBytesPerSec,
                averageSpeedBytesPerSec = sessionAvgSpeedBytesPerSec,
                peakSpeedBytesPerSec = max(state.peakSpeedBytesPerSec, overallSpeedBytesPerSec),
                statusBannerMessage = if (allCompleted) {
                    "اكتمل إرسال جميع الملفات والمجلدات إلى الجهاز المستلم بنجاح!"
                } else {
                    state.statusBannerMessage
                }
            )
        }

        val currentState = _uiState.value
        retainedActiveState = currentState
        if (!currentState.isTransferRunning) {
            BarqTransferForegroundService.stopTransferService(getApplication())
        } else {
            BarqTransferForegroundService.startOrUpdateTransfer(
                context = getApplication(),
                direction = TransferDirection.SENDING,
                currentFileName = currentItem.name,
                completedFiles = currentState.completedFilesOnlyCount,
                totalFiles = currentState.totalFilesOnlyCount,
                transferredBytes = currentState.transferredBytes,
                totalBytes = currentState.totalBytes,
                speedBytesPerSec = if (currentState.isPaused) 0L else overallSpeedBytesPerSec.toLong(),
                isPaused = currentState.isPaused,
                forceUpdate = isDone
            )
        }

        newlyCompletedItem?.let { completed ->
            if (!completed.isDirectory) {
                recordHistoryItem(
                    item = completed,
                    direction = TransferDirection.SENDING,
                    peerAddress = "Receiver",
                    avgSpeedBytesPerSec = overallSpeedBytesPerSec
                )
            }
        }
    }

    fun startLiveChunkedTransfer(direction: TransferDirection) = synchronized(transferControlLock) {
        if (direction == TransferDirection.SENDING) {
            startSendSession(navigateToLiveScreen = false)
            return
        }

        if (_uiState.value.files.isEmpty()) {
            _uiState.update {
                it.copy(
                    statusBannerMessage = "الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال"
                )
            }
            return
        }

        val nowElapsed = android.os.SystemClock.elapsedRealtime()
        if (_uiState.value.isTransferRunning &&
            _uiState.value.transferDirection == TransferDirection.RECEIVING &&
            activeTransferJob?.isActive == true &&
            nowElapsed > lastStartReceiveSessionElapsedMs &&
            (nowElapsed - lastStartReceiveSessionElapsedMs) < 350L
        ) {
            return
        }
        lastStartReceiveSessionElapsedMs = nowElapsed

        activeTransferJob?.cancel()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()
        senderSessionStartNano = 0L
        senderSessionServedBytes.set(0L)

        // RECEIVING direction: preserve any partial progress (.part bytes / completedChunks) so resume continues from where it stopped
        _uiState.update { state ->
            val nonCompleted = state.files.filter { it.status != FileTransferStatus.COMPLETED }
            val allWereCancelled = nonCompleted.isNotEmpty() && nonCompleted.all { it.status == FileTransferStatus.CANCELLED }
            if (allWereCancelled) {
                cancelledFileIds.clear()
                pausedFileIds.clear()
            } else {
                state.files.forEach { f ->
                    if (f.status != FileTransferStatus.CANCELLED) {
                        cancelledFileIds.remove(f.id)
                    }
                }
            }
            val resetFiles = state.files.map { f ->
                when {
                    f.status == FileTransferStatus.COMPLETED -> f
                    !allWereCancelled && f.status == FileTransferStatus.CANCELLED && f.id in cancelledFileIds -> f
                    f.id in pausedFileIds -> f.copy(status = FileTransferStatus.PAUSED, currentSpeedBytesPerSec = 0.0)
                    f.transferredBytes in 1L until f.sizeBytes || f.completedChunks in 1 until f.totalChunks -> {
                        f.copy(status = FileTransferStatus.QUEUED, currentSpeedBytesPerSec = 0.0, errorMessage = null)
                    }
                    else -> {
                        f.copy(
                            completedChunks = 0,
                            transferredBytes = 0L,
                            currentSpeedBytesPerSec = 0.0,
                            status = FileTransferStatus.QUEUED,
                            errorMessage = null
                        )
                    }
                }
            }
            state.copy(
                currentScreen = AppScreen.LIVE_TRANSFER,
                transferDirection = TransferDirection.RECEIVING,
                receiverConnectionPhase = ReceiverConnectionPhase.APPROVED_RECEIVING,
                files = resetFiles,
                isTransferRunning = true,
                isPaused = false,
                isBackgroundServiceActive = true,
                liveOverallSpeedBytesPerSec = 0.0,
                connectedPeerLabel = "متصل بالمرسل «${state.remoteSenderDeviceName.ifBlank { state.remoteHostIp }}» (${state.remoteHostIp}:${state.remoteHostPort} • ${state.remoteSessionCode})"
            )
        }
        retainedActiveState = _uiState.value

        val initialState = _uiState.value
        BarqTransferForegroundService.startOrUpdateTransfer(
            context = getApplication(),
            direction = TransferDirection.RECEIVING,
            currentFileName = initialState.activeTransferringFile?.name ?: initialState.files.firstOrNull()?.name.orEmpty(),
            completedFiles = initialState.completedFilesOnlyCount,
            totalFiles = initialState.totalFilesOnlyCount,
            transferredBytes = initialState.transferredBytes,
            totalBytes = initialState.totalBytes,
            speedBytesPerSec = 0L,
            forceUpdate = true
        )

        activeTransferJob = transferEngineScope.launch {
            val appContext = getApplication<Application>().applicationContext
            val hostIp = _uiState.value.remoteHostIp
            val hostPort = _uiState.value.remoteHostPort
            val sessionCode = _uiState.value.remoteSessionCode
            val authToken = _uiState.value.remoteAuthToken
            val chunkSizeBytes = _uiState.value.remoteChunkSizeBytes
            val btAddress = _uiState.value.connectedBluetoothAddress
            val mode = _uiState.value.transportMode
            val downloadDir = resolveBarqSherDownloadsDir(appContext)

            val useBluetoothDirect = (mode == TransportMode.BLUETOOTH_DIRECT && btAddress.isNotBlank()) ||
                (hostIp.isBlank() && btAddress.isNotBlank())

            try {
                val anyFailed = if (useBluetoothDirect) {
                    bluetoothManager?.executeDirectBluetoothReceiveSession(
                        peerAddress = btAddress,
                        downloadDir = downloadDir,
                        itemsProvider = { _uiState.value.files },
                        isPausedProvider = { _uiState.value.isPaused },
                        onFileUpdated = { fileId, currentSpeed, sessionSpeed, transform ->
                            if (!isActive || !_uiState.value.isTransferRunning) return@executeDirectBluetoothReceiveSession
                            val topSpeed = max(currentSpeed, sessionSpeed)
                            _uiState.update { state ->
                                val updatedFiles = state.files.map { f ->
                                    if (f.id == fileId) transform(f) else f
                                }
                                state.copy(
                                    files = updatedFiles,
                                    liveOverallSpeedBytesPerSec = if (state.isPaused) 0.0 else topSpeed,
                                    averageSpeedBytesPerSec = if (sessionSpeed > 0.0) sessionSpeed else state.averageSpeedBytesPerSec,
                                    peakSpeedBytesPerSec = max(state.peakSpeedBytesPerSec, topSpeed)
                                )
                            }
                            val snap = _uiState.value
                            retainedActiveState = snap
                            if (snap.isTransferRunning) {
                                BarqTransferForegroundService.startOrUpdateTransfer(
                                    context = appContext,
                                    direction = TransferDirection.RECEIVING,
                                    currentFileName = snap.activeTransferringFile?.name.orEmpty(),
                                    completedFiles = snap.completedFilesOnlyCount,
                                    totalFiles = snap.totalFilesOnlyCount,
                                    transferredBytes = snap.transferredBytes,
                                    totalBytes = snap.totalBytes,
                                    speedBytesPerSec = if (snap.isPaused) 0L else topSpeed.toLong(),
                                    isPaused = snap.isPaused
                                )
                            }
                        },
                        onFileCompleted = { completedItem, avgSpeed ->
                            if (!completedItem.isDirectory) {
                                recordHistoryItem(
                                    item = completedItem,
                                    direction = TransferDirection.RECEIVING,
                                    peerAddress = "BT:$btAddress",
                                    avgSpeedBytesPerSec = avgSpeed
                                )
                            }
                        },
                        onFileFailed = { failedItem, errMsg ->
                            recordHistoryItem(
                                item = failedItem,
                                direction = TransferDirection.RECEIVING,
                                peerAddress = "BT:$btAddress",
                                avgSpeedBytesPerSec = 0.0,
                                errorMessage = errMsg
                            )
                        }
                    ) ?: true
                } else {
                    executeHighSpeedReceiveSession(
                        hostIp = hostIp,
                        hostPort = hostPort,
                        sessionCode = sessionCode,
                        authToken = authToken,
                        chunkSizeBytes = chunkSizeBytes,
                        downloadDir = downloadDir,
                        itemsProvider = { _uiState.value.files },
                        isPausedProvider = { _uiState.value.isPaused },
                        isFileCancelledProvider = { fileId -> fileId in cancelledFileIds },
                        isFilePausedProvider = { fileId -> fileId in pausedFileIds },
                        onNewFilesDiscovered = { discoveredItems ->
                            if (discoveredItems.isNotEmpty() && isActive && _uiState.value.isTransferRunning) {
                                _uiState.update { state ->
                                    val existingIds = state.files.map { it.id }.toSet()
                                    val brandNew = discoveredItems.filter { it.id !in existingIds && it.id !in cancelledFileIds }
                                    if (brandNew.isEmpty()) state
                                    else state.copy(
                                        files = state.files + brandNew,
                                        statusBannerMessage = "أضاف المرسِل ${brandNew.size} ملفات جديدة للجلسة — جاري استلامها تلقائياً"
                                    )
                                }
                                retainedActiveState = _uiState.value
                            }
                        },
                        onFileUpdated = { fileId, currentSpeed, sessionSpeed, transform ->
                            if (!isActive || !_uiState.value.isTransferRunning) return@executeHighSpeedReceiveSession
                            val topSpeed = max(currentSpeed, sessionSpeed)
                            _uiState.update { state ->
                                val updatedFiles = state.files.map { f ->
                                    if (f.id == fileId) transform(f) else f
                                }
                                state.copy(
                                    files = updatedFiles,
                                    liveOverallSpeedBytesPerSec = if (state.isPaused) 0.0 else topSpeed,
                                    averageSpeedBytesPerSec = if (sessionSpeed > 0.0) sessionSpeed else state.averageSpeedBytesPerSec,
                                    peakSpeedBytesPerSec = max(state.peakSpeedBytesPerSec, topSpeed)
                                )
                            }
                            val snap = _uiState.value
                            retainedActiveState = snap
                            if (snap.isTransferRunning) {
                                BarqTransferForegroundService.startOrUpdateTransfer(
                                    context = appContext,
                                    direction = TransferDirection.RECEIVING,
                                    currentFileName = snap.activeTransferringFile?.name.orEmpty(),
                                    completedFiles = snap.completedFilesOnlyCount,
                                    totalFiles = snap.totalFilesOnlyCount,
                                    transferredBytes = snap.transferredBytes,
                                    totalBytes = snap.totalBytes,
                                    speedBytesPerSec = if (snap.isPaused) 0L else topSpeed.toLong(),
                                    isPaused = snap.isPaused
                                )
                            }
                        },
                        onFileCompleted = { completedItem, avgSpeed ->
                            if (!completedItem.isDirectory) {
                                recordHistoryItem(
                                    item = completedItem,
                                    direction = TransferDirection.RECEIVING,
                                    peerAddress = "$hostIp:$hostPort",
                                    avgSpeedBytesPerSec = avgSpeed
                                )
                            }
                        },
                        onFileFailed = { failedItem, errMsg ->
                            recordHistoryItem(
                                item = failedItem,
                                direction = TransferDirection.RECEIVING,
                                peerAddress = "$hostIp:$hostPort",
                                avgSpeedBytesPerSec = 0.0,
                                errorMessage = errMsg
                            )
                        }
                    )
                }

                if (!isActive) return@launch
                BarqTransferForegroundService.stopTransferService(appContext)
                withContext(Dispatchers.Main) {
                    _uiState.update { state ->
                        val failedFiles = state.files.filter { it.status == FileTransferStatus.FAILED }
                        val firstFailureMsg = failedFiles.firstOrNull()?.errorMessage
                        state.copy(
                            isTransferRunning = false,
                            isPaused = false,
                            isBackgroundServiceActive = false,
                            receiverConnectionPhase = if (anyFailed) ReceiverConnectionPhase.FAILED else ReceiverConnectionPhase.COMPLETED,
                            liveOverallSpeedBytesPerSec = 0.0,
                            statusBannerMessage = if (anyFailed) {
                                firstFailureMsg ?: "تعذر إكمال بعض الملفات (${failedFiles.size}). تم الاحتفاظ بالملفات المكتملة والأجزاء الصالحة (.part)؛ يمكنك إعادة المحاولة."
                            } else {
                                "اكتمل استلام جميع الملفات والمجلدات ببنيتها الكاملة والتحقق من سلامتها (SHA-256) في (Downloads/BarqSher)!"
                            }
                        )
                    }
                    retainedActiveState = _uiState.value
                    loadAllDeviceMediaAndFiles()
                    loadReceivedApks()
                }
            } catch (ce: CancellationException) {
                BarqTransferForegroundService.stopTransferService(appContext)
                throw ce
            }
        }
        retainedTransferJob = activeTransferJob
    }

    private fun isDirectoryActuallyWritable(dir: File): Boolean {
        return try {
            if (!dir.exists() && !dir.mkdirs()) return false
            if (!dir.canWrite()) return false
            val probe = File(dir, ".barq_probe_${System.nanoTime()}")
            val created = probe.createNewFile()
            if (created || probe.exists()) {
                probe.delete()
                true
            } else {
                false
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun resolveBarqSherDownloadsDir(appContext: Context): File {
        return try {
            @Suppress("DEPRECATION")
            val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val barqDir = File(publicDownloads, "BarqSher")
            if (isDirectoryActuallyWritable(barqDir)) {
                barqDir
            } else {
                File(
                    appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: appContext.filesDir,
                    "BarqSher"
                ).apply { mkdirs() }
            }
        } catch (_: Throwable) {
            File(
                appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: appContext.filesDir,
                "BarqSher"
            ).apply { mkdirs() }
        }
    }

    /**
     * Connects to a discovered peer session directly.
     */
    fun connectToDiscoveredPeer(peer: DiscoveredPeerSession) {
        connectAndReceiveFromInput("BARQP2P|${peer.sessionCode}|${peer.hostIp}|${peer.port}")
    }

    /**
     * Resolves the sender's IP, port, and session code from:
     * 1. QR payload: BARQP2P|code|ip|port|sessionId|expiresAt
     * 2. Explicit IP & code: ip:port#code or ip#code
     * 3. Auto-discovered UDP peer matching the entered code
     * 4. Active UDP broadcast query (BARQ_FIND|code) + subnet scan across all local interfaces
     */
    fun connectAndReceiveFromInput(rawInput: String) {
        val cleaned = rawInput.trim()
        if (cleaned.isEmpty()) {
            _uiState.update {
                it.copy(
                    receiverConnectionPhase = ReceiverConnectionPhase.FAILED,
                    receiverDiagnosticError = "لم يتم إدخال رمز اتصال أو مسح باركود صالح.",
                    statusBannerMessage = "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد"
                )
            }
            return
        }

        approvalPollingJob?.cancel()
        _uiState.update {
            it.copy(
                isConnectingToSender = true,
                receiverConnectionPhase = ReceiverConnectionPhase.CONNECTING_MANIFEST,
                receiverDiagnosticError = null,
                statusBannerMessage = null
            )
        }

        viewModelScope.launch(Dispatchers.IO) {
            val candidateEndpoints = mutableListOf<Pair<String, Int>>()
            val defaultPort = _uiState.value.networkStatus.port
            var sessionCode = ""
            var parsedQrExpiresAt = Long.MAX_VALUE

            if (cleaned.startsWith("BARQP2P|", ignoreCase = true)) {
                val tokens = cleaned.split("|")
                if (tokens.size >= 4) {
                    sessionCode = tokens[1].trim().uppercase(Locale.US)
                    val ip = tokens[2].trim()
                    val port = tokens[3].trim().toIntOrNull() ?: defaultPort
                    if (tokens.size >= 6) {
                        parsedQrExpiresAt = tokens[5].trim().toLongOrNull() ?: Long.MAX_VALUE
                    }
                    if (ip.isNotEmpty()) candidateEndpoints.add(ip to port)
                }
            } else if (cleaned.contains("#")) {
                val hostPart = cleaned.substringBefore("#").trim()
                val codePart = cleaned.substringAfter("#").trim().uppercase(Locale.US)
                sessionCode = if (codePart.startsWith("BRQ-") || codePart.startsWith("5G-")) codePart else "BRQ-$codePart"
                val ip = hostPart.substringBefore(":")
                val port = hostPart.substringAfter(":", "").toIntOrNull() ?: defaultPort
                if (ip.isNotEmpty()) candidateEndpoints.add(ip to port)
            } else {
                val normalizedCore = P2PChunkServer.normalizeCode(cleaned)
                if (normalizedCore.length == 4 && normalizedCore.all { it.isDigit() }) {
                    sessionCode = "BRQ-$normalizedCore"

                    _uiState.value.discoveredPeers.find {
                        P2PChunkServer.normalizeCode(it.sessionCode) == normalizedCore
                    }?.let { discovered ->
                        candidateEndpoints.add(discovered.hostIp to discovered.port)
                    }

                    sendUdpFindQuery(sessionCode)
                    delay(350L)
                    _uiState.value.discoveredPeers.find {
                        P2PChunkServer.normalizeCode(it.sessionCode) == normalizedCore
                    }?.let { discovered ->
                        candidateEndpoints.add(discovered.hostIp to discovered.port)
                    }

                    val thirdOctet = normalizedCore.substring(0, 2).toIntOrNull()
                    val fourthOctet = normalizedCore.substring(2, 4).toIntOrNull()
                    if (thirdOctet != null && fourthOctet != null) {
                        val allIps = _uiState.value.networkStatus.allLocalIps
                        for (localIp in allIps) {
                            val parts = localIp.split(".")
                            if (parts.size == 4) {
                                candidateEndpoints.add("${parts[0]}.${parts[1]}.$thirdOctet.$fourthOctet" to defaultPort)
                                candidateEndpoints.add("${parts[0]}.${parts[1]}.${parts[2]}.$fourthOctet" to defaultPort)
                            }
                        }
                        candidateEndpoints.add("192.168.$thirdOctet.$fourthOctet" to 8989)
                    }
                }
            }

            if (System.currentTimeMillis() > parsedQrExpiresAt) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            isConnectingToSender = false,
                            showReceiveConfirmationDialog = false,
                            pendingIncomingFiles = emptyList(),
                            receiverConnectionPhase = ReceiverConnectionPhase.FAILED,
                            receiverDiagnosticError = "انتهت صلاحية جلسة الإرسال المرتبطة برمز QR هذا. اطلب من المرسِل الضغط على (بدء جلسة الإرسال) لتوليد رمز جديد.",
                            statusBannerMessage = "انتهت صلاحية جلسة الإرسال في رمز QR. يرجى تجديد الجلسة من جهاز المرسِل."
                        )
                    }
                }
                return@launch
            }

            val distinctEndpoints = candidateEndpoints.distinct()
            if (distinctEndpoints.isEmpty() || sessionCode.isBlank()) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            isConnectingToSender = false,
                            showReceiveConfirmationDialog = false,
                            pendingIncomingFiles = emptyList(),
                            receiverConnectionPhase = ReceiverConnectionPhase.FAILED,
                            receiverDiagnosticError = "صيغة الكود غير صحيحة. أدخل الكود المكون من 4 أرقام (مثل 4301) أو امسح رمز QR من شاشة الإرسال.",
                            statusBannerMessage = "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد"
                        )
                    }
                }
                return@launch
            }

            var fetchedRemoteFiles: List<TransferFileItem>? = null
            var remoteChunkSize = _uiState.value.selectedChunkSize.bytes
            var remoteSenderName = "جهاز أندرويد"
            var remoteSesId = "SES-REMOTE"
            var remoteRequiresApprove = false
            var resolvedIp = ""
            var resolvedPort = defaultPort
            var sawExpired410 = false
            var sawForbidden403 = false

            for ((targetIp, targetPort) in distinctEndpoints) {
                try {
                    val encodedCode = URLEncoder.encode(sessionCode, "UTF-8")
                    val url = URL("http://$targetIp:$targetPort/api/manifest?code=$encodedCode")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 2500
                        readTimeout = 4000
                        requestMethod = "GET"
                    }
                    when (conn.responseCode) {
                        200 -> {
                            val body = BufferedInputStream(conn.inputStream).bufferedReader().readText()
                            val json = JSONObject(body)
                            remoteChunkSize = json.optInt("chunkSize", remoteChunkSize)
                            remoteSenderName = json.optString("senderDevice", "جهاز أندرويد")
                            remoteSesId = json.optString("sessionId", "SES-REMOTE")
                            remoteRequiresApprove = json.optBoolean("requiresApproval", false)
                            val arr = json.optJSONArray("files")
                            if (arr != null && arr.length() > 0) {
                                val list = mutableListOf<TransferFileItem>()
                                for (i in 0 until arr.length()) {
                                    val o = arr.getJSONObject(i)
                                    val name = o.optString("name", "file_$i")
                                    val size = o.optLong("sizeBytes", 0L).coerceAtLeast(0L)
                                    val chunks = max(1, o.optInt("totalChunks", 1))
                                    val sha256 = o.optString("sha256", "")
                                    val splitWarn = o.optBoolean("hasSplitWarning", false)
                                    val relPath = o.optString("relativePath", "")
                                    val rootFolder = o.optString("rootFolderName", "")
                                    val batchId = o.optString("folderBatchId", "")
                                    val isDir = o.optBoolean("isDirectory", false)
                                    list.add(
                                        TransferFileItem(
                                            id = o.optString("id", "rem_$i"),
                                            name = name,
                                            sizeBytes = size,
                                            category = FileCategory.fromFileName(name, isDirectory = isDir),
                                            relativePath = relPath,
                                            rootFolderName = rootFolder,
                                            folderBatchId = batchId,
                                            isDirectory = isDir,
                                            totalChunks = chunks,
                                            sha256Expected = sha256,
                                            hasSplitWarning = splitWarn
                                        )
                                    )
                                }
                                if (list.isNotEmpty()) {
                                    fetchedRemoteFiles = list
                                    resolvedIp = targetIp
                                    resolvedPort = targetPort
                                    conn.disconnect()
                                    break
                                }
                            }
                        }
                        410 -> sawExpired410 = true
                        403 -> sawForbidden403 = true
                    }
                    conn.disconnect()
                } catch (_: Exception) {
                }
            }

            withContext(Dispatchers.Main) {
                val validFiles = fetchedRemoteFiles
                if (validFiles.isNullOrEmpty()) {
                    val diagnostic = when {
                        sawExpired410 -> "انتهت صلاحية جلسة الإرسال على الجهاز المرسِل. اطلب من المرسِل إعادة تشغيل جلسة الإرسال."
                        sawForbidden403 -> "تم الوصول للجهاز المرسِل ولكن جلسة الإرسال غير مفعّلة بعد أو أن الكود المدخل ($sessionCode) غير مطابق للكود الظاهر على شاشة المرسِل."
                        else -> "تعذر الوصول المباشر إلى عنوان المرسِل (${distinctEndpoints.first().first}:${distinctEndpoints.first().second}). تأكد من أن الجهازين متصلان بنفس شبكة الواي فاي المحلية أو أن أحد الجهازين يشغّل نقطة اتصال (Wi-Fi Hotspot) والآخر متصل بها مباشره دون عزل أجهزة (AP Isolation)."
                    }
                    _uiState.update {
                        it.copy(
                            isConnectingToSender = false,
                            showReceiveConfirmationDialog = false,
                            pendingIncomingFiles = emptyList(),
                            receiverConnectionPhase = ReceiverConnectionPhase.FAILED,
                            receiverDiagnosticError = diagnostic,
                            statusBannerMessage = "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد"
                        )
                    }
                } else {
                    _uiState.update { state ->
                        state.copy(
                            isConnectingToSender = false,
                            enteredReceiveCode = sessionCode,
                            remoteHostIp = resolvedIp,
                            remoteHostPort = resolvedPort,
                            remoteSessionCode = sessionCode,
                            remoteSessionId = remoteSesId,
                            remoteSenderDeviceName = remoteSenderName,
                            remoteRequiresApproval = remoteRequiresApprove,
                            remoteAuthToken = "",
                            receiverConnectionPhase = ReceiverConnectionPhase.MANIFEST_PREVIEW,
                            receiverDiagnosticError = null,
                            remoteChunkSizeBytes = remoteChunkSize,
                            pendingIncomingFiles = validFiles,
                            showReceiveConfirmationDialog = true,
                            currentScreen = AppScreen.RECEIVE,
                            statusBannerMessage = null
                        )
                    }
                }
            }
        }
    }

    private fun sendUdpFindQuery(code: String) {
        try {
            DatagramSocket().use { ds ->
                ds.broadcast = true
                val bytes = "BARQ_FIND|$code".toByteArray(Charsets.UTF_8)
                val pkt = DatagramPacket(
                    bytes,
                    bytes.size,
                    InetAddress.getByName("255.255.255.255"),
                    P2PChunkServer.UDP_DISCOVERY_PORT
                )
                ds.send(pkt)
            }
        } catch (_: Exception) {
        }
    }

    /**
     * Triggered when the Receiver presses "اتصال واستلام" on the manifest preview dialog.
     * - Verifies sufficient free disk space via StatFs.
     * - If the Sender session requires approval, sends `/api/request-connect` and polls `/api/connect-status`
     *   in state `WAITING_SENDER_APPROVAL` until the Sender approves and issues an `authToken`.
     * - Only starts downloading files after authorization is granted.
     */
    fun confirmAndStartReceiving() {
        val stateSnap = _uiState.value
        val incoming = stateSnap.pendingIncomingFiles
        if (incoming.isEmpty()) {
            _uiState.update { it.copy(showReceiveConfirmationDialog = false) }
            return
        }

        val appContext = getApplication<Application>().applicationContext
        val downloadDir = resolveBarqSherDownloadsDir(appContext)
        val requiredBytes = incoming.sumOf { it.sizeBytes }
        try {
            val statTarget = if (downloadDir.exists()) downloadDir else appContext.filesDir
            val stat = StatFs(statTarget.absolutePath)
            if (stat.availableBytes < requiredBytes + (10L * 1024L * 1024L)) {
                val neededMb = String.format(Locale.US, "%.1f MB", requiredBytes / (1024.0 * 1024.0))
                val availMb = String.format(Locale.US, "%.1f MB", stat.availableBytes / (1024.0 * 1024.0))
                _uiState.update {
                    it.copy(
                        showReceiveConfirmationDialog = false,
                        receiverConnectionPhase = ReceiverConnectionPhase.FAILED,
                        receiverDiagnosticError = "المساحة التخزينية غير كافية على هذا الجهاز. المطلوب: $neededMb والمتاح حالياً: $availMb.",
                        statusBannerMessage = "تعذر بدء الاستلام: المساحة التخزينية المتاحة غير كافية ($availMb)"
                    )
                }
                return
            }
        } catch (_: Throwable) {
        }

        // If Sender does not require approval (or already issued token), start receiving immediately
        if (!stateSnap.remoteRequiresApproval || stateSnap.remoteAuthToken.isNotBlank()) {
            _uiState.update { state ->
                state.copy(
                    files = incoming,
                    pendingIncomingFiles = emptyList(),
                    showReceiveConfirmationDialog = false
                )
            }
            startLiveChunkedTransfer(TransferDirection.RECEIVING)
            return
        }

        // Otherwise, send connection request to Sender and wait for Sender's approval
        approvalPollingJob?.cancel()
        _uiState.update {
            it.copy(
                receiverConnectionPhase = ReceiverConnectionPhase.WAITING_SENDER_APPROVAL,
                statusBannerMessage = "تم إرسال طلب الاتصال إلى «${it.remoteSenderDeviceName}». بانتظار موافقة المرسِل لبدء النقل..."
            )
        }

        approvalPollingJob = viewModelScope.launch(Dispatchers.IO) {
            val hostIp = stateSnap.remoteHostIp
            val hostPort = stateSnap.remoteHostPort
            val sessionCode = stateSnap.remoteSessionCode
            val encodedCode = URLEncoder.encode(sessionCode, "UTF-8")
            val encodedClient = URLEncoder.encode(receiverClientId, "UTF-8")
            val myDeviceName = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifBlank { "جهاز أندرويد مستلم" }
            val encodedDevice = URLEncoder.encode(myDeviceName, "UTF-8")

            try {
                val reqUrl = URL(
                    "http://$hostIp:$hostPort/api/request-connect?code=$encodedCode&clientId=$encodedClient&deviceName=$encodedDevice"
                )
                val reqConn = (reqUrl.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 4000
                    readTimeout = 4000
                    requestMethod = "GET"
                }
                val reqCode = reqConn.responseCode
                if (reqCode == 200) {
                    val respJson = JSONObject(BufferedInputStream(reqConn.inputStream).bufferedReader().readText())
                    val st = respJson.optString("status", "PENDING")
                    val tok = respJson.optString("authToken", "")
                    reqConn.disconnect()
                    if (st == ConnectionApprovalStatus.APPROVED.name && tok.isNotBlank()) {
                        withContext(Dispatchers.Main) {
                            _uiState.update { s ->
                                s.copy(
                                    remoteAuthToken = tok,
                                    files = incoming,
                                    pendingIncomingFiles = emptyList(),
                                    showReceiveConfirmationDialog = false,
                                    receiverConnectionPhase = ReceiverConnectionPhase.APPROVED_RECEIVING
                                )
                            }
                            startLiveChunkedTransfer(TransferDirection.RECEIVING)
                        }
                        return@launch
                    }
                } else {
                    reqConn.disconnect()
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(
                                showReceiveConfirmationDialog = false,
                                receiverConnectionPhase = ReceiverConnectionPhase.FAILED,
                                receiverDiagnosticError = "رفض الخادم طلب الاتصال (HTTP $reqCode). قد تكون الجلسة قد انتهت أو تم إيقافها.",
                                statusBannerMessage = "تعذر إرسال طلب الاتصال للمرسِل"
                            )
                        }
                    }
                    return@launch
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            showReceiveConfirmationDialog = false,
                            receiverConnectionPhase = ReceiverConnectionPhase.FAILED,
                            receiverDiagnosticError = "انقطع الاتصال بجهاز المرسِل أثناء طلب الموافقة: ${e.message ?: ""}",
                            statusBannerMessage = "انقطع الاتصال بالمرسِل"
                        )
                    }
                }
                return@launch
            }

            // Poll /api/connect-status every 400ms until Sender approves, rejects, or session expires
            val startWait = System.currentTimeMillis()
            while (isActive && (System.currentTimeMillis() - startWait) < 300_000L) {
                delay(400L)
                try {
                    val statusUrl = URL(
                        "http://$hostIp:$hostPort/api/connect-status?code=$encodedCode&clientId=$encodedClient"
                    )
                    val conn = (statusUrl.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 3000
                        readTimeout = 3000
                        requestMethod = "GET"
                    }
                    if (conn.responseCode == 200) {
                        val json = JSONObject(BufferedInputStream(conn.inputStream).bufferedReader().readText())
                        val statusStr = json.optString("status", "PENDING")
                        val token = json.optString("authToken", "")
                        conn.disconnect()

                        when (statusStr) {
                            ConnectionApprovalStatus.APPROVED.name -> {
                                withContext(Dispatchers.Main) {
                                    _uiState.update { s ->
                                        s.copy(
                                            remoteAuthToken = token,
                                            files = incoming,
                                            pendingIncomingFiles = emptyList(),
                                            showReceiveConfirmationDialog = false,
                                            receiverConnectionPhase = ReceiverConnectionPhase.APPROVED_RECEIVING,
                                            statusBannerMessage = "وافق المرسِل على الاتصال! جاري بدء النقل المباشر..."
                                        )
                                    }
                                    startLiveChunkedTransfer(TransferDirection.RECEIVING)
                                }
                                return@launch
                            }
                            ConnectionApprovalStatus.REJECTED.name -> {
                                withContext(Dispatchers.Main) {
                                    _uiState.update { s ->
                                        s.copy(
                                            showReceiveConfirmationDialog = false,
                                            pendingIncomingFiles = emptyList(),
                                            receiverConnectionPhase = ReceiverConnectionPhase.REJECTED,
                                            receiverDiagnosticError = "قام المرسِل برفض طلب الاتصال من هذا الجهاز.",
                                            statusBannerMessage = "تم رفض طلب الاتصال من قِبل المرسِل"
                                        )
                                    }
                                }
                                return@launch
                            }
                            ConnectionApprovalStatus.EXPIRED.name, ConnectionApprovalStatus.CANCELLED.name -> {
                                withContext(Dispatchers.Main) {
                                    _uiState.update { s ->
                                        s.copy(
                                            showReceiveConfirmationDialog = false,
                                            pendingIncomingFiles = emptyList(),
                                            receiverConnectionPhase = ReceiverConnectionPhase.FAILED,
                                            receiverDiagnosticError = "انتهت صلاحية جلسة الإرسال أو قام المرسِل بإيقافها.",
                                            statusBannerMessage = "انتهت جلسة الإرسال لدى الطرف الآخر"
                                        )
                                    }
                                }
                                return@launch
                            }
                        }
                    } else if (conn.responseCode == 410 || conn.responseCode == 403) {
                        conn.disconnect()
                        withContext(Dispatchers.Main) {
                            _uiState.update { s ->
                                s.copy(
                                    showReceiveConfirmationDialog = false,
                                    pendingIncomingFiles = emptyList(),
                                    receiverConnectionPhase = ReceiverConnectionPhase.FAILED,
                                    receiverDiagnosticError = "أُلغيت جلسة الإرسال من طرف المرسِل.",
                                    statusBannerMessage = "أُلغيت جلسة الإرسال"
                                )
                            }
                        }
                        return@launch
                    } else {
                        conn.disconnect()
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    fun cancelReceiveConfirmation() {
        approvalPollingJob?.cancel()
        _uiState.update { state ->
            state.copy(
                pendingIncomingFiles = emptyList(),
                showReceiveConfirmationDialog = false,
                receiverConnectionPhase = ReceiverConnectionPhase.IDLE,
                statusBannerMessage = "تم إلغاء طلب استلام الملفات"
            )
        }
    }

    fun togglePauseResume(): Unit = synchronized(transferControlLock) {
        val current = _uiState.value
        if (!current.isTransferRunning &&
            current.transferDirection == TransferDirection.RECEIVING &&
            current.files.any { it.status != FileTransferStatus.COMPLETED && it.status != FileTransferStatus.CANCELLED }
        ) {
            startLiveChunkedTransfer(TransferDirection.RECEIVING)
            return@synchronized
        }

        var snapshotAfterToggle: P2PUiState? = null
        _uiState.update { state ->
            val newPaused = !state.isPaused
            if (!newPaused) {
                pausedFileIds.clear()
            }
            val updatedFiles = state.files.map { f ->
                if (f.status == FileTransferStatus.TRANSFERRING || f.status == FileTransferStatus.PAUSED) {
                    f.copy(
                        status = if (newPaused) FileTransferStatus.PAUSED else FileTransferStatus.TRANSFERRING,
                        currentSpeedBytesPerSec = if (newPaused) 0.0 else f.currentSpeedBytesPerSec
                    )
                } else f
            }
            val next = state.copy(
                isPaused = newPaused,
                files = updatedFiles,
                liveOverallSpeedBytesPerSec = if (newPaused) 0.0 else state.liveOverallSpeedBytesPerSec,
                statusBannerMessage = if (newPaused) "تم إيقاف النقل مؤقتاً مع حفظ موضع الدفعة الحالية" else "تم استئناف النقل المباشر من آخر دفعة (Chunk)"
            )
            snapshotAfterToggle = next
            next
        }
        snapshotAfterToggle?.let { next ->
            retainedActiveState = next
            if (next.isTransferRunning || next.isSenderReady) {
                BarqTransferForegroundService.startOrUpdateTransfer(
                    context = getApplication(),
                    direction = next.transferDirection,
                    currentFileName = next.activeTransferringFile?.name ?: next.files.firstOrNull()?.name.orEmpty(),
                    completedFiles = next.completedFilesOnlyCount,
                    totalFiles = next.totalFilesOnlyCount,
                    transferredBytes = next.transferredBytes,
                    totalBytes = next.totalBytes,
                    speedBytesPerSec = if (next.isPaused) 0L else next.liveOverallSpeedBytesPerSec.toLong(),
                    isPaused = next.isPaused,
                    isStandbySession = !next.isTransferRunning && next.isSenderReady,
                    forceUpdate = true
                )
            }
        }
        Unit
    }

    fun openHistoryMediaInApp(record: TransferHistoryRecord) {
        if (!record.isCompleted) {
            _uiState.update {
                it.copy(
                    previewingHistoryRecord = null,
                    statusBannerMessage = "لا يمكن فتح «${record.fileName}» لأن عملية التنزيل لم تكتمل بالكامل"
                )
            }
            return
        }
        val existingFile = record.resolveExistingFile()
        if (existingFile == null) {
            _uiState.update {
                it.copy(
                    previewingHistoryRecord = null,
                    statusBannerMessage = "تعذر فتح «${record.fileName}»: الملف غير موجود في المسار المحفوظ (ربما تم حذفه أو نقله)"
                )
            }
            return
        }
        _uiState.update {
            it.copy(
                previewingHistoryRecord = record.copy(savedPath = existingFile.absolutePath),
                statusBannerMessage = "جاري عرض «${existingFile.name}» (${com.example.ui.components.formatBytesArabic(existingFile.length())})"
            )
        }
    }

    fun closeHistoryMediaPreview() {
        _uiState.update { it.copy(previewingHistoryRecord = null) }
    }

    fun openHistoryRecordExternally(context: Context, record: TransferHistoryRecord): Boolean {
        if (!record.isCompleted) {
            _uiState.update {
                it.copy(statusBannerMessage = "لا يمكن فتح «${record.fileName}» لأن التنزيل غير مكتمل")
            }
            return false
        }
        val existingFile = record.resolveExistingFile()
        if (existingFile == null) {
            _uiState.update {
                it.copy(
                    statusBannerMessage = "تعذر فتح «${record.fileName}»: الملف غير موجود في المسار المحفوظ (ربما تم حذفه أو نقله)"
                )
            }
            return false
        }
        return try {
            val contentUri = try {
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    existingFile
                )
            } catch (_: Exception) {
                Uri.fromFile(existingFile)
            }
            val resolvedMime = resolveHistoryRecordMimeType(record, existingFile)
            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, resolvedMime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(viewIntent, "فتح ${existingFile.name}").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            _uiState.update {
                it.copy(statusBannerMessage = "تم فتح «${existingFile.name}» بنجاح")
            }
            true
        } catch (e: Exception) {
            _uiState.update {
                it.copy(statusBannerMessage = "تعذر العثور على تطبيق مناسب لفتح «${existingFile.name}»: ${e.message ?: ""}")
            }
            false
        }
    }

    fun openBatteryOptimizationSettings(context: Context) {
        try {
            val intent = Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallback = Intent(android.provider.Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
            } catch (_: Exception) {
            }
        }
    }

    private fun resolveHistoryRecordMimeType(record: TransferHistoryRecord, file: File): String {
        val explicit = record.mimeType?.trim().orEmpty()
        if (explicit.isNotBlank() && explicit != "*/*") return explicit
        val ext = file.extension.lowercase(Locale.ROOT)
        val fromExt = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        if (!fromExt.isNullOrBlank()) return fromExt
        return when {
            record.isVideoFile -> "video/*"
            record.isImageFile -> "image/*"
            record.category == FileCategory.AUDIO -> "audio/*"
            record.category == FileCategory.GAME_APK || ext == "apk" -> "application/vnd.android.package-archive"
            else -> "*/*"
        }
    }

    fun exportSelfApkToDownloads() {
        viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>()
            try {
                val sourceApk = File(appContext.applicationInfo.sourceDir)
                val outDir = resolveBarqSherDownloadsDir(appContext)
                val targetApk = File(outDir, "Barq-Sher.apk")
                sourceApk.inputStream().use { input ->
                    FileOutputStream(targetApk).use { output ->
                        input.copyTo(output, 64 * 1024)
                    }
                }
                val sizeMb = String.format(Locale.US, "%.1f MB", targetApk.length() / (1024.0 * 1024.0))
                withContext(Dispatchers.Main) {
                    _uiState.update { state ->
                        state.copy(
                            statusBannerMessage = "تم حفظ ملف التطبيق Barq-Sher.apk ($sizeMb) في التنزيلات، وعبر الرابط: http://${state.networkStatus.localIp}:${state.networkStatus.port}/barq-p2p.apk"
                        )
                    }
                    loadReceivedApks()
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(statusBannerMessage = "رابط تنزيل الـ APK جاهز: http://${it.networkStatus.localIp}:${it.networkStatus.port}/barq-p2p.apk")
                    }
                }
            }
        }
    }

    private fun recordHistoryItem(
        item: TransferFileItem,
        direction: TransferDirection,
        peerAddress: String,
        avgSpeedBytesPerSec: Double,
        errorMessage: String? = null
    ) {
        val savedFileObj = item.savedPath?.takeIf { it.isNotBlank() }?.let { File(it) }
        val ext = (savedFileObj?.extension ?: item.name.substringAfterLast('.', "")).lowercase(Locale.ROOT)
        val guessedMime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (item.category) {
            FileCategory.VIDEO -> "video/mp4"
            FileCategory.IMAGE -> "image/jpeg"
            FileCategory.AUDIO -> "audio/*"
            FileCategory.GAME_APK -> "application/vnd.android.package-archive"
            else -> "*/*"
        }
        val resolvedUriStr = when {
            savedFileObj != null && savedFileObj.exists() -> Uri.fromFile(savedFileObj).toString()
            item.uri != null -> item.uri.toString()
            else -> null
        }
        val record = TransferHistoryRecord(
            id = UUID.randomUUID().toString().take(10),
            fileName = item.displayPathOrName,
            sizeBytes = item.sizeBytes,
            category = item.category,
            direction = direction,
            status = item.status,
            timestampMillis = System.currentTimeMillis(),
            savedPath = item.savedPath,
            uriString = resolvedUriStr,
            mimeType = guessedMime,
            sha256Hash = item.sha256Actual.ifBlank { item.sha256Expected },
            sha256Verified = item.sha256Verified,
            averageSpeedBytesPerSec = avgSpeedBytesPerSec,
            peerAddress = peerAddress,
            errorMessage = errorMessage,
            relativePath = item.relativePath,
            rootFolderName = item.rootFolderName
        )
        _uiState.update { state ->
            val deduplicated = state.transferHistory.filterNot { existing ->
                existing.savedPath != null && existing.savedPath == record.savedPath && existing.direction == record.direction
            }
            val updated = (listOf(record) + deduplicated).take(150)
            savePersistedHistory(updated)
            val next = state.copy(transferHistory = updated)
            retainedActiveState = next
            next
        }
    }

    fun clearTransferHistory() {
        _uiState.update {
            val next = it.copy(transferHistory = emptyList(), previewingHistoryRecord = null)
            retainedActiveState = next
            next
        }
        savePersistedHistory(emptyList())
    }

    private fun savePersistedHistory(records: List<TransferHistoryRecord>) {
        transferEngineScope.launch(Dispatchers.IO) {
            try {
                val arr = JSONArray()
                for (r in records) {
                    val o = JSONObject()
                    o.put("id", r.id)
                    o.put("fileName", r.fileName)
                    o.put("sizeBytes", r.sizeBytes)
                    o.put("category", r.category.name)
                    o.put("direction", r.direction.name)
                    o.put("status", r.status.name)
                    o.put("timestampMillis", r.timestampMillis)
                    o.put("savedPath", r.savedPath ?: "")
                    o.put("uriString", r.uriString ?: "")
                    o.put("mimeType", r.mimeType ?: "")
                    o.put("sha256Hash", r.sha256Hash)
                    o.put("sha256Verified", r.sha256Verified)
                    o.put("averageSpeedBytesPerSec", r.averageSpeedBytesPerSec)
                    o.put("peerAddress", r.peerAddress)
                    o.put("errorMessage", r.errorMessage ?: "")
                    o.put("relativePath", r.relativePath)
                    o.put("rootFolderName", r.rootFolderName)
                    arr.put(o)
                }
                val file = File(getApplication<Application>().filesDir, "barq_transfer_history.json")
                file.writeText(arr.toString())
            } catch (_: Exception) {
            }
        }
    }

    private fun loadPersistedHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = File(getApplication<Application>().filesDir, "barq_transfer_history.json")
                if (!file.exists()) return@launch
                val arr = JSONArray(file.readText())
                val list = mutableListOf<TransferHistoryRecord>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        TransferHistoryRecord(
                            id = o.optString("id"),
                            fileName = o.optString("fileName"),
                            sizeBytes = o.optLong("sizeBytes"),
                            category = runCatching { FileCategory.valueOf(o.optString("category")) }.getOrDefault(FileCategory.DOCUMENT),
                            direction = runCatching { TransferDirection.valueOf(o.optString("direction")) }.getOrDefault(TransferDirection.RECEIVING),
                            status = runCatching { FileTransferStatus.valueOf(o.optString("status")) }.getOrDefault(FileTransferStatus.COMPLETED),
                            timestampMillis = o.optLong("timestampMillis"),
                            savedPath = o.optString("savedPath").ifBlank { null },
                            uriString = o.optString("uriString").ifBlank { null },
                            mimeType = o.optString("mimeType").ifBlank { null },
                            sha256Hash = o.optString("sha256Hash"),
                            sha256Verified = o.optBoolean("sha256Verified"),
                            averageSpeedBytesPerSec = o.optDouble("averageSpeedBytesPerSec", 0.0),
                            peerAddress = o.optString("peerAddress"),
                            errorMessage = o.optString("errorMessage").ifBlank { null },
                            relativePath = o.optString("relativePath", ""),
                            rootFolderName = o.optString("rootFolderName", "")
                        )
                    )
                }
                _uiState.update { it.copy(transferHistory = list) }
            } catch (_: Exception) {
            }
        }
    }

    private fun updateFileState(fileId: String, transform: (TransferFileItem) -> TransferFileItem) {
        _uiState.update { state ->
            val next = state.copy(files = state.files.map { if (it.id == fileId) transform(it) else it })
            retainedActiveState = next
            next
        }
    }

    override fun onCleared() {
        super.onCleared()
        sessionTimerJob?.cancel()
        approvalPollingJob?.cancel()
        mediaLoadJob?.cancel()
        val snap = _uiState.value
        if (snap.isTransferRunning || snap.isSenderReady) {
            // Preserve active transfer job and chunkServer in background when Activity or screen recreates
            retainedSessionAppIdentity = getApplication()
            retainedActiveState = snap
            retainedChunkServer = chunkServer
            retainedTransferJob = activeTransferJob
        } else {
            bluetoothManager?.cleanup()
            chunkServer?.stopServer()
            retainedChunkServer = null
            retainedTransferJob = null
            retainedActiveState = null
        }
    }

    companion object {
        private const val LOG_TAG = "BarqP2PTransfer"
        private const val SOCKET_RECEIVE_BUFFER_BYTES = 4 * 1024 * 1024 // 4 MB TCP receive window
        private const val WRITE_COALESCE_BYTES = 256 * 1024 // Bounded 256 KB disk write coalescing (OOM-safe for 3 GB files)
        private const val STREAM_READ_BUFFER_BYTES = 256 * 1024 // Bounded 256 KB stream read buffer
        private const val CONCURRENT_SMALL_FILES_LIMIT = 3

        @Volatile
        private var retainedSessionAppIdentity: Application? = null

        @Volatile
        private var retainedActiveState: P2PUiState? = null

        @Volatile
        private var retainedChunkServer: P2PChunkServer? = null

        @Volatile
        private var retainedTransferJob: Job? = null

        fun resetRetainedEngineForTests() {
            runCatching { retainedTransferJob?.cancel() }
            runCatching { retainedChunkServer?.stopServer() }
            retainedTransferJob = null
            retainedChunkServer = null
            retainedActiveState = null
            retainedSessionAppIdentity = null
        }

        /**
         * Reads HTTP response headers up to `\r\n\r\n` from a raw socket InputStream and returns
         * the HTTP status code (e.g. 200), leaving the InputStream positioned at the first byte of the body.
         */
        private fun readHttpStatusFromSocketStream(input: java.io.InputStream): Int {
            val headerBytes = java.io.ByteArrayOutputStream(512)
            var state = 0
            while (headerBytes.size() < 16 * 1024) {
                val b = input.read()
                if (b == -1) break
                headerBytes.write(b)
                state = when {
                    state == 0 && b == '\r'.code -> 1
                    state == 1 && b == '\n'.code -> 2
                    state == 2 && b == '\r'.code -> 3
                    state == 3 && b == '\n'.code -> 4
                    b == '\r'.code -> 1
                    else -> 0
                }
                if (state == 4) break
            }
            val headerText = headerBytes.toString(StandardCharsets.ISO_8859_1.name())
            val firstLine = headerText.lineSequence().firstOrNull()?.trim().orEmpty()
            val parts = firstLine.split(' ')
            return if (parts.size >= 2) parts[1].toIntOrNull() ?: -1 else -1
        }

        /**
         * Sanitizes a relative path (e.g., "MyFolder/Sub1/file.txt") to prevent path traversal ("..")
         * while preserving nested directory structure and replacing the root folder segment if deduplicated.
         */
        fun resolveDestinationFileForTransferItem(
            downloadDir: File,
            item: TransferFileItem,
            rootFolderMap: Map<String, String>
        ): File {
            val rawRel = item.relativePath.trim().replace('\\', '/')
            if (rawRel.isBlank()) {
                val safeName = DeviceMediaRepository.sanitizePathSegment(item.name)
                return resolveUniqueStandaloneFile(downloadDir, safeName)
            }
            val segments = rawRel.split('/')
                .map { DeviceMediaRepository.sanitizePathSegment(it) }
                .filter { it.isNotBlank() && it != "." && it != ".." }
            if (segments.isEmpty()) {
                val safeName = DeviceMediaRepository.sanitizePathSegment(item.name)
                return resolveUniqueStandaloneFile(downloadDir, safeName)
            }
            val mappedSegments = segments.toMutableList()
            val originalRoot = mappedSegments[0]
            val mappedRoot = rootFolderMap[originalRoot] ?: originalRoot
            mappedSegments[0] = mappedRoot

            var current = downloadDir
            for (seg in mappedSegments) {
                current = File(current, seg)
            }
            return current
        }

        private fun resolveUniqueStandaloneFile(parentDir: File, fileName: String): File {
            val direct = File(parentDir, fileName)
            if (!direct.exists()) return direct
            val dotIdx = fileName.lastIndexOf('.')
            val stem = if (dotIdx > 0) fileName.substring(0, dotIdx) else fileName
            val ext = if (dotIdx > 0) fileName.substring(dotIdx) else ""
            var index = 1
            while (true) {
                val candidate = File(parentDir, "$stem ($index)$ext")
                if (!candidate.exists()) return candidate
                index++
            }
        }

        fun buildUniqueRootFolderMap(
            downloadDir: File,
            items: List<TransferFileItem>,
            isResumingSession: Boolean
        ): Map<String, String> {
            val map = LinkedHashMap<String, String>()
            val rootNames = items.mapNotNull {
                val r = it.rootFolderName.trim()
                if (r.isNotBlank()) DeviceMediaRepository.sanitizePathSegment(r)
                else it.relativePath.substringBefore('/', "").trim().takeIf { s -> s.isNotBlank() }?.let { s ->
                    DeviceMediaRepository.sanitizePathSegment(s)
                }
            }.distinct()

            for (root in rootNames) {
                val existing = File(downloadDir, root)
                if (!existing.exists() || isResumingSession) {
                    map[root] = root
                } else {
                    var counter = 1
                    while (true) {
                        val candidateName = "$root ($counter)"
                        if (!File(downloadDir, candidateName).exists()) {
                            map[root] = candidateName
                            break
                        }
                        counter++
                    }
                }
            }
            return map
        }

        private fun resolveAndReserveUniqueDestinationFile(
            downloadDir: File,
            item: TransferFileItem,
            rootFolderMap: Map<String, String>,
            reservedByFileId: ConcurrentHashMap<String, File>
        ): File {
            reservedByFileId[item.id]?.let { return it }
            synchronized(reservedByFileId) {
                reservedByFileId[item.id]?.let { return it }
                val baseCandidate = resolveDestinationFileForTransferItem(downloadDir, item, rootFolderMap)
                if (item.isDirectory) {
                    reservedByFileId[item.id] = baseCandidate
                    return baseCandidate
                }
                if (baseCandidate.exists() && baseCandidate.isDirectory && baseCandidate.listFiles().isNullOrEmpty()) {
                    runCatching { baseCandidate.delete() }
                }
                val reservedPaths = reservedByFileId.entries
                    .filter { it.key != item.id }
                    .map { it.value.absolutePath }
                    .toSet()
                val parentDir = baseCandidate.parentFile ?: downloadDir
                val safeIdSuffix = item.id.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "item" }
                val existingPartsInDir = runCatching { parentDir.listFiles()?.toList().orEmpty() }.getOrDefault(emptyList())
                val ownPartFile = existingPartsInDir.firstOrNull { f ->
                    f.isFile && f.name.endsWith(".$safeIdSuffix.part")
                }
                if (ownPartFile != null) {
                    val resumedName = ownPartFile.name.removeSuffix(".$safeIdSuffix.part")
                    if (resumedName.isNotBlank()) {
                        val resumedTarget = File(parentDir, resumedName)
                        if (resumedTarget.absolutePath !in reservedPaths) {
                            reservedByFileId[item.id] = resumedTarget
                            return resumedTarget
                        }
                    }
                }
                fun hasOtherPartFileClaiming(candidate: File): Boolean {
                    val prefix = "${candidate.name}."
                    return existingPartsInDir.any { f ->
                        f.isFile &&
                            f.name.startsWith(prefix) &&
                            f.name.endsWith(".part") &&
                            f.name != "${candidate.name}.$safeIdSuffix.part" &&
                            f.name != "${candidate.name}.part"
                    }
                }
                if (!baseCandidate.exists() && baseCandidate.absolutePath !in reservedPaths && !hasOtherPartFileClaiming(baseCandidate)) {
                    reservedByFileId[item.id] = baseCandidate
                    return baseCandidate
                }
                val originalName = DeviceMediaRepository.sanitizePathSegment(item.name.substringAfterLast('/'))
                    .ifBlank { baseCandidate.name }
                val dotIdx = originalName.lastIndexOf('.')
                val stem = if (dotIdx > 0) originalName.substring(0, dotIdx) else originalName
                val ext = if (dotIdx > 0) originalName.substring(dotIdx) else ""
                var index = 1
                while (true) {
                    val candidate = File(parentDir, "$stem ($index)$ext")
                    if (!candidate.exists() && candidate.absolutePath !in reservedPaths && !hasOtherPartFileClaiming(candidate)) {
                        reservedByFileId[item.id] = candidate
                        return candidate
                    }
                    index++
                }
            }
        }

        /**
         * High-Speed Receiver Transfer Engine supporting:
         * 1. Exact folder hierarchy recreation (including empty directories and 0-byte files).
         * 2. Duplicate root folder & file name resolution.
         * 3. Bounded 256 KB streaming (/api/stream) with zero OOM risk on 2.9 GB - 3 GB files.
         * 4. On-the-fly SHA-256 verification without double disk reads.
         * 5. Sequential multi-video / large-file queue that continues remaining files if one fails.
         * 6. Session authorization token (`authToken`) verification and exact `.part` resume.
         */
        suspend fun executeHighSpeedReceiveSession(
            hostIp: String,
            hostPort: Int,
            sessionCode: String,
            chunkSizeBytes: Int,
            downloadDir: File,
            itemsProvider: () -> List<TransferFileItem>,
            isPausedProvider: () -> Boolean,
            onFileUpdated: (
                fileId: String,
                fileSpeedBytesPerSec: Double,
                sessionSpeedBytesPerSec: Double,
                transform: (TransferFileItem) -> TransferFileItem
            ) -> Unit,
            onFileCompleted: (TransferFileItem, Double) -> Unit,
            onFileFailed: (TransferFileItem, String) -> Unit,
            authToken: String = "",
            isFileCancelledProvider: (String) -> Boolean = { false },
            isFilePausedProvider: (String) -> Boolean = { false },
            onNewFilesDiscovered: (List<TransferFileItem>) -> Unit = {}
        ): Boolean = coroutineScope {
            if (!downloadDir.exists()) downloadDir.mkdirs()
            val initialItems = itemsProvider()
            val isResuming = initialItems.any {
                it.transferredBytes > 0L || it.completedChunks > 0 || it.status == FileTransferStatus.COMPLETED
            }
            val rootFolderMap = LinkedHashMap<String, String>(
                buildUniqueRootFolderMap(downloadDir, initialItems, isResuming)
            )

            // Step 1: Explicitly create every selected root folder FIRST on the receiving phone before placing contents inside it
            for (mappedRootName in rootFolderMap.values) {
                File(downloadDir, mappedRootName).mkdirs()
            }

            val sessionStartNano = System.nanoTime()
            val sessionTotalBytes = AtomicLong(0L)
            var anyFailed = false
            val processedIds = ConcurrentHashMap.newKeySet<String>()
            val reservedDestByFileId = ConcurrentHashMap<String, File>()
            val autoRetriedFailedIds = ConcurrentHashMap.newKeySet<String>()

            while (isActive) {
                var currentAllItems = itemsProvider()
                currentAllItems.forEach { item ->
                    if (item.status == FileTransferStatus.QUEUED && !isFilePausedProvider(item.id) && !isFileCancelledProvider(item.id)) {
                        processedIds.remove(item.id)
                    }
                }
                var batchToProcess = currentAllItems.filter { item ->
                    item.id !in processedIds &&
                        item.status != FileTransferStatus.COMPLETED &&
                        item.status != FileTransferStatus.CANCELLED &&
                        !isFileCancelledProvider(item.id) &&
                        !isFilePausedProvider(item.id)
                }

                if (batchToProcess.isEmpty() && hostIp.isNotBlank() && hostPort > 0 &&
                    (processedIds.isNotEmpty() || currentAllItems.any { isFilePausedProvider(it.id) })
                ) {
                    val remoteManifestItems = fetchLiveManifestItems(hostIp, hostPort, sessionCode)
                    val existingIds = currentAllItems.map { it.id }.toSet()
                    val newlyAddedOnSender = remoteManifestItems.filter { item ->
                        item.id !in existingIds &&
                            item.id !in processedIds &&
                            !isFileCancelledProvider(item.id)
                    }
                    if (newlyAddedOnSender.isNotEmpty()) {
                        onNewFilesDiscovered(newlyAddedOnSender)
                        currentAllItems = itemsProvider()
                        batchToProcess = newlyAddedOnSender.filter { !isFilePausedProvider(it.id) }
                    }
                }

                if (batchToProcess.isEmpty()) {
                    val nonRecoverableCodes = setOf(
                        "SOURCE_PERMISSION_LOST",
                        "DEST_PERMISSION_LOST",
                        "PERMISSION_LOST",
                        "DEST_STORAGE_FULL",
                        "STORAGE_FULL",
                        "SOURCE_FILE_NOT_FOUND"
                    )
                    val autoRetryCandidates = itemsProvider().filter { item ->
                        !item.isDirectory &&
                            item.status == FileTransferStatus.FAILED &&
                            item.id !in autoRetriedFailedIds &&
                            !isFileCancelledProvider(item.id) &&
                            !isFilePausedProvider(item.id) &&
                            item.failureDiagnosticCode !in nonRecoverableCodes
                    }
                    if (autoRetryCandidates.isNotEmpty() && isActive) {
                        val candidateIds = autoRetryCandidates.map { it.id }.toSet()
                        autoRetriedFailedIds.addAll(candidateIds)
                        processedIds.removeAll(candidateIds)
                        for (candidate in autoRetryCandidates) {
                            onFileUpdated(candidate.id, 0.0, 0.0) { f ->
                                f.copy(
                                    status = FileTransferStatus.QUEUED,
                                    currentSpeedBytesPerSec = 0.0,
                                    retryCount = f.retryCount + 1,
                                    errorMessage = "إعادة محاولة تلقائية بعد انتهاء بقية الملفات...",
                                    failureDiagnosticCode = null
                                )
                            }
                        }
                        anyFailed = itemsProvider().any { it.status == FileTransferStatus.FAILED && it.id !in candidateIds }
                        delay(120L)
                        continue
                    }

                    val hasPendingPausedFiles = itemsProvider().any { item ->
                        item.id !in processedIds &&
                            item.status != FileTransferStatus.COMPLETED &&
                            item.status != FileTransferStatus.CANCELLED &&
                            !isFileCancelledProvider(item.id) &&
                            (isFilePausedProvider(item.id) || item.status == FileTransferStatus.PAUSED)
                    }
                    if (hasPendingPausedFiles && isActive) {
                        delay(80L)
                        continue
                    }
                    break
                }

                val additionalRoots = buildUniqueRootFolderMap(downloadDir, batchToProcess, isResumingSession = true)
                for ((origRoot, mappedRoot) in additionalRoots) {
                    if (origRoot !in rootFolderMap) {
                        rootFolderMap[origRoot] = mappedRoot
                        File(downloadDir, mappedRoot).mkdirs()
                    }
                }

                // Step 2: Pre-create all nested subdirectories and immediately complete empty directory items
                val remainingFileItems = mutableListOf<TransferFileItem>()
                for (item in batchToProcess) {
                    if (item.status == FileTransferStatus.COMPLETED || item.status == FileTransferStatus.CANCELLED || isFileCancelledProvider(item.id)) {
                        processedIds.add(item.id)
                        continue
                    }
                    if (isFilePausedProvider(item.id)) {
                        continue
                    }
                    val dest = resolveAndReserveUniqueDestinationFile(
                        downloadDir = downloadDir,
                        item = item,
                        rootFolderMap = rootFolderMap,
                        reservedByFileId = reservedDestByFileId
                    )
                    if (item.isDirectory) {
                        processedIds.add(item.id)
                        dest.mkdirs()
                        sendAckToSender(hostIp, hostPort, sessionCode, item.id)
                        var doneSnap: TransferFileItem? = null
                        onFileUpdated(item.id, 0.0, 0.0) { f ->
                            val d = f.copy(
                                completedChunks = f.totalChunks,
                                transferredBytes = 0L,
                                status = FileTransferStatus.COMPLETED,
                                savedPath = dest.absolutePath,
                                sha256Actual = Sha256Util.EMPTY_DIR_SHA256,
                                sha256Verified = true,
                                errorMessage = null
                            )
                            doneSnap = d
                            d
                        }
                        doneSnap?.let { onFileCompleted(it, 0.0) }
                    } else if (item.sizeBytes == 0L) {
                        processedIds.add(item.id)
                        dest.parentFile?.mkdirs()
                        if (dest.exists() && dest.isDirectory && dest.listFiles().isNullOrEmpty()) {
                            runCatching { dest.delete() }
                        }
                        if (!dest.exists()) dest.createNewFile()
                        sendAckToSender(hostIp, hostPort, sessionCode, item.id)
                        var doneSnap: TransferFileItem? = null
                        onFileUpdated(item.id, 0.0, 0.0) { f ->
                            val d = f.copy(
                                completedChunks = f.totalChunks,
                                transferredBytes = 0L,
                                status = FileTransferStatus.COMPLETED,
                                savedPath = dest.absolutePath,
                                sha256Actual = Sha256Util.EMPTY_BYTES_SHA256,
                                sha256Verified = true,
                                errorMessage = null
                            )
                            doneSnap = d
                            d
                        }
                        doneSnap?.let { onFileCompleted(it, 0.0) }
                    } else {
                        dest.parentFile?.mkdirs()
                        if (dest.exists() && dest.isDirectory && dest.listFiles().isNullOrEmpty()) {
                            runCatching { dest.delete() }
                        }
                        remainingFileItems.add(item)
                    }
                }

                // Partition into small/medium files (<= 4 MB) for bounded concurrency, and large files (> 4 MB) for sequential high-speed streaming
                val smallFiles = remainingFileItems.filter { it.sizeBytes <= 4L * 1024L * 1024L }
                val largeFiles = remainingFileItems.filter { it.sizeBytes > 4L * 1024L * 1024L }

                if (smallFiles.isNotEmpty()) {
                    val semaphore = Semaphore(CONCURRENT_SMALL_FILES_LIMIT)
                    val jobs = smallFiles.map { item ->
                        async(Dispatchers.IO) {
                            semaphore.withPermit {
                                val ok = downloadSingleFileOptimized(
                                    item = item,
                                    hostIp = hostIp,
                                    hostPort = hostPort,
                                    sessionCode = sessionCode,
                                    authToken = authToken,
                                    chunkSizeBytes = chunkSizeBytes,
                                    downloadDir = downloadDir,
                                    rootFolderMap = rootFolderMap,
                                    reservedDestByFileId = reservedDestByFileId,
                                    sessionStartNano = sessionStartNano,
                                    sessionTotalBytes = sessionTotalBytes,
                                    itemsProvider = itemsProvider,
                                    isPausedProvider = isPausedProvider,
                                    isFileCancelledProvider = isFileCancelledProvider,
                                    isFilePausedProvider = isFilePausedProvider,
                                    onFileUpdated = onFileUpdated,
                                    onFileCompleted = onFileCompleted,
                                    onFileFailed = onFileFailed
                                )
                                val postStatus = itemsProvider().find { it.id == item.id }?.status
                                if (!isFilePausedProvider(item.id) && postStatus != FileTransferStatus.PAUSED) {
                                    processedIds.add(item.id)
                                    if (!ok) anyFailed = true
                                }
                            }
                        }
                    }
                    jobs.awaitAll()
                }

                // Sequential multi-video / large-file queue: each file finishes & verifies before the next starts
                for (largeItem in largeFiles) {
                    if (!isActive) break
                    if (isFilePausedProvider(largeItem.id)) continue
                    val ok = downloadSingleFileOptimized(
                        item = largeItem,
                        hostIp = hostIp,
                        hostPort = hostPort,
                        sessionCode = sessionCode,
                        authToken = authToken,
                        chunkSizeBytes = chunkSizeBytes,
                        downloadDir = downloadDir,
                        rootFolderMap = rootFolderMap,
                        reservedDestByFileId = reservedDestByFileId,
                        sessionStartNano = sessionStartNano,
                        sessionTotalBytes = sessionTotalBytes,
                        itemsProvider = itemsProvider,
                        isPausedProvider = isPausedProvider,
                        isFileCancelledProvider = isFileCancelledProvider,
                        isFilePausedProvider = isFilePausedProvider,
                        onFileUpdated = onFileUpdated,
                        onFileCompleted = onFileCompleted,
                        onFileFailed = onFileFailed
                    )
                    val postStatus = itemsProvider().find { it.id == largeItem.id }?.status
                    if (!isFilePausedProvider(largeItem.id) && postStatus != FileTransferStatus.PAUSED) {
                        processedIds.add(largeItem.id)
                        if (!ok) {
                            anyFailed = true
                        }
                    }
                }
            }

            anyFailed
        }

        private fun fetchLiveManifestItems(
            hostIp: String,
            hostPort: Int,
            sessionCode: String
        ): List<TransferFileItem> {
            return try {
                val encodedCode = URLEncoder.encode(sessionCode, "UTF-8")
                val url = URL("http://$hostIp:$hostPort/api/manifest?code=$encodedCode")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 1500
                    readTimeout = 2000
                    requestMethod = "GET"
                }
                try {
                    if (conn.responseCode != 200) return emptyList()
                    val body = BufferedInputStream(conn.inputStream).bufferedReader().readText()
                    val json = JSONObject(body)
                    val arr = json.optJSONArray("files") ?: return emptyList()
                    val list = mutableListOf<TransferFileItem>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val name = o.optString("name", "file_$i")
                        val size = o.optLong("sizeBytes", 0L).coerceAtLeast(0L)
                        val chunks = max(1, o.optInt("totalChunks", 1))
                        val sha256 = o.optString("sha256", "")
                        val splitWarn = o.optBoolean("hasSplitWarning", false)
                        val relPath = o.optString("relativePath", "")
                        val rootFolder = o.optString("rootFolderName", "")
                        val batchId = o.optString("folderBatchId", "")
                        val isDir = o.optBoolean("isDirectory", false)
                        list.add(
                            TransferFileItem(
                                id = o.optString("id", "rem_$i"),
                                name = name,
                                sizeBytes = size,
                                category = FileCategory.fromFileName(name, isDirectory = isDir),
                                relativePath = relPath,
                                rootFolderName = rootFolder,
                                folderBatchId = batchId,
                                isDirectory = isDir,
                                totalChunks = chunks,
                                sha256Expected = sha256,
                                hasSplitWarning = splitWarn
                            )
                        )
                    }
                    list
                } finally {
                    runCatching { conn.disconnect() }
                }
            } catch (_: Throwable) {
                emptyList()
            }
        }

        private suspend fun downloadSingleFileOptimized(
            item: TransferFileItem,
            hostIp: String,
            hostPort: Int,
            sessionCode: String,
            authToken: String,
            chunkSizeBytes: Int,
            downloadDir: File,
            rootFolderMap: Map<String, String>,
            reservedDestByFileId: ConcurrentHashMap<String, File>,
            sessionStartNano: Long,
            sessionTotalBytes: AtomicLong,
            itemsProvider: () -> List<TransferFileItem>,
            isPausedProvider: () -> Boolean,
            isFileCancelledProvider: (String) -> Boolean,
            isFilePausedProvider: (String) -> Boolean,
            onFileUpdated: (
                fileId: String,
                fileSpeedBytesPerSec: Double,
                sessionSpeedBytesPerSec: Double,
                transform: (TransferFileItem) -> TransferFileItem
            ) -> Unit,
            onFileCompleted: (TransferFileItem, Double) -> Unit,
            onFileFailed: (TransferFileItem, String) -> Unit
        ): Boolean = coroutineScope {
            val totalChunks = max(1, item.totalChunks)
            val safeChunkBytesLong = chunkSizeBytes.toLong().coerceAtLeast(1L)
            val finalOutFile = resolveAndReserveUniqueDestinationFile(
                downloadDir = downloadDir,
                item = item,
                rootFolderMap = rootFolderMap,
                reservedByFileId = reservedDestByFileId
            )
            finalOutFile.parentFile?.mkdirs()
            if (!item.isDirectory && finalOutFile.exists() && finalOutFile.isDirectory && finalOutFile.listFiles().isNullOrEmpty()) {
                runCatching { finalOutFile.delete() }
            }
            val parentDir = finalOutFile.parentFile ?: downloadDir
            val safeIdSuffix = item.id.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "item" }
            val isolatedPartFile = File(parentDir, "${finalOutFile.name}.$safeIdSuffix.part")
            val legacyPartFile = File(parentDir, "${finalOutFile.name}.part")
            var tempPartFile = if (!isolatedPartFile.exists() && legacyPartFile.exists()) {
                legacyPartFile
            } else {
                isolatedPartFile
            }

            fun isSingleFileCancelled(): Boolean {
                if (isFileCancelledProvider(item.id)) return true
                val latestStatus = itemsProvider().find { it.id == item.id }?.status
                return latestStatus == FileTransferStatus.CANCELLED
            }

            fun isSingleFilePaused(): Boolean {
                if (isFilePausedProvider(item.id)) return true
                val latestStatus = itemsProvider().find { it.id == item.id }?.status
                return !isPausedProvider() && latestStatus == FileTransferStatus.PAUSED
            }

            fun cancelOnlyThisFile(reason: String = "تم إلغاء نقل هذا الملف"): Boolean {
                runCatching { if (tempPartFile.exists()) tempPartFile.delete() }
                onFileUpdated(item.id, 0.0, 0.0) { f ->
                    if (f.status == FileTransferStatus.COMPLETED) f
                    else f.copy(
                        status = FileTransferStatus.CANCELLED,
                        currentSpeedBytesPerSec = 0.0,
                        errorMessage = reason
                    )
                }
                sendAckToSender(
                    hostIp = hostIp,
                    hostPort = hostPort,
                    sessionCode = sessionCode,
                    fileId = item.id,
                    status = FileTransferStatus.CANCELLED,
                    verified = false,
                    transferredBytes = 0L,
                    errorMessage = reason
                )
                return true
            }

            if (isSingleFileCancelled()) {
                return@coroutineScope cancelOnlyThisFile()
            }

            if (isSingleFilePaused()) {
                onFileUpdated(item.id, 0.0, 0.0) { f ->
                    if (f.status == FileTransferStatus.COMPLETED || f.status == FileTransferStatus.CANCELLED) f
                    else f.copy(status = FileTransferStatus.PAUSED, currentSpeedBytesPerSec = 0.0)
                }
                sendAckToSender(
                    hostIp = hostIp,
                    hostPort = hostPort,
                    sessionCode = sessionCode,
                    fileId = item.id,
                    status = FileTransferStatus.PAUSED,
                    verified = false,
                    transferredBytes = if (tempPartFile.exists()) tempPartFile.length().coerceIn(0L, item.sizeBytes) else item.transferredBytes
                )
                return@coroutineScope true
            }

            val initialRunStatus = if (isPausedProvider()) FileTransferStatus.PAUSED else FileTransferStatus.TRANSFERRING
            onFileUpdated(item.id, 0.0, 0.0) {
                if (it.status == FileTransferStatus.CANCELLED) it
                else it.copy(status = initialRunStatus, errorMessage = null, failureDiagnosticCode = null)
            }
            sendAckToSender(
                hostIp = hostIp,
                hostPort = hostPort,
                sessionCode = sessionCode,
                fileId = item.id,
                status = initialRunStatus,
                verified = false,
                transferredBytes = if (tempPartFile.exists()) tempPartFile.length().coerceIn(0L, item.sizeBytes) else item.transferredBytes
            )

            val fileStartNano = System.nanoTime()
            var bytesDownloadedForThisFile = 0L
            var lastUiReportNano = 0L

            try {
                if (finalOutFile.parentFile?.exists() != true && finalOutFile.parentFile?.mkdirs() == false) {
                    throw SecurityException("DEST_PERMISSION_LOST: فُقدت صلاحية الكتابة في مجلد الحفظ — يرجى إعادة اختيار مجلد الحفظ عند الضرورة")
                }
                if (!isDirectoryWritableWithPermissions(parentDir) || !isDirectoryWritableWithPermissions(downloadDir)) {
                    throw SecurityException("DEST_PERMISSION_LOST: فُقدت صلاحية الكتابة في مجلد الحفظ — يرجى إعادة اختيار مجلد الحفظ عند الضرورة")
                }

                if (tempPartFile.exists() && !tempPartFile.canWrite()) {
                    val deletedStale = runCatching { tempPartFile.delete() }.getOrDefault(false)
                    if (!deletedStale && tempPartFile.exists()) {
                        tempPartFile = File(parentDir, "${finalOutFile.name}.${safeIdSuffix}_r${item.retryCount}.part")
                    }
                }

                val existingPartBytes = if (tempPartFile.exists()) tempPartFile.length() else 0L
                var resumeOffset = if (existingPartBytes in 1L..item.sizeBytes) {
                    existingPartBytes
                } else {
                    0L
                }

                // Verify free disk space before writing large files (including > 4 GB files using 64-bit Long math)
                val remainingNeededBytes = (item.sizeBytes - resumeOffset).coerceAtLeast(0L)
                runCatching {
                    val stat = android.os.StatFs((finalOutFile.parentFile ?: downloadDir).absolutePath)
                    val availableBytes = stat.availableBytes
                    if (availableBytes in 1L until remainingNeededBytes) {
                        throw java.io.IOException(
                            "ENOSPC: المساحة التخزينية غير كافية لحفظ الملف (المتاح: ${availableBytes / (1024L * 1024L)} MB، المطلوب: ${remainingNeededBytes / (1024L * 1024L)} MB)"
                        )
                    }
                }.onFailure { err ->
                    if (err is java.io.IOException) throw err
                }

                val digest = MessageDigest.getInstance("SHA-256")
                val openedRaf = try {
                    RandomAccessFile(tempPartFile, "rw")
                } catch (openErr: Throwable) {
                    runCatching { tempPartFile.delete() }
                    tempPartFile = File(parentDir, "${finalOutFile.name}.${safeIdSuffix}_r${item.retryCount + 1}.part")
                    resumeOffset = 0L
                    try {
                        RandomAccessFile(tempPartFile, "rw")
                    } catch (secondErr: Throwable) {
                        if (isStorageFullException(secondErr)) throw secondErr
                        throw SecurityException(
                            "DEST_PERMISSION_LOST: فُقدت صلاحية الكتابة في مجلد الحفظ — يرجى إعادة اختيار مجلد الحفظ عند الضرورة (${secondErr.message})",
                            secondErr
                        )
                    }
                }
                openedRaf.use { raf ->
                    if (resumeOffset == 0L && existingPartBytes > 0L) {
                        // Existing .part exceeded expected sizeBytes or was invalid -> truncate cleanly
                        raf.setLength(0L)
                    } else if (resumeOffset > 0L) {
                        // Validate and hash already-downloaded .part prefix using bounded 256 KB buffer
                        raf.seek(0L)
                        val hashScratch = ByteArray(STREAM_READ_BUFFER_BYTES)
                        var remPrefix = resumeOffset
                        var hashedBytes = 0L
                        while (remPrefix > 0L) {
                            val r = raf.read(hashScratch, 0, minOf(hashScratch.size.toLong(), remPrefix).toInt())
                            if (r <= 0) break
                            digest.update(hashScratch, 0, r)
                            remPrefix -= r.toLong()
                            hashedBytes += r.toLong()
                        }
                        if (hashedBytes != resumeOffset) {
                            digest.reset()
                            resumeOffset = 0L
                            raf.setLength(0L)
                        } else if (resumeOffset == item.sizeBytes && item.sha256Expected.isNotBlank()) {
                            // Full-size .part left from interrupted session right before rename: verify hash before accepting
                            val checkDigest = (digest.clone() as? MessageDigest)?.digest()
                            val partHex = checkDigest?.let { Sha256Util.bytesToHex(it) }.orEmpty()
                            if (partHex.isNotBlank() && !partHex.equals(item.sha256Expected, ignoreCase = true)) {
                                digest.reset()
                                resumeOffset = 0L
                                raf.setLength(0L)
                            }
                        }
                        if (resumeOffset > 0L) {
                            val resumedChunks = ((resumeOffset + safeChunkBytesLong - 1L) / safeChunkBytesLong)
                                .coerceIn(1L, totalChunks.toLong()).toInt()
                            onFileUpdated(item.id, 0.0, 0.0) { f ->
                                f.copy(
                                    completedChunks = minOf(resumedChunks, (totalChunks - 1).coerceAtLeast(1)),
                                    transferredBytes = resumeOffset,
                                    status = if (isPausedProvider()) FileTransferStatus.PAUSED else FileTransferStatus.TRANSFERRING,
                                    errorMessage = null
                                )
                            }
                        }
                    }

                    val encodedFileId = URLEncoder.encode(item.id, "UTF-8")
                    val encodedCode = URLEncoder.encode(sessionCode, "UTF-8")
                    val encodedToken = URLEncoder.encode(authToken, "UTF-8")
                    val readBuf = ByteArray(STREAM_READ_BUFFER_BYTES)
                    val writeCoalesceBuf = ByteArray(WRITE_COALESCE_BYTES)
                    var writeCoalescePos = 0
                    var currentByteOffset = resumeOffset

                    fun commitBytesToPart(source: ByteArray, offset: Int, count: Int) {
                        if (count <= 0) return
                        var lastWriteErr: Throwable? = null
                        for (writeAttempt in 1..3) {
                            try {
                                raf.seek(currentByteOffset)
                                raf.write(source, offset, count)
                                digest.update(source, offset, count)
                                currentByteOffset += count.toLong()
                                bytesDownloadedForThisFile += count.toLong()
                                sessionTotalBytes.addAndGet(count.toLong())
                                return
                            } catch (ioe: Throwable) {
                                lastWriteErr = ioe
                                if (isStorageFullException(ioe)) break
                                runCatching { Thread.sleep(40L * writeAttempt) }
                            }
                        }
                        writeCoalescePos = 0
                        runCatching { raf.setLength(currentByteOffset) }
                        throw lastWriteErr ?: java.io.IOException("STREAM_WRITE_ERROR: تعذر كتابة الدفعة في ملف الاستئناف")
                    }

                    fun flushCoalescedWrites() {
                        if (writeCoalescePos > 0) {
                            val pending = writeCoalescePos
                            writeCoalescePos = 0
                            commitBytesToPart(writeCoalesceBuf, 0, pending)
                        }
                    }

                    var streamAttempt = 0
                    var sourceUnreadableRetries = 0
                    while (currentByteOffset < item.sizeBytes && isActive) {
                        if (isSingleFilePaused()) {
                            flushCoalescedWrites()
                            onFileUpdated(item.id, 0.0, 0.0) { f ->
                                f.copy(
                                    transferredBytes = minOf(f.sizeBytes, currentByteOffset),
                                    currentSpeedBytesPerSec = 0.0,
                                    status = FileTransferStatus.PAUSED
                                )
                            }
                            sendAckToSender(
                                hostIp = hostIp,
                                hostPort = hostPort,
                                sessionCode = sessionCode,
                                fileId = item.id,
                                status = FileTransferStatus.PAUSED,
                                verified = false,
                                transferredBytes = currentByteOffset
                            )
                            return@coroutineScope true
                        }
                        var pausedWait = false
                        while (isPausedProvider() && isActive) {
                            if (isSingleFileCancelled()) {
                                return@coroutineScope cancelOnlyThisFile()
                            }
                            if (isSingleFilePaused()) {
                                flushCoalescedWrites()
                                onFileUpdated(item.id, 0.0, 0.0) { f ->
                                    f.copy(
                                        transferredBytes = minOf(f.sizeBytes, currentByteOffset),
                                        currentSpeedBytesPerSec = 0.0,
                                        status = FileTransferStatus.PAUSED
                                    )
                                }
                                sendAckToSender(
                                    hostIp = hostIp,
                                    hostPort = hostPort,
                                    sessionCode = sessionCode,
                                    fileId = item.id,
                                    status = FileTransferStatus.PAUSED,
                                    verified = false,
                                    transferredBytes = currentByteOffset
                                )
                                return@coroutineScope true
                            }
                            if (!pausedWait) {
                                pausedWait = true
                                sendAckToSender(
                                    hostIp = hostIp,
                                    hostPort = hostPort,
                                    sessionCode = sessionCode,
                                    fileId = item.id,
                                    status = FileTransferStatus.PAUSED,
                                    verified = false,
                                    transferredBytes = currentByteOffset
                                )
                            }
                            delay(100)
                        }
                        if (pausedWait) {
                            streamAttempt = 0
                            onFileUpdated(item.id, 0.0, 0.0) { f ->
                                if (f.status == FileTransferStatus.PAUSED) {
                                    f.copy(status = FileTransferStatus.TRANSFERRING)
                                } else f
                            }
                            sendAckToSender(
                                hostIp = hostIp,
                                hostPort = hostPort,
                                sessionCode = sessionCode,
                                fileId = item.id,
                                status = FileTransferStatus.TRANSFERRING,
                                verified = false,
                                transferredBytes = currentByteOffset
                            )
                        }
                        if (!isActive) throw CancellationException("Transfer cancelled")
                        if (isSingleFileCancelled()) {
                            return@coroutineScope cancelOnlyThisFile()
                        }

                        streamAttempt++
                        var conn: HttpURLConnection? = null
                        try {
                            raf.seek(currentByteOffset)
                            writeCoalescePos = 0
                            val streamUrl = URL(
                                "http://$hostIp:$hostPort/api/stream?fileId=$encodedFileId&offset=$currentByteOffset&chunkSize=$chunkSizeBytes&code=$encodedCode&token=$encodedToken"
                            )
                            conn = (streamUrl.openConnection() as HttpURLConnection).apply {
                                connectTimeout = 15_000
                                readTimeout = 45_000
                                requestMethod = "GET"
                                setRequestProperty("Connection", "keep-alive")
                            }

                            val statusCode = conn.responseCode
                            if (statusCode == 404 || statusCode == 410) {
                                val errBody = runCatching {
                                    conn.errorStream?.bufferedReader()?.readText().orEmpty()
                                }.getOrDefault("")
                                conn.disconnect()
                                if (statusCode == 404 || errBody.contains("FILE_CANCELLED_OR_REMOVED") || isSingleFileCancelled()) {
                                    return@coroutineScope cancelOnlyThisFile("تم إلغاء أو حذف هذا الملف من قائمة المرسِل")
                                }
                                throw java.io.IOException("HTTP $statusCode")
                            }
                            if (statusCode == 416) {
                                conn.disconnect()
                                // Offset out of range on .part file -> reset .part cleanly and restart from byte 0
                                writeCoalescePos = 0
                                raf.setLength(0L)
                                currentByteOffset = 0L
                                digest.reset()
                                streamAttempt = 0
                                continue
                            }
                            if (statusCode == 403) {
                                val errBody = runCatching {
                                    conn.errorStream?.bufferedReader()?.readText().orEmpty()
                                }.getOrDefault("")
                                conn.disconnect()
                                if (errBody.contains("SOURCE_FILE_UNREADABLE")) {
                                    if (sourceUnreadableRetries < 1) {
                                        sourceUnreadableRetries++
                                        delay(150L)
                                        continue
                                    }
                                    throw SecurityException("SOURCE_PERMISSION_LOST: فُقدت صلاحية قراءة الملف لدى المرسِل — يرجى إعادة تحديد الملف")
                                }
                                throw java.io.IOException("HTTP 403")
                            }
                            if (statusCode != 200) {
                                conn.disconnect()
                                throw java.io.IOException("HTTP $statusCode")
                            }

                            val bytesAtAttemptStart = currentByteOffset
                            BufferedInputStream(conn.inputStream, STREAM_READ_BUFFER_BYTES).use { input ->
                                while (currentByteOffset + writeCoalescePos.toLong() < item.sizeBytes) {
                                    if (!isActive) {
                                        flushCoalescedWrites()
                                        throw CancellationException("Transfer cancelled")
                                    }
                                    if (isSingleFileCancelled()) {
                                        writeCoalescePos = 0
                                        return@coroutineScope cancelOnlyThisFile()
                                    }
                                    if (isSingleFilePaused()) {
                                        flushCoalescedWrites()
                                        onFileUpdated(item.id, 0.0, 0.0) { f ->
                                            f.copy(
                                                transferredBytes = minOf(f.sizeBytes, currentByteOffset),
                                                currentSpeedBytesPerSec = 0.0,
                                                status = FileTransferStatus.PAUSED
                                            )
                                        }
                                        sendAckToSender(
                                            hostIp = hostIp,
                                            hostPort = hostPort,
                                            sessionCode = sessionCode,
                                            fileId = item.id,
                                            status = FileTransferStatus.PAUSED,
                                            verified = false,
                                            transferredBytes = currentByteOffset
                                        )
                                        return@coroutineScope true
                                    }
                                    if (isPausedProvider()) {
                                        flushCoalescedWrites()
                                        onFileUpdated(item.id, 0.0, 0.0) { f ->
                                            f.copy(
                                                transferredBytes = minOf(f.sizeBytes, currentByteOffset),
                                                currentSpeedBytesPerSec = 0.0,
                                                status = FileTransferStatus.PAUSED
                                            )
                                        }
                                        sendAckToSender(
                                            hostIp = hostIp,
                                            hostPort = hostPort,
                                            sessionCode = sessionCode,
                                            fileId = item.id,
                                            status = FileTransferStatus.PAUSED,
                                            verified = false,
                                            transferredBytes = currentByteOffset
                                        )
                                        break
                                    }
                                    val uncommittedBytes = writeCoalescePos.toLong()
                                    val remainingBytes = (item.sizeBytes - (currentByteOffset + uncommittedBytes)).coerceAtLeast(0L)
                                    val maxToRead = minOf(readBuf.size.toLong(), remainingBytes).toInt()
                                    if (maxToRead <= 0) break
                                    val readCount = input.read(readBuf, 0, maxToRead)
                                    if (readCount == -1) break
                                    if (readCount > 0) {
                                        if (writeCoalescePos + readCount > writeCoalesceBuf.size) {
                                            flushCoalescedWrites()
                                        }
                                        if (readCount >= writeCoalesceBuf.size) {
                                            commitBytesToPart(readBuf, 0, readCount)
                                        } else {
                                            System.arraycopy(readBuf, 0, writeCoalesceBuf, writeCoalescePos, readCount)
                                            writeCoalescePos += readCount
                                        }

                                        val effectiveOffsetNow = currentByteOffset + writeCoalescePos.toLong()
                                        val nowNano = System.nanoTime()
                                        if (effectiveOffsetNow >= item.sizeBytes || (nowNano - lastUiReportNano) >= 45_000_000L) {
                                            lastUiReportNano = nowNano
                                            val fileElapsed = max(0.002, (nowNano - fileStartNano) / 1_000_000_000.0)
                                            val sessionElapsed = max(0.002, (nowNano - sessionStartNano) / 1_000_000_000.0)
                                            val effectiveDownloaded = bytesDownloadedForThisFile + writeCoalescePos.toLong()
                                            val fSpeed = effectiveDownloaded.toDouble() / fileElapsed
                                            val sSpeed = (sessionTotalBytes.get() + writeCoalescePos.toLong()).toDouble() / sessionElapsed
                                            val doneChunks = ((effectiveOffsetNow + safeChunkBytesLong - 1L) / safeChunkBytesLong)
                                                .coerceIn(1L, (totalChunks - 1).coerceAtLeast(1).toLong())
                                                .toInt()
                                            onFileUpdated(item.id, fSpeed, sSpeed) { f ->
                                                f.copy(
                                                    completedChunks = doneChunks,
                                                    transferredBytes = minOf(f.sizeBytes, effectiveOffsetNow),
                                                    currentSpeedBytesPerSec = fSpeed,
                                                    status = FileTransferStatus.TRANSFERRING,
                                                    errorMessage = null
                                                )
                                            }
                                        }
                                    }
                                }
                                flushCoalescedWrites()
                            }
                            if (currentByteOffset > bytesAtAttemptStart) {
                                streamAttempt = 0
                            }
                            if (currentByteOffset < item.sizeBytes && !isPausedProvider() && !isSingleFilePaused()) {
                                throw java.io.IOException("انقطع التدفق الشبكي قبل اكتمال الملف عند الإزاحة $currentByteOffset")
                            }
                        } catch (ce: CancellationException) {
                            throw ce
                        } catch (e: Exception) {
                            runCatching { flushCoalescedWrites() }
                            runCatching { raf.setLength(currentByteOffset) }
                            if (isSingleFileCancelled()) {
                                return@coroutineScope cancelOnlyThisFile()
                            }
                            if (isStorageFullException(e) || isPermissionOrUnreadableException(e)) {
                                throw e
                            }
                            if (isPausedProvider()) {
                                streamAttempt = 0
                                continue
                            }
                            android.util.Log.w(LOG_TAG, "Stream attempt $streamAttempt for ${item.name} interrupted at byte $currentByteOffset: ${e.message}")
                            if (streamAttempt >= 5) {
                                throw java.io.IOException(
                                    "انقطع الاتصال أثناء نقل الملف بعد عدة محاولات — تم حفظ الجزء المنقول (.part) ويمكنك الضغط على إعادة المحاولة للاستئناف",
                                    e
                                )
                            }
                            onFileUpdated(item.id, 0.0, 0.0) { f ->
                                f.copy(
                                    transferredBytes = minOf(f.sizeBytes, currentByteOffset),
                                    currentSpeedBytesPerSec = 0.0,
                                    status = FileTransferStatus.RETRYING,
                                    retryCount = streamAttempt,
                                    errorMessage = "محاولة استئناف تلقائية ($streamAttempt/5) من موضع التوقف..."
                                )
                            }
                            sendAckToSender(
                                hostIp = hostIp,
                                hostPort = hostPort,
                                sessionCode = sessionCode,
                                fileId = item.id,
                                status = FileTransferStatus.RETRYING,
                                verified = false,
                                transferredBytes = currentByteOffset
                            )
                            delay(200L * streamAttempt)
                        } finally {
                            runCatching { conn?.disconnect() }
                        }
                    }
                }

                if (isSingleFileCancelled()) {
                    return@coroutineScope cancelOnlyThisFile()
                }

                // Verify exact file size and on-the-fly SHA-256 digest before exposing final file
                onFileUpdated(item.id, 0.0, 0.0) {
                    it.copy(status = FileTransferStatus.VERIFYING, currentSpeedBytesPerSec = 0.0, errorMessage = null)
                }
                sendAckToSender(
                    hostIp = hostIp,
                    hostPort = hostPort,
                    sessionCode = sessionCode,
                    fileId = item.id,
                    status = FileTransferStatus.VERIFYING,
                    verified = false,
                    transferredBytes = item.sizeBytes
                )

                val actualLength = tempPartFile.length()
                if (actualLength != item.sizeBytes) {
                    if (isSingleFileCancelled()) {
                        return@coroutineScope cancelOnlyThisFile("تم إلغاء نقل هذا الملف")
                    }
                    if (actualLength > item.sizeBytes) {
                        runCatching {
                            RandomAccessFile(tempPartFile, "rw").use { it.setLength(0L) }
                        }
                    }
                    throw IllegalStateException("انقطع الاتصال قبل اكتمال الملف (تم حفظ $actualLength بايت من أصل ${item.sizeBytes} بايت — جاهز للاستئناف)")
                }

                val computedSha256 = Sha256Util.bytesToHex(digest.digest())
                val expectedSha256 = item.sha256Expected
                val shaMatches = expectedSha256.isBlank() || computedSha256.equals(expectedSha256, ignoreCase = true)
                if (!shaMatches) {
                    // Corrupted .part payload: reset .part so next retry starts cleanly without keeping corrupt bytes
                    runCatching { tempPartFile.delete() }
                    throw IllegalStateException("HASH_MISMATCH: فشل التحقق من سلامة الملف (SHA-256 غير متطابق — تم حذف الجزء التالف لإعادة التحميل بأمان)")
                }

                if (finalOutFile.exists()) finalOutFile.delete()
                val renamed = tempPartFile.renameTo(finalOutFile)
                val savedFile = if (renamed) {
                    finalOutFile
                } else {
                    try {
                        tempPartFile.inputStream().use { inp ->
                            FileOutputStream(finalOutFile).use { outp ->
                                inp.copyTo(outp, STREAM_READ_BUFFER_BYTES)
                            }
                        }
                        tempPartFile.delete()
                        finalOutFile
                    } catch (copyErr: Exception) {
                        runCatching { if (finalOutFile.exists() && finalOutFile.length() != item.sizeBytes) finalOutFile.delete() }
                        throw IllegalStateException("تعذر حفظ الملف النهائي بعد التحقق: ${copyErr.message ?: ""}")
                    }
                }

                sendAckToSender(
                    hostIp = hostIp,
                    hostPort = hostPort,
                    sessionCode = sessionCode,
                    fileId = item.id,
                    status = FileTransferStatus.COMPLETED,
                    verified = true,
                    transferredBytes = item.sizeBytes
                )

                val totalElapsedSec = max(0.002, (System.nanoTime() - fileStartNano) / 1_000_000_000.0)
                val avgSpeed = bytesDownloadedForThisFile.toDouble() / totalElapsedSec

                var completedSnapshot: TransferFileItem? = null
                onFileUpdated(item.id, avgSpeed, avgSpeed) { f ->
                    val done = f.copy(
                        completedChunks = totalChunks,
                        transferredBytes = f.sizeBytes,
                        currentSpeedBytesPerSec = 0.0,
                        status = FileTransferStatus.COMPLETED,
                        savedPath = savedFile.absolutePath,
                        sha256Actual = computedSha256,
                        sha256Verified = true,
                        errorMessage = null,
                        failureDiagnosticCode = null
                    )
                    completedSnapshot = done
                    done
                }

                completedSnapshot?.let { onFileCompleted(it, avgSpeed) }
                true
            } catch (ce: CancellationException) {
                runCatching { if (tempPartFile.exists()) tempPartFile.delete() }
                onFileUpdated(item.id, 0.0, 0.0) { f ->
                    if (f.status == FileTransferStatus.COMPLETED) f
                    else f.copy(status = FileTransferStatus.CANCELLED, currentSpeedBytesPerSec = 0.0)
                }
                sendAckToSender(
                    hostIp = hostIp,
                    hostPort = hostPort,
                    sessionCode = sessionCode,
                    fileId = item.id,
                    status = FileTransferStatus.CANCELLED,
                    verified = false,
                    transferredBytes = 0L
                )
                throw ce
            } catch (t: Throwable) {
                if (isSingleFileCancelled()) {
                    return@coroutineScope cancelOnlyThisFile()
                }
                val partialBytesOnDisk = if (tempPartFile.exists()) tempPartFile.length().coerceIn(0L, item.sizeBytes) else 0L
                val rawMessage = t.message.orEmpty()
                val diagCode = when {
                    rawMessage.contains("SOURCE_PERMISSION_LOST") || rawMessage.contains("المرسِل") -> "SOURCE_PERMISSION_LOST"
                    rawMessage.contains("DEST_PERMISSION_LOST") || rawMessage.contains("مجلد الحفظ") -> "DEST_PERMISSION_LOST"
                    rawMessage.contains("SOURCE_FILE_NOT_FOUND") || rawMessage.contains("HTTP 404") -> "SOURCE_FILE_NOT_FOUND"
                    isStorageFullException(t) -> "DEST_STORAGE_FULL"
                    rawMessage.contains("HASH_MISMATCH") || rawMessage.contains("SHA-256") -> "HASH_MISMATCH"
                    rawMessage.contains("HTTP 416") || rawMessage.contains("OFFSET_OUT_OF_RANGE") -> "HTTP_RANGE_ERROR"
                    rawMessage.contains("STREAM_WRITE_ERROR") -> "STREAM_WRITE_ERROR"
                    isPermissionOrUnreadableException(t) -> "PERMISSION_LOST"
                    t is java.net.SocketException || t is java.net.SocketTimeoutException || t is java.net.ConnectException -> "NETWORK_DISCONNECTED"
                    else -> "STREAM_READ_ERROR"
                }
                val destPermOk = runCatching { isDirectoryWritableWithPermissions(parentDir) }.getOrDefault(false)
                val redactedUri = item.uri?.let { "${it.scheme}://${it.authority}/..." } ?: "local"
                android.util.Log.e(
                    LOG_TAG,
                    "DIAG[deviceSide=RECEIVER, stage=DOWNLOAD_STREAM, fileId=${item.id}, fileName=${item.name}, " +
                        "sourceUri=$redactedUri, sizeBytes=${item.sizeBytes}, diagnosticCode=$diagCode, " +
                        "exceptionClass=${t.javaClass.simpleName}, originalMessage=$rawMessage, " +
                        "retryCount=${item.retryCount}, lastValidOffset=$partialBytesOnDisk, " +
                        "sourcePermissionOk=${diagCode != "SOURCE_PERMISSION_LOST"}, destPermissionOk=$destPermOk]"
                )
                val errMsg = when {
                    t is OutOfMemoryError -> "الذاكرة المؤقتة غير كافية؛ أعد المحاولة لاستئناف التدفق المتجزئ الآمن"
                    isStorageFullException(t) -> "امتلأت المساحة التخزينية للجهاز — تم الاحتفاظ بالجزء المحمّل (${partialBytesOnDisk / (1024L * 1024L)} MB) لاستئنافه فور تفريغ مساحة"
                    diagCode == "SOURCE_PERMISSION_LOST" -> "فُقدت صلاحية قراءة الملف لدى المرسِل — يرجى إعادة تحديد الملف"
                    diagCode == "DEST_PERMISSION_LOST" -> "فُقدت صلاحية الكتابة في مجلد الحفظ — يرجى إعادة اختيار مجلد الحفظ عند الضرورة"
                    diagCode == "SOURCE_FILE_NOT_FOUND" -> "الملف المصدر لم يعد موجوداً لدى المرسِل"
                    isPermissionOrUnreadableException(t) -> "فُقدت صلاحية الوصول إلى الملف أو مجلد الحفظ أثناء النقل — يرجى التحقق من الصلاحية وإعادة المحاولة"
                    else -> rawMessage.removePrefix("HASH_MISMATCH: ").removePrefix("STREAM_WRITE_ERROR: ")
                        .takeIf { it.isNotBlank() && !it.startsWith("HTTP ") }
                        ?: "انقطع الاتصال أثناء نقل الملف — تم حفظ الجزء المنقول (.part) ويمكنك الضغط على إعادة المحاولة للاستئناف"
                }
                var failedSnap: TransferFileItem? = null
                onFileUpdated(item.id, 0.0, 0.0) { f ->
                    val failed = f.copy(
                        transferredBytes = partialBytesOnDisk,
                        status = FileTransferStatus.FAILED,
                        currentSpeedBytesPerSec = 0.0,
                        errorMessage = errMsg,
                        failureDiagnosticCode = diagCode
                    )
                    failedSnap = failed
                    failed
                }
                sendAckToSender(
                    hostIp = hostIp,
                    hostPort = hostPort,
                    sessionCode = sessionCode,
                    fileId = item.id,
                    status = FileTransferStatus.FAILED,
                    verified = false,
                    transferredBytes = partialBytesOnDisk,
                    errorMessage = errMsg
                )
                failedSnap?.let { onFileFailed(it, errMsg) }
                false
            }
        }

        internal fun isDirectoryWritableWithPermissions(dir: File): Boolean {
            if (!dir.exists() || !dir.isDirectory) return false
            if (!dir.canWrite()) return false
            return try {
                val perms = java.nio.file.Files.getPosixFilePermissions(dir.toPath())
                val path = dir.absolutePath
                if (path.startsWith("/storage/") || path.startsWith("/sdcard")) {
                    perms.contains(java.nio.file.attribute.PosixFilePermission.OWNER_WRITE) ||
                        perms.contains(java.nio.file.attribute.PosixFilePermission.GROUP_WRITE) ||
                        perms.contains(java.nio.file.attribute.PosixFilePermission.OTHERS_WRITE)
                } else {
                    perms.contains(java.nio.file.attribute.PosixFilePermission.OWNER_WRITE)
                }
            } catch (_: Throwable) {
                dir.canWrite()
            }
        }

        internal fun isStorageFullException(t: Throwable?): Boolean {
            var cur = t
            while (cur != null) {
                val msg = cur.message.orEmpty().lowercase(Locale.ROOT)
                if (msg.contains("enospc") ||
                    msg.contains("no space left") ||
                    msg.contains("disk full") ||
                    msg.contains("المساحة التخزينية غير كافية")
                ) {
                    return true
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP &&
                    cur is android.system.ErrnoException &&
                    cur.errno == android.system.OsConstants.ENOSPC
                ) {
                    return true
                }
                cur = cur.cause
            }
            return false
        }

        internal fun isPermissionOrUnreadableException(t: Throwable?): Boolean {
            var cur = t
            while (cur != null) {
                if (cur is SecurityException) return true
                val msg = cur.message.orEmpty().lowercase(Locale.ROOT)
                if (msg.contains("eacces") ||
                    msg.contains("eperm") ||
                    msg.contains("permission denied") ||
                    msg.contains("operation not permitted") ||
                    msg.contains("source_file_unreadable") ||
                    msg.contains("source_permission_lost") ||
                    msg.contains("dest_permission_lost")
                ) {
                    return true
                }
                cur = cur.cause
            }
            return false
        }

        private fun sendAckToSender(
            hostIp: String,
            hostPort: Int,
            sessionCode: String,
            fileId: String,
            status: FileTransferStatus = FileTransferStatus.COMPLETED,
            verified: Boolean = true,
            transferredBytes: Long = -1L,
            errorMessage: String? = null
        ) {
            if (hostIp.isBlank() || hostPort <= 0) return
            try {
                val encodedFileId = URLEncoder.encode(fileId, "UTF-8")
                val encodedCode = URLEncoder.encode(sessionCode, "UTF-8")
                val encodedStatus = URLEncoder.encode(status.name, "UTF-8")
                val encodedErr = if (!errorMessage.isNullOrBlank()) {
                    "&error=${URLEncoder.encode(errorMessage, "UTF-8")}"
                } else ""
                val bytesParam = if (transferredBytes >= 0L) "&bytes=$transferredBytes" else ""
                val ackUrl = URL(
                    "http://$hostIp:$hostPort/api/ack?fileId=$encodedFileId&status=$encodedStatus&verified=$verified$bytesParam&code=$encodedCode$encodedErr"
                )
                val conn = (ackUrl.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 2500
                    readTimeout = 2500
                    setRequestProperty("Connection", "keep-alive")
                }
                try {
                    conn.responseCode
                } finally {
                    runCatching { conn.disconnect() }
                }
            } catch (_: Exception) {
            }
        }
    }
}
