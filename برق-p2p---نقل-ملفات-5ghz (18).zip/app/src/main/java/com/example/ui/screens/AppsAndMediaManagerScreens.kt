package com.example.ui.screens

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DeviceMediaRepository
import com.example.model.DeviceMediaItem
import com.example.model.FileCategory
import com.example.model.FileTransferStatus
import com.example.model.FilesSubTab
import com.example.model.FolderStatsStatus
import com.example.model.InstalledAppItem
import com.example.model.MediaViewMode
import com.example.model.ReceivedApkItem
import com.example.model.SortOption
import com.example.model.StorageFolderItem
import com.example.model.TransferDirection
import com.example.model.TransferHistoryRecord
import com.example.ui.components.CopyrightFooter
import com.example.ui.components.SelectionBottomActionBar
import com.example.ui.components.categoryIcon
import com.example.ui.components.formatBytesArabic
import com.example.ui.components.formatDurationArabic
import com.example.ui.components.formatSpeedArabic
import com.example.ui.theme.CoralRose
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HotspotAmber
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.InspectedItemDetails
import com.example.viewmodel.P2PUiState
import android.graphics.BitmapFactory
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Section 3: Installed Applications Screen showing real colored app icons, app name,
 * package name, actual APK size, split APK warnings, search, and multi-selection.
 */
@Composable
fun InstalledAppsScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onToggleSystemApps: (Boolean) -> Unit,
    onRefreshApps: () -> Unit,
    onToggleSelectApp: (String) -> Unit,
    onSelectAllVisible: (List<String>) -> Unit,
    onClearSelection: () -> Unit,
    onAddSelectedToSend: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val filteredApps = remember(uiState.installedApps, uiState.appsSearchQuery) {
        val q = uiState.appsSearchQuery.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) uiState.installedApps
        else uiState.installedApps.filter {
            it.appName.lowercase(Locale.ROOT).contains(q) ||
                it.packageName.lowercase(Locale.ROOT).contains(q)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    ScreenTopBar(
                        title = "التطبيقات المثبتة (${filteredApps.size})",
                        subtitle = "حدد تطبيقاً أو أكثر لإرسال حزمة التثبيت APK",
                        accentColor = NeonEmerald,
                        onBack = onBack
                    )
                }
                IconButton(
                    onClick = onRefreshApps,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, CircleShape)
                        .testTag("refresh_installed_apps_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "تحديث قائمة التطبيقات",
                        tint = ElectricCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Important Android APK sharing notice (Section 3 requirement)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF1A2234))
                    .border(1.dp, HotspotAmber.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "تنبيه تقني: إرسال التطبيق يشارك ملف التثبيت الأساسي (APK) فقط ولا يشمل بيانات التطبيق الخاصة أو الحسابات المسجلة. التطبيقات المقسمة (Split APKs) قد تتطلب مثبت حزم مخصص على الجهاز المستلم.",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFFFDE68A)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search & System Apps Filter Row
            OutlinedTextField(
                value = uiState.appsSearchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("ابحث باسم التطبيق أو اسم الحزمة (Package)...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = ElectricCyan) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricCyan,
                    unfocusedBorderColor = GlassBorder,
                    focusedContainerColor = MidnightSurface,
                    unfocusedContainerColor = MidnightSurface
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("apps_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = uiState.includeSystemApps,
                        onCheckedChange = onToggleSystemApps,
                        colors = SwitchDefaults.colors(checkedThumbColor = ElectricCyan),
                        modifier = Modifier.testTag("toggle_system_apps_switch")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "إظهار تطبيقات النظام",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { onSelectAllVisible(filteredApps.map { it.packageName }) },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("select_all_apps_button")
                    ) {
                        Icon(Icons.Filled.SelectAll, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تحديد الكل", fontSize = 12.sp, color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (uiState.isLoadingApps) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = ElectricCyan)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("جاري فحص التطبيقات المثبتة وجلب الأيقونات الحقيقية...", color = TextSecondary)
                    }
                }
            } else if (filteredApps.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MidnightCard)
                        .padding(24.dp)
                ) {
                    Text(
                        text = "لا توجد تطبيقات مطابقة للبحث. يمكنك تفعيل خيار (إظهار تطبيقات النظام) لعرض كافة الحزم المثبتة.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("installed_apps_lazy_column")
                ) {
                    items(filteredApps, key = { it.packageName }) { app ->
                        val isSelected = app.packageName in uiState.selectedAppPackages
                        InstalledAppRowCard(
                            app = app,
                            isSelected = isSelected,
                            onToggleSelect = { onToggleSelectApp(app.packageName) }
                        )
                    }
                }
            }
        }

        SelectionBottomActionBar(
            selectedCount = uiState.totalSelectedCountInManager,
            selectedBytes = uiState.totalSelectedBytesInManager,
            onClearSelection = onClearSelection,
            onAddSelectedToSendQueue = onAddSelectedToSend,
            isSessionActive = uiState.isSenderReady || uiState.isTransferRunning
        )

        CopyrightFooter()
    }
}

@Composable
private fun InstalledAppRowCard(
    app: InstalledAppItem,
    isSelected: Boolean,
    onToggleSelect: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) Color(0xFF102A3A) else MidnightCard)
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) ElectricCyan else GlassBorder,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onToggleSelect)
            .padding(12.dp)
            .testTag("installed_app_card_${app.packageName}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            // Real colored application icon from PackageManager
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0A1424))
                    .padding(4.dp)
            ) {
                if (app.iconBitmap != null) {
                    Image(
                        bitmap = app.iconBitmap,
                        contentDescription = app.appName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.Android,
                        contentDescription = app.appName,
                        tint = NeonEmerald,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = app.appName,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (app.hasSplitApks) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = HotspotAmber.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "Split (${app.splitCount + 1})",
                                fontSize = 10.sp,
                                color = HotspotAmber,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Text(
                    text = app.packageName,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "الإصدار: v${app.versionName} • الحجم: ${formatBytesArabic(app.sizeBytes)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricCyan
                )
            }
        }

        Checkbox(
            checked = isSelected,
            onCheckedChange = { onToggleSelect() },
            colors = CheckboxDefaults.colors(
                checkedColor = ElectricCyan,
                checkmarkColor = Color(0xFF002229)
            )
        )
    }
}

/**
 * Section 2: Real Media Category Screen (Used for Images, Videos, and Audio/Music tabs).
 * Displays real thumbnails, durations, sizes, search, sorting, runtime permission prompt with rationale, and SAF picker.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MediaCategoryScreen(
    title: String,
    subtitle: String,
    category: FileCategory,
    items: List<DeviceMediaItem>,
    uiState: P2PUiState,
    onBack: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onSortOptionChange: (SortOption) -> Unit,
    onPermissionsResult: (Map<String, Boolean>) -> Unit,
    onRefreshMedia: () -> Unit,
    onPickSafFiles: (List<Uri>) -> Unit,
    onPickSafFolder: (Uri) -> Unit = {},
    onOpenSavedSafFolder: (Uri, String) -> Unit = { _, _ -> },
    onToggleViewMode: () -> Unit = {},
    onLoadNextMediaBatch: () -> Unit = {},
    onToggleSelectMedia: (String) -> Unit,
    onSelectAllVisible: (List<String>) -> Unit,
    onClearSelection: () -> Unit,
    onAddSelectedToSend: () -> Unit,
    onInspectMediaItem: (DeviceMediaItem) -> Unit = {},
    onDismissInspectedItem: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    var showLocalPermissionRationale by remember { mutableStateOf(false) }

    val permissionsToRequest = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { resultMap ->
        onPermissionsResult(resultMap)
    }

    val safFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) onPickSafFiles(uris)
    }

    val safFolderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri != null) onPickSafFolder(treeUri)
    }

    uiState.inspectedItemDetails?.let { details ->
        InspectedItemDetailsDialog(
            details = details,
            onDismiss = onDismissInspectedItem
        )
    }

    if (showLocalPermissionRationale) {
        PermissionRationaleDialog(
            onConfirmRequestPermission = {
                showLocalPermissionRationale = false
                permissionLauncher.launch(permissionsToRequest)
            },
            onUseSafInstead = {
                showLocalPermissionRationale = false
                val mimeFilter = when (category) {
                    FileCategory.IMAGE -> arrayOf("image/*")
                    FileCategory.VIDEO -> arrayOf("video/*")
                    FileCategory.AUDIO -> arrayOf("audio/*")
                    else -> arrayOf("*/*")
                }
                safFilePickerLauncher.launch(mimeFilter)
            },
            onDismiss = { showLocalPermissionRationale = false }
        )
    }

    // Category-specific scan & permission flags so we never show an empty state prematurely
    val isCategoryScanning = when (category) {
        FileCategory.IMAGE -> uiState.isLoadingImages || (uiState.isLoadingMedia && !uiState.hasCompletedInitialImageScan)
        FileCategory.VIDEO -> uiState.isLoadingVideos || (uiState.isLoadingMedia && !uiState.hasCompletedInitialVideoScan)
        FileCategory.AUDIO -> uiState.isLoadingAudio || (uiState.isLoadingMedia && !uiState.hasCompletedInitialAudioScan)
        else -> uiState.isLoadingMedia
    }
    val hasCategoryCompletedInitialScan = when (category) {
        FileCategory.IMAGE -> uiState.hasCompletedInitialImageScan
        FileCategory.VIDEO -> uiState.hasCompletedInitialVideoScan
        FileCategory.AUDIO -> uiState.hasCompletedInitialAudioScan
        else -> !uiState.isLoadingMedia
    }
    val hasCategoryPermission = when (category) {
        FileCategory.IMAGE -> uiState.hasImagePermission || uiState.hasMediaPermissions
        FileCategory.VIDEO -> uiState.hasVideoPermission || uiState.hasMediaPermissions
        FileCategory.AUDIO -> uiState.hasAudioPermission || uiState.hasMediaPermissions
        else -> uiState.hasMediaPermissions
    }

    var visiblePageLimit by remember(category, uiState.mediaSearchQuery, uiState.sortOption) {
        mutableIntStateOf(60)
    }
    val effectivePageLimit = maxOf(visiblePageLimit, uiState.mediaVisiblePageLimit)

    val filteredAndSorted = remember(items, uiState.mediaSearchQuery, uiState.sortOption) {
        val q = uiState.mediaSearchQuery.trim().lowercase(Locale.ROOT)
        val filtered = if (q.isEmpty()) items else items.filter {
            it.name.lowercase(Locale.ROOT).contains(q) ||
                it.bucketOrFolderName.lowercase(Locale.ROOT).contains(q) ||
                it.relativePathInStorage.lowercase(Locale.ROOT).contains(q)
        }
        when (uiState.sortOption) {
            SortOption.DATE_DESC -> filtered.sortedByDescending { it.dateModifiedMillis }
            SortOption.DATE_ASC -> filtered.sortedBy { it.dateModifiedMillis }
            SortOption.NAME_ASC -> filtered.sortedBy { it.name.lowercase(Locale.ROOT) }
            SortOption.NAME_DESC -> filtered.sortedByDescending { it.name.lowercase(Locale.ROOT) }
            SortOption.SIZE_DESC -> filtered.sortedByDescending { it.sizeBytes }
            SortOption.SIZE_ASC -> filtered.sortedBy { it.sizeBytes }
            SortOption.TYPE_ASC -> filtered.sortedWith(
                compareBy<DeviceMediaItem> { it.fileExtensionBadge.lowercase(Locale.ROOT) }
                    .thenBy { it.name.lowercase(Locale.ROOT) }
            )
        }
    }

    val pagedMediaItems = remember(filteredAndSorted, effectivePageLimit) {
        if (filteredAndSorted.size <= effectivePageLimit) filteredAndSorted
        else filteredAndSorted.subList(0, effectivePageLimit)
    }

    val lazyListState = rememberLazyListState()
    val lazyGridState = rememberLazyGridState()

    val shouldLoadNextBatch by remember(filteredAndSorted.size, effectivePageLimit, uiState.mediaViewMode) {
        derivedStateOf {
            if (filteredAndSorted.size <= effectivePageLimit) {
                false
            } else if (uiState.mediaViewMode == MediaViewMode.GRID) {
                val layoutInfo = lazyGridState.layoutInfo
                val totalVisible = layoutInfo.totalItemsCount
                val lastVisibleIndex = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                totalVisible > 0 && lastVisibleIndex >= (totalVisible - 12).coerceAtLeast(0)
            } else {
                val layoutInfo = lazyListState.layoutInfo
                val totalVisible = layoutInfo.totalItemsCount
                val lastVisibleIndex = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                totalVisible > 0 && lastVisibleIndex >= (totalVisible - 10).coerceAtLeast(0)
            }
        }
    }

    LaunchedEffect(shouldLoadNextBatch) {
        if (shouldLoadNextBatch && filteredAndSorted.size > visiblePageLimit) {
            visiblePageLimit = (visiblePageLimit + 60).coerceAtMost(filteredAndSorted.size)
            onLoadNextMediaBatch()
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    ScreenTopBar(
                        title = "$title (${filteredAndSorted.size})",
                        subtitle = subtitle,
                        accentColor = Color(category.badgeColorHex),
                        onBack = onBack
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (uiState.mediaViewMode == MediaViewMode.GRID) {
                            ElectricCyan.copy(alpha = 0.22f)
                        } else {
                            MidnightCard
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .border(
                                1.dp,
                                if (uiState.mediaViewMode == MediaViewMode.GRID) ElectricCyan else GlassBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable(onClick = onToggleViewMode)
                            .testTag("toggle_media_view_mode_chip")
                    ) {
                        Text(
                            text = if (uiState.mediaViewMode == MediaViewMode.GRID) "شبكة ⊞" else "قائمة ☰",
                            style = MaterialTheme.typography.labelMedium,
                            color = ElectricCyan,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                        )
                    }
                    IconButton(
                        onClick = onRefreshMedia,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MidnightCard)
                            .border(1.dp, GlassBorder, CircleShape)
                            .testTag("refresh_media_category_button")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = "تحديث", tint = ElectricCyan)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Runtime Permission Banner with explanation before requesting (only when permission is not granted AND no persisted SAF folder is active)
            if (!hasCategoryPermission) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF28190B))
                        .border(1.dp, HotspotAmber, RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = uiState.permissionDeniedMessage
                                ?: "لماذا نحتاج الإذن؟ لعرض جميع الصور والفيديوهات والصوتيات في هذا القسم تلقائياً من جهازك دون الحاجة لاختيارها يدوياً في كل مرة.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { showLocalPermissionRationale = true },
                                colors = ButtonDefaults.buttonColors(containerColor = HotspotAmber),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("grant_media_permissions_button")
                            ) {
                                Icon(Icons.Filled.LockOpen, contentDescription = null, tint = Color(0xFF1F1200), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("شرح ومنح الصلاحية", color = Color(0xFF1F1200), fontWeight = FontWeight.Bold)
                            }
                            if (uiState.persistedSafFolders.isEmpty()) {
                                OutlinedButton(
                                    onClick = {
                                        val mimeFilter = when (category) {
                                            FileCategory.IMAGE -> arrayOf("image/*")
                                            FileCategory.VIDEO -> arrayOf("video/*")
                                            FileCategory.AUDIO -> arrayOf("audio/*")
                                            else -> arrayOf("*/*")
                                        }
                                        safFilePickerLauncher.launch(mimeFilter)
                                    },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("اختيار عبر النظام (SAF)", color = ElectricCyan)
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Revoked SAF Folder diagnostic notice (if a previously saved SAF folder lost permission or was deleted)
            if (uiState.revokedSafFolders.isNotEmpty()) {
                val revokedNames = uiState.revokedSafFolders.joinToString("، ") { it.displayName }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF2D1219))
                        .border(1.dp, CoralRose.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                        .padding(10.dp)
                        .testTag("revoked_saf_warning_banner")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "تم إلغاء صلاحية المجلد المحفوظ ($revokedNames) أو حذفه من النظام. يمكنك استعادة الصلاحية عند الحاجة.",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        OutlinedButton(
                            onClick = { safFolderPickerLauncher.launch(null) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("تحديث المجلد", color = ElectricCyan, fontSize = 10.sp)
                        }
                    }
                }
            }

            // Search & Sort Controls
            OutlinedTextField(
                value = uiState.mediaSearchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("ابحث بالاسم أو المجلد...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = ElectricCyan) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricCyan,
                    unfocusedBorderColor = GlassBorder,
                    focusedContainerColor = MidnightSurface,
                    unfocusedContainerColor = MidnightSurface
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("media_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                SortOption.entries.forEach { sort ->
                    FilterChip(
                        selected = uiState.sortOption == sort,
                        onClick = { onSortOptionChange(sort) },
                        label = { Text(sort.arabicLabel, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricCyan.copy(alpha = 0.22f),
                            selectedLabelColor = ElectricCyan
                        )
                    )
                }
                FilterChip(
                    selected = false,
                    onClick = { onSelectAllVisible(filteredAndSorted.map { it.id }) },
                    label = { Text("تحديد الكل", fontSize = 11.sp, color = NeonEmerald) }
                )
                if (uiState.totalSelectedCountInManager > 0) {
                    FilterChip(
                        selected = false,
                        onClick = onClearSelection,
                        label = { Text("إلغاء التحديد", fontSize = 11.sp, color = CoralRose) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Progressive background scan indicator when first batches are already visible
            if (isCategoryScanning && filteredAndSorted.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                        .testTag("media_progressive_scan_strip")
                ) {
                    LinearProgressIndicator(
                        color = ElectricCyan,
                        trackColor = MidnightCard,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(999.dp))
                    )
                    Text(
                        text = "جاري استكمال فحص بقية العناصر تدريجياً (${filteredAndSorted.size} مكتشف حتى الآن)...",
                        style = MaterialTheme.typography.labelSmall,
                        color = ElectricCyan,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            // State 1: Initial scan is still in progress and no items have arrived yet -> NEVER show Empty State prematurely
            if ((isCategoryScanning || !hasCategoryCompletedInitialScan) && filteredAndSorted.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("media_scanning_loading_box")
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(color = ElectricCyan)
                        Text(
                            text = "جاري فحص مكتبة ${category.arabicLabel} في الخلفية...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "يتم جلب العناصر على دفعات سريعة دون تجميد الواجهة",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else if (filteredAndSorted.isEmpty()) {
                // State 2: Scan has genuinely finished and returned 0 matching items
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MidnightCard)
                        .padding(20.dp)
                        .testTag("media_empty_state_box")
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (category == FileCategory.VIDEO && uiState.videoScanErrorMessage != null) {
                            Text(
                                text = uiState.videoScanErrorMessage,
                                style = MaterialTheme.typography.bodyMedium,
                                color = HotspotAmber,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = onRefreshMedia,
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan)
                            ) {
                                Icon(Icons.Filled.Refresh, contentDescription = null, tint = Color(0xFF002229))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إعادة فحص الفيديوهات", color = Color(0xFF002229), fontWeight = FontWeight.Bold)
                            }
                        } else {
                            val emptyTitle = when {
                                uiState.mediaSearchQuery.isNotBlank() ->
                                    "لا توجد نتائج مطابقة للبحث «${uiState.mediaSearchQuery}» في قسم ${category.arabicLabel}."
                                !hasCategoryPermission ->
                                    "يرجى منح صلاحية قراءة ${category.arabicLabel} لعرض الملفات الموجودة في الهاتف تلقائياً."
                                else ->
                                    "لم يتم العثور على ملفات معروضة في قسم ${category.arabicLabel} بعد اكتمال الفحص."
                            }
                            Text(
                                text = emptyTitle,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = onRefreshMedia,
                                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan)
                                ) {
                                    Icon(Icons.Filled.Refresh, contentDescription = null, tint = Color(0xFF002229), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إعادة الفحص", color = Color(0xFF002229), fontWeight = FontWeight.Bold)
                                }
                                if (uiState.persistedSafFolders.isEmpty()) {
                                    OutlinedButton(
                                        onClick = {
                                            val mimeFilter = when (category) {
                                                FileCategory.IMAGE -> arrayOf("image/*")
                                                FileCategory.VIDEO -> arrayOf("video/*")
                                                FileCategory.AUDIO -> arrayOf("audio/*")
                                                else -> arrayOf("*/*")
                                            }
                                            safFilePickerLauncher.launch(mimeFilter)
                                        }
                                    ) {
                                        Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = ElectricCyan)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("اختيار ملفات إضافية", color = ElectricCyan)
                                    }
                                }
                            }
                        }

                        // If the user already granted SAF folder permissions previously, display them directly instead of asking again
                        if (uiState.persistedSafFolders.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "المجلدات المحفوظة بصلاحية نشطة (اضغط للفتح مباشرة دون إعادة الاختيار):",
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonEmerald,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.testTag("saved_saf_folders_in_media_row")
                            ) {
                                items(uiState.persistedSafFolders, key = { "saved_saf_${it.uriString}" }) { safFolder ->
                                    Surface(
                                        color = NeonEmerald.copy(alpha = 0.16f),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .border(1.dp, NeonEmerald, RoundedCornerShape(10.dp))
                                            .clickable {
                                                onOpenSavedSafFolder(safFolder.treeUri, safFolder.displayName)
                                            }
                                    ) {
                                        Text(
                                            text = "📁 ${safFolder.displayName}",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (uiState.mediaViewMode == MediaViewMode.GRID && (category == FileCategory.IMAGE || category == FileCategory.VIDEO)) {
                // Fast LazyVerticalGrid with stable keys, contentType, and automatic pagination
                LazyVerticalGrid(
                    state = lazyGridState,
                    columns = GridCells.Adaptive(minSize = 112.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("media_items_lazy_column")
                ) {
                    gridItems(
                        items = pagedMediaItems,
                        key = { it.id },
                        contentType = { it.category }
                    ) { item ->
                        MediaGridItemCard(
                            item = item,
                            isSelected = item.id in uiState.selectedMediaIds,
                            onToggleSelect = { onToggleSelectMedia(item.id) },
                            onInspectInfo = { onInspectMediaItem(item) }
                        )
                    }
                    if (filteredAndSorted.size > pagedMediaItems.size) {
                        item(
                            key = "load_more_media_page_grid",
                            span = { GridItemSpan(maxLineSpan) }
                        ) {
                            OutlinedButton(
                                onClick = {
                                    visiblePageLimit = (visiblePageLimit + 120).coerceAtMost(filteredAndSorted.size)
                                    onLoadNextMediaBatch()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .testTag("load_more_media_button")
                            ) {
                                Text(
                                    text = "عرض المزيد (${pagedMediaItems.size} من ${filteredAndSorted.size})",
                                    color = ElectricCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            } else {
                // Fast LazyColumn with stable keys, contentType, and automatic pagination
                LazyColumn(
                    state = lazyListState,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("media_items_lazy_column")
                ) {
                    items(
                        items = pagedMediaItems,
                        key = { it.id },
                        contentType = { it.category }
                    ) { item ->
                        MediaItemRowCard(
                            item = item,
                            isSelected = item.id in uiState.selectedMediaIds,
                            onToggleSelect = { onToggleSelectMedia(item.id) },
                            onInspectInfo = { onInspectMediaItem(item) }
                        )
                    }
                    if (filteredAndSorted.size > pagedMediaItems.size) {
                        item(key = "load_more_media_page") {
                            OutlinedButton(
                                onClick = {
                                    visiblePageLimit = (visiblePageLimit + 120).coerceAtMost(filteredAndSorted.size)
                                    onLoadNextMediaBatch()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .testTag("load_more_media_button")
                            ) {
                                Text(
                                    text = "عرض المزيد (${pagedMediaItems.size} من ${filteredAndSorted.size})",
                                    color = ElectricCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        SelectionBottomActionBar(
            selectedCount = uiState.totalSelectedCountInManager,
            selectedBytes = uiState.totalSelectedBytesInManager,
            selectedFoldersCount = uiState.selectedFoldersCount,
            selectedFilesCount = uiState.selectedFilesAndAppsCount,
            onClearSelection = onClearSelection,
            onAddSelectedToSendQueue = onAddSelectedToSend,
            isSessionActive = uiState.isSenderReady || uiState.isTransferRunning
        )

        CopyrightFooter()
    }
}

/**
 * Section 1: Internal File & Folder Manager with Android Permissions, Hierarchical Folder Navigation,
 * SAF (`ACTION_OPEN_DOCUMENT_TREE`) with persisted URI permissions, Game Files (`.apk`, `.xapk`, `.obb`) support,
 * and honest Android 11+ (`Android/data` & `Android/obb`) policy guidance.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FilesAndFoldersScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onSubTabChange: (FilesSubTab) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onSortOptionChange: (SortOption) -> Unit,
    onPickSafFiles: (List<Uri>) -> Unit = {},
    onPickSafFolder: (Uri) -> Unit = {},
    onBrowseSafTreeFolder: (Uri, String?, String?, Boolean) -> Unit = { _, _, _, _ -> },
    onExitSafBrowser: () -> Unit = {},
    onNavigateUpDirectory: () -> Boolean = { false },
    onInspectProtectedFolder: (String) -> Unit = {},
    onTogglePermissionRationale: (Boolean) -> Unit = {},
    onToggleStoragePolicySheet: (Boolean) -> Unit = {},
    onSendLocalFolderDirectly: (String) -> Unit = {},
    onToggleSelectFolder: (String) -> Unit = {},
    onSelectAllVisibleFoldersAndFiles: (List<String>, List<String>) -> Unit = { _, _ -> },
    onAddOrSelectFolderByPath: (String) -> Unit = {},
    onSetBrowsingFolderFilter: (String?) -> Unit = {},
    onPermissionsResult: (Map<String, Boolean>) -> Unit = {},
    onRefreshFiles: () -> Unit,
    onToggleSelectMedia: (String) -> Unit,
    onSelectAllVisible: (List<String>) -> Unit,
    onClearSelection: () -> Unit,
    onAddSelectedToSend: () -> Unit,
    onInspectMediaItem: (DeviceMediaItem) -> Unit = {},
    onInspectFolderItem: (StorageFolderItem) -> Unit = {},
    onDismissInspectedItem: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler {
        if (!onNavigateUpDirectory()) {
            if (uiState.browsingFolderFilter != null) {
                onSetBrowsingFolderFilter(null)
            } else {
                onBack()
            }
        }
    }

    var customFolderInput by remember { mutableStateOf("") }
    var showCustomPathBar by remember { mutableStateOf(false) }

    val permissionsToRequest = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    uiState.inspectedItemDetails?.let { details ->
        InspectedItemDetailsDialog(
            details = details,
            onDismiss = onDismissInspectedItem
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        onPermissionsResult(result)
    }

    val safFolderTreeBrowserLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri != null) {
            onBrowseSafTreeFolder(treeUri, null, null, true)
        }
    }

    val safSendEntireFolderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri != null) {
            onPickSafFolder(treeUri)
        }
    }

    val safMultipleFilesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            onPickSafFiles(uris)
        }
    }

    if (uiState.showPermissionRationaleDialog) {
        PermissionRationaleDialog(
            onConfirmRequestPermission = {
                onTogglePermissionRationale(false)
                permissionLauncher.launch(permissionsToRequest)
            },
            onUseSafInstead = {
                onTogglePermissionRationale(false)
                safFolderTreeBrowserLauncher.launch(null)
            },
            onDismiss = { onTogglePermissionRationale(false) }
        )
    }

    if (uiState.showAndroidStoragePolicySheet) {
        AndroidStoragePolicyDialog(
            onPickSafFolderToBrowse = {
                onToggleStoragePolicySheet(false)
                safFolderTreeBrowserLauncher.launch(null)
            },
            onPickSafFolderToSendImmediately = {
                onToggleStoragePolicySheet(false)
                safSendEntireFolderLauncher.launch(null)
            },
            onSwitchToApksAndObbTab = {
                onToggleStoragePolicySheet(false)
                onSubTabChange(FilesSubTab.APKS)
            },
            onDismiss = { onToggleStoragePolicySheet(false) }
        )
    }

    var showSortDropdown by remember { mutableStateOf(false) }
    var showCategoryDropdown by remember { mutableStateOf(false) }

    // Compute hierarchical folders & files from non-blocking ViewModel state (never call File.listFiles on Main Thread)
    val (displayedFolders, displayedFiles) = remember(
        uiState.storageFolders,
        uiState.currentBrowsingFolders,
        uiState.currentBrowsingFiles,
        uiState.deviceGeneralFiles,
        uiState.safFolderFiles,
        uiState.activeSafTreeUri,
        uiState.safBrowsingFolders,
        uiState.safBrowsingFiles,
        uiState.activeFilesSubTab,
        uiState.browsingFolderFilter,
        uiState.mediaSearchQuery,
        uiState.sortOption
    ) {
        val q = uiState.mediaSearchQuery.trim().lowercase(Locale.ROOT)

        val (rawFolders, rawFiles) = when {
            uiState.activeSafTreeUri != null -> {
                Pair(uiState.safBrowsingFolders, uiState.safBrowsingFiles)
            }
            uiState.browsingFolderFilter != null -> {
                val activeFolderClean = uiState.browsingFolderFilter.trim().trim('/')
                if (q.isEmpty()) {
                    // Immediate children loaded asynchronously on Dispatchers.IO by ViewModel
                    Pair(uiState.currentBrowsingFolders, uiState.currentBrowsingFiles)
                } else {
                    // Non-blocking in-memory search inside current folder and known nested items
                    val prefix = "$activeFolderClean/"
                    val nestedDirs = uiState.storageFolders.filter {
                        it.relativeDisplayPath.startsWith(prefix, ignoreCase = true)
                    }
                    val nestedFiles = uiState.deviceGeneralFiles.filter {
                        it.relativePathInStorage.startsWith(prefix, ignoreCase = true) ||
                            it.bucketOrFolderName.equals(activeFolderClean, ignoreCase = true) ||
                            it.bucketOrFolderName.startsWith(prefix, ignoreCase = true)
                    }
                    Pair(
                        (uiState.currentBrowsingFolders + nestedDirs).distinctBy { it.path },
                        (uiState.currentBrowsingFiles + nestedFiles).distinctBy { it.id }
                    )
                }
            }
            else -> {
                val rootFolders = if (uiState.currentBrowsingFolders.isNotEmpty()) {
                    uiState.currentBrowsingFolders
                } else {
                    uiState.storageFolders.filter { !it.relativeDisplayPath.contains('/') }
                }
                val rootImmediateFiles = uiState.currentBrowsingFiles

                val showFoldersInTab = uiState.activeFilesSubTab in setOf(
                    FilesSubTab.ALL,
                    FilesSubTab.DOWNLOADS,
                    FilesSubTab.FOLDERS,
                    FilesSubTab.RECENT
                )
                val foldersForTab = if (!showFoldersInTab) {
                    emptyList()
                } else if (uiState.activeFilesSubTab == FilesSubTab.DOWNLOADS) {
                    (rootFolders + uiState.storageFolders).distinctBy { it.path }.filter {
                        it.relativeDisplayPath.equals("Download", ignoreCase = true) ||
                            it.relativeDisplayPath.startsWith("Download/", ignoreCase = true) ||
                            it.name.equals("BarqSher", ignoreCase = true)
                    }
                } else if (q.isEmpty()) {
                    // Root of Shared Internal Storage: show actual top-level folders dynamically discovered on device
                    rootFolders
                } else {
                    (rootFolders + uiState.storageFolders).distinctBy { it.path }
                }

                val filesForTab = if (uiState.activeFilesSubTab == FilesSubTab.FOLDERS) {
                    emptyList()
                } else {
                    when (uiState.activeFilesSubTab) {
                        FilesSubTab.ALL -> if (q.isEmpty()) {
                            // At root storage level, show root-level files plus discovered general files
                            (rootImmediateFiles + uiState.deviceGeneralFiles).distinctBy { it.id }
                        } else {
                            (rootImmediateFiles + uiState.deviceGeneralFiles).distinctBy { it.id }
                        }
                        FilesSubTab.DOWNLOADS -> uiState.deviceGeneralFiles.filter {
                            it.id.startsWith("dl_") ||
                                it.bucketOrFolderName.startsWith("Download", ignoreCase = true) ||
                                it.relativePathInStorage.startsWith("Download/", ignoreCase = true) ||
                                it.bucketOrFolderName.equals("BarqSher", ignoreCase = true)
                        }
                        FilesSubTab.RECENT -> uiState.deviceGeneralFiles.take(80)
                        FilesSubTab.DOCUMENTS -> uiState.deviceGeneralFiles.filter { it.category == FileCategory.DOCUMENT }
                        FilesSubTab.ARCHIVES -> uiState.deviceGeneralFiles.filter { it.category == FileCategory.ARCHIVE }
                        FilesSubTab.APKS -> uiState.deviceGeneralFiles.filter {
                            it.category == FileCategory.GAME_APK ||
                                it.name.endsWith(".obb", ignoreCase = true) ||
                                it.name.endsWith(".xapk", ignoreCase = true) ||
                                it.name.endsWith(".apks", ignoreCase = true)
                        }
                        FilesSubTab.FOLDERS -> emptyList()
                    }
                }
                Pair(foldersForTab, filesForTab)
            }
        }

        val filteredFolders = if (q.isEmpty()) rawFolders else rawFolders.filter {
            it.name.lowercase(Locale.ROOT).contains(q) ||
                it.relativeDisplayPath.lowercase(Locale.ROOT).contains(q) ||
                it.path.lowercase(Locale.ROOT).contains(q)
        }

        // Keep standard root folders (Download, DCIM, Pictures, Movies, Documents, Music, SDCard) pinned first at root when using default sort
        val sortedFolders = when (uiState.sortOption) {
            SortOption.DATE_DESC -> if (uiState.browsingFolderFilter == null && q.isEmpty()) {
                filteredFolders
            } else {
                filteredFolders.sortedByDescending { it.lastModifiedMillis }
            }
            SortOption.DATE_ASC -> filteredFolders.sortedBy { it.lastModifiedMillis }
            SortOption.NAME_ASC -> filteredFolders.sortedBy { it.name.lowercase(Locale.ROOT) }
            SortOption.NAME_DESC -> filteredFolders.sortedByDescending { it.name.lowercase(Locale.ROOT) }
            SortOption.SIZE_DESC -> filteredFolders.sortedByDescending { it.totalBytes }
            SortOption.SIZE_ASC -> filteredFolders.sortedBy { it.totalBytes }
            SortOption.TYPE_ASC -> filteredFolders.sortedBy { it.name.lowercase(Locale.ROOT) }
        }

        val filteredFiles = if (q.isEmpty()) rawFiles else rawFiles.filter {
            it.name.lowercase(Locale.ROOT).contains(q) ||
                it.bucketOrFolderName.lowercase(Locale.ROOT).contains(q) ||
                it.relativePathInStorage.lowercase(Locale.ROOT).contains(q) ||
                it.fileExtensionBadge.lowercase(Locale.ROOT).contains(q)
        }
        val sortedFiles = when (uiState.sortOption) {
            SortOption.DATE_DESC -> filteredFiles.sortedByDescending { it.dateModifiedMillis }
            SortOption.DATE_ASC -> filteredFiles.sortedBy { it.dateModifiedMillis }
            SortOption.NAME_ASC -> filteredFiles.sortedBy { it.name.lowercase(Locale.ROOT) }
            SortOption.NAME_DESC -> filteredFiles.sortedByDescending { it.name.lowercase(Locale.ROOT) }
            SortOption.SIZE_DESC -> filteredFiles.sortedByDescending { it.sizeBytes }
            SortOption.SIZE_ASC -> filteredFiles.sortedBy { it.sizeBytes }
            SortOption.TYPE_ASC -> filteredFiles.sortedWith(
                compareBy<DeviceMediaItem> { it.category.ordinal }
                    .thenBy { it.fileExtensionBadge.lowercase(Locale.ROOT) }
                    .thenBy { it.name.lowercase(Locale.ROOT) }
            )
        }

        Pair(
            sortedFolders.distinctBy { it.path },
            sortedFiles.distinctBy { it.id }
        )
    }

    var visibleFilesLimit by remember(
        uiState.activeFilesSubTab,
        uiState.browsingFolderFilter,
        uiState.activeSafTreeUri,
        uiState.mediaSearchQuery,
        uiState.sortOption
    ) {
        mutableIntStateOf(120)
    }

    val pagedDisplayedFiles = remember(displayedFiles, visibleFilesLimit) {
        if (displayedFiles.size <= visibleFilesLimit) displayedFiles
        else displayedFiles.subList(0, visibleFilesLimit)
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            // 1. Clean Top Header Bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(
                        onClick = {
                            if (!onNavigateUpDirectory()) {
                                if (uiState.browsingFolderFilter != null) {
                                    onSetBrowsingFolderFilter(null)
                                } else {
                                    onBack()
                                }
                            }
                        },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(MidnightCard)
                            .border(1.dp, GlassBorder, CircleShape)
                            .testTag("top_bar_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "مدير الملفات (${displayedFolders.size} مجلد • ${displayedFiles.size} ملف)",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        color = if (showCustomPathBar) HotspotAmber.copy(alpha = 0.24f) else MidnightCard,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .border(
                                1.dp,
                                if (showCustomPathBar) HotspotAmber else GlassBorder,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { showCustomPathBar = !showCustomPathBar }
                            .testTag("toggle_custom_folder_bar_button")
                    ) {
                        Text(
                            text = "مسار يدوي",
                            fontSize = 10.sp,
                            color = HotspotAmber,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp)
                        )
                    }
                    IconButton(
                        onClick = { onToggleStoragePolicySheet(true) },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(MidnightCard)
                            .border(1.dp, HotspotAmber.copy(alpha = 0.5f), CircleShape)
                            .testTag("open_storage_policy_button")
                    ) {
                        Icon(
                            Icons.Filled.Info,
                            contentDescription = "سياسة التخزين ومجلدات الألعاب OBB",
                            tint = HotspotAmber,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                    IconButton(
                        onClick = onRefreshFiles,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(MidnightCard)
                            .border(1.dp, GlassBorder, CircleShape)
                            .testTag("refresh_files_and_folders_button")
                    ) {
                        Icon(
                            Icons.Filled.Refresh,
                            contentDescription = "تحديث القائمة",
                            tint = ElectricCyan,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Optional slim storage permission strip with clear explanation
            if (!uiState.hasMediaPermissions) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF1F1608))
                        .border(1.dp, HotspotAmber.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("storage_permission_banner")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = Icons.Filled.LockOpen,
                            contentDescription = null,
                            tint = HotspotAmber,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = uiState.permissionDeniedMessage
                                ?: "امسح/اسمح بصلاحية التخزين لإظهار محتويات كل المجلدات تلقائياً",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = HotspotAmber,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clickable { onTogglePermissionRationale(true) }
                            .testTag("grant_storage_permission_button")
                    ) {
                        Text(
                            text = "منح الإذن",
                            color = Color(0xFF1F1200),
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
            }

            // 2. Search Bar (searches inside current folder when browsing a folder, or across storage when at root)
            val searchPlaceholder = if (uiState.browsingFolderFilter != null) {
                "ابحث داخل المجلد الحالي (${uiState.browsingFolderFilter})..."
            } else {
                "ابحث باسم المجلد أو الملف أو الامتداد..."
            }
            OutlinedTextField(
                value = uiState.mediaSearchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = {
                    Text(
                        searchPlaceholder,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                leadingIcon = {
                    Icon(
                        Icons.Filled.Search,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(17.dp)
                    )
                },
                trailingIcon = {
                    if (uiState.mediaSearchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { onSearchQueryChange("") },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Filled.Close,
                                contentDescription = "مسح البحث",
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                },
                textStyle = MaterialTheme.typography.bodySmall.copy(color = Color.White),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricCyan,
                    unfocusedBorderColor = GlassBorder,
                    focusedContainerColor = MidnightSurface,
                    unfocusedContainerColor = MidnightSurface
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("files_and_folders_search_input")
            )

            // Collapsible Direct Folder Path Selector (e.g. "Download/ropon")
            if (showCustomPathBar) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = customFolderInput,
                        onValueChange = { customFolderInput = it },
                        placeholder = {
                            Text("مسار مجلد (مثال: Download/ropon)", fontSize = 11.sp)
                        },
                        leadingIcon = {
                            Icon(Icons.Filled.Folder, contentDescription = null, tint = HotspotAmber, modifier = Modifier.size(16.dp))
                        },
                        textStyle = MaterialTheme.typography.bodySmall.copy(color = Color.White),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = HotspotAmber,
                            unfocusedBorderColor = GlassBorder,
                            focusedContainerColor = MidnightSurface,
                            unfocusedContainerColor = MidnightSurface
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("custom_folder_path_input")
                    )

                    Button(
                        onClick = {
                            if (customFolderInput.isNotBlank()) {
                                onAddOrSelectFolderByPath(customFolderInput)
                                customFolderInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = HotspotAmber),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(42.dp)
                            .testTag("add_folder_by_path_button")
                    ) {
                        Text(
                            text = "تحديد المجلد",
                            color = Color(0xFF1F1200),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // 3. Always-visible Breadcrumb Navigation Bar (مسار التنقل بالأعلى + زر رجوع للمجلد السابق)
            val isInsideSubfolder = uiState.browsingFolderFilter != null || uiState.activeSafTreeUri != null
            val breadcrumbSegments = remember(uiState.browsingFolderFilter, uiState.activeSafTreeUri, uiState.activeSafPathLabel) {
                if (uiState.activeSafTreeUri != null) {
                    val label = uiState.activeSafPathLabel ?: "مجلد SAF"
                    label.split('/').filter { it.isNotBlank() }
                } else {
                    uiState.browsingFolderFilter?.trim('/')?.split('/')?.filter { it.isNotBlank() }.orEmpty()
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isInsideSubfolder) Color(0xFF0E2433) else MidnightSurface)
                    .border(
                        1.dp,
                        if (isInsideSubfolder) ElectricCyan.copy(alpha = 0.55f) else GlassBorder,
                        RoundedCornerShape(10.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("file_manager_breadcrumb_bar")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (isInsideSubfolder) {
                        Surface(
                            color = ElectricCyan.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .clickable { onNavigateUpDirectory() }
                                .testTag("navigate_up_folder_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "رجوع للمجلد السابق",
                                    tint = ElectricCyan,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "المجلد السابق ↑",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    LazyRow(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        item(key = "crumb_root") {
                            Text(
                                text = "📱 التخزين الداخلي",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (!isInsideSubfolder) ElectricCyan else Color.White,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable {
                                    if (uiState.activeSafTreeUri != null) onExitSafBrowser()
                                    else onSetBrowsingFolderFilter(null)
                                }
                            )
                        }
                        items(breadcrumbSegments.size, key = { idx -> "crumb_$idx" }) { idx ->
                            val segName = breadcrumbSegments[idx]
                            val targetRelPath = breadcrumbSegments.subList(0, idx + 1).joinToString("/")
                            Text(
                                text = "❯",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                            Text(
                                text = segName,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (idx == breadcrumbSegments.lastIndex) HotspotAmber else Color.White,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable {
                                    if (uiState.activeSafTreeUri == null) {
                                        onSetBrowsingFolderFilter(targetRelPath)
                                    }
                                }
                            )
                        }
                    }
                }

                if (isInsideSubfolder) {
                    Text(
                        text = "الجذر ×",
                        style = MaterialTheme.typography.labelSmall,
                        color = HotspotAmber,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .padding(start = 6.dp)
                            .clickable {
                                if (uiState.activeSafTreeUri != null) onExitSafBrowser()
                                else onSetBrowsingFolderFilter(null)
                            }
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // 4. Clean, Uncrowded Single-Line Action & Sort Bar (Dropdowns for Sort & Category + Select All + Optional SAF)
            val totalVisibleCount = displayedFolders.size + displayedFiles.size
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Sort Dropdown Button
                Box {
                    Surface(
                        color = MidnightCard,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .border(1.dp, ElectricCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable { showSortDropdown = true }
                            .testTag("sort_dropdown_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Sort,
                                contentDescription = null,
                                tint = ElectricCyan,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "ترتيب: ${uiState.sortOption.arabicLabel} ▾",
                                fontSize = 10.sp,
                                color = ElectricCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    DropdownMenu(
                        expanded = showSortDropdown,
                        onDismissRequest = { showSortDropdown = false },
                        modifier = Modifier.background(MidnightCard)
                    ) {
                        SortOption.entries.forEach { sort ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = sort.arabicLabel,
                                        color = if (uiState.sortOption == sort) ElectricCyan else Color.White,
                                        fontWeight = if (uiState.sortOption == sort) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    )
                                },
                                onClick = {
                                    onSortOptionChange(sort)
                                    showSortDropdown = false
                                }
                            )
                        }
                    }
                }

                // Category Filter Dropdown (replaces the crowded multi-row filter chips)
                Box {
                    Surface(
                        color = MidnightCard,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                            .clickable { showCategoryDropdown = true }
                            .testTag("category_filter_dropdown_button")
                    ) {
                        Text(
                            text = "العرض: ${uiState.activeFilesSubTab.arabicLabel} ▾",
                            fontSize = 10.sp,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = showCategoryDropdown,
                        onDismissRequest = { showCategoryDropdown = false },
                        modifier = Modifier.background(MidnightCard)
                    ) {
                        FilesSubTab.entries.forEach { tab ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = tab.arabicLabel,
                                        color = if (uiState.activeFilesSubTab == tab) ElectricCyan else Color.White,
                                        fontWeight = if (uiState.activeFilesSubTab == tab) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    )
                                },
                                onClick = {
                                    onSubTabChange(tab)
                                    showCategoryDropdown = false
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("🎮 فحص مجلد Android/obb", color = HotspotAmber, fontSize = 12.sp) },
                            onClick = {
                                showCategoryDropdown = false
                                onInspectProtectedFolder("Android/obb")
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("🔒 فحص مجلد Android/data", color = HotspotAmber, fontSize = 12.sp) },
                            onClick = {
                                showCategoryDropdown = false
                                onInspectProtectedFolder("Android/data")
                            }
                        )
                    }
                }

                // Select All / Deselect All + Optional SAF in a compact scrollable tail
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (totalVisibleCount > 0) {
                        item(key = "chip_select_all") {
                            Surface(
                                color = NeonEmerald.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .border(1.dp, NeonEmerald.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                                    .clickable {
                                        onSelectAllVisibleFoldersAndFiles(
                                            displayedFolders.map { it.path },
                                            displayedFiles.map { it.id }
                                        )
                                    }
                                    .testTag("select_all_visible_chip")
                            ) {
                                Text(
                                    text = "تحديد الكل ($totalVisibleCount)",
                                    fontSize = 10.sp,
                                    color = NeonEmerald,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                    if (uiState.totalSelectedCountInManager > 0) {
                        item(key = "chip_deselect_all") {
                            Surface(
                                color = CoralRose.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .border(1.dp, CoralRose.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                                    .clickable { onClearSelection() }
                                    .testTag("deselect_all_visible_chip")
                            ) {
                                Text(
                                    text = "إلغاء (${uiState.totalSelectedCountInManager})",
                                    fontSize = 10.sp,
                                    color = CoralRose,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                    item(key = "chip_saf_folder") {
                        Surface(
                            color = if (uiState.activeSafTreeUri != null) NeonEmerald.copy(alpha = 0.2f) else MidnightCard,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .border(1.dp, NeonEmerald.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .clickable { safFolderTreeBrowserLauncher.launch(null) }
                                .testTag("pick_saf_folder_in_manager_button")
                        ) {
                            Text(
                                text = "📁 مجلد SAF",
                                fontSize = 10.sp,
                                color = NeonEmerald,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                            )
                        }
                    }
                    items(uiState.persistedSafFolders, key = { "saf_${it.uriString}" }) { safItem ->
                        val isCurrentSaf = uiState.activeSafTreeUri == safItem.treeUri
                        Surface(
                            color = if (isCurrentSaf) ElectricCyan.copy(alpha = 0.2f) else MidnightCard,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .border(1.dp, if (isCurrentSaf) ElectricCyan else GlassBorder, RoundedCornerShape(8.dp))
                                .clickable { onBrowseSafTreeFolder(safItem.treeUri, safItem.displayName, null, false) }
                        ) {
                            Text(
                                text = "🔐 ${safItem.displayName}",
                                fontSize = 10.sp,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            if (uiState.isBrowsingDirectoryLoading) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 4.dp)
                        .testTag("directory_loading_indicator")
                ) {
                    LinearProgressIndicator(
                        color = ElectricCyan,
                        trackColor = MidnightCard,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(999.dp))
                    )
                    Text(
                        text = "جاري قراءة محتويات المسار في الخلفية...",
                        style = MaterialTheme.typography.labelSmall,
                        color = ElectricCyan,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            if (uiState.browsingDirectoryError != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF2B1911))
                        .border(1.dp, HotspotAmber.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                        .padding(10.dp)
                        .testTag("directory_error_banner")
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = uiState.browsingDirectoryError,
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { safFolderTreeBrowserLauncher.launch(null) },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "فتح مجلد عبر النظام (SAF)",
                                    color = Color(0xFF002619),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                            if (uiState.browsingFolderFilter != null) {
                                OutlinedButton(
                                    onClick = { onNavigateUpDirectory() },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("المجلد السابق ↑", color = ElectricCyan, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            // 5. Spacious Main File Manager List: Folders First, Then Files
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(bottom = 88.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("files_manager_lazy_column")
            ) {
                if (displayedFolders.isNotEmpty()) {
                    item(key = "folders_section_header") {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 1.dp)
                        ) {
                            Text(
                                text = "📁 المجلدات (${displayedFolders.size}) — اضغط على المجلد لفتحه، أو الدائرة لتحديده، أو مطولاً للخيارات",
                                style = MaterialTheme.typography.labelSmall,
                                color = HotspotAmber,
                                fontWeight = FontWeight.Bold
                            )
                            if (uiState.selectedFoldersCount > 0) {
                                Text(
                                    text = "محدد: ${uiState.selectedFoldersCount} مجلد",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NeonEmerald,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    items(displayedFolders, key = { "folder_${it.path}" }) { folder ->
                        val isFolderSelected = folder.path in uiState.selectedFolderPaths
                        SelectableFolderRowCard(
                            folder = folder,
                            isSelected = isFolderSelected,
                            onToggleSelect = { onToggleSelectFolder(folder.path) },
                            onInspectInfo = { onInspectFolderItem(folder) },
                            onSendFolderDirectly = { onSendLocalFolderDirectly(folder.path) },
                            onBrowseInside = {
                                if (folder.safTreeUri != null) {
                                    onBrowseSafTreeFolder(
                                        folder.safTreeUri,
                                        folder.relativeDisplayPath,
                                        folder.safDocumentId,
                                        false
                                    )
                                } else {
                                    onSetBrowsingFolderFilter(folder.relativeDisplayPath)
                                }
                            }
                        )
                    }
                }

                if (displayedFiles.isNotEmpty()) {
                    item(key = "files_section_header") {
                        Text(
                            text = "📄 الملفات (${displayedFiles.size})",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricCyan,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 2.dp, bottom = 1.dp)
                        )
                    }

                    items(pagedDisplayedFiles, key = { "file_${it.id}" }) { item ->
                        MediaItemRowCard(
                            item = item,
                            isSelected = item.id in uiState.selectedMediaIds,
                            onToggleSelect = { onToggleSelectMedia(item.id) },
                            onInspectInfo = { onInspectMediaItem(item) }
                        )
                    }

                    if (displayedFiles.size > visibleFilesLimit) {
                        item(key = "load_more_files_in_manager") {
                            LaunchedEffect(visibleFilesLimit, displayedFiles.size) {
                                visibleFilesLimit = (visibleFilesLimit + 160).coerceAtMost(displayedFiles.size)
                            }
                            OutlinedButton(
                                onClick = {
                                    visibleFilesLimit = (visibleFilesLimit + 240).coerceAtMost(displayedFiles.size)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .testTag("load_more_files_button")
                            ) {
                                Text(
                                    text = "عرض المزيد من الملفات (${pagedDisplayedFiles.size} من ${displayedFiles.size})",
                                    color = ElectricCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                if (displayedFolders.isEmpty() && displayedFiles.isEmpty() && !uiState.isBrowsingDirectoryLoading) {
                    item(key = "empty_files_and_folders_state") {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(MidnightCard)
                                .border(1.dp, GlassBorder, RoundedCornerShape(14.dp))
                                .padding(18.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = if (uiState.browsingFolderFilter != null) {
                                        "المجلد «${uiState.browsingFolderFilter}» فارغ حالياً أو يتطلب منح إذن التخزين لعرض محتوياته."
                                    } else {
                                        "لا توجد عناصر مطابقة للبحث الحالي."
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (uiState.browsingFolderFilter != null) {
                                        OutlinedButton(onClick = { onNavigateUpDirectory() }) {
                                            Text("الرجوع للمجلد السابق ↑", color = ElectricCyan, fontSize = 11.sp)
                                        }
                                    }
                                    if (!uiState.hasMediaPermissions) {
                                        Button(
                                            onClick = { onTogglePermissionRationale(true) },
                                            colors = ButtonDefaults.buttonColors(containerColor = HotspotAmber)
                                        ) {
                                            Text("منح إذن التخزين", color = Color(0xFF1F1200), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        SelectionBottomActionBar(
            selectedCount = uiState.totalSelectedCountInManager,
            selectedBytes = uiState.totalSelectedBytesInManager,
            selectedFoldersCount = uiState.selectedFoldersCount,
            selectedFilesCount = uiState.selectedFilesAndAppsCount,
            onClearSelection = onClearSelection,
            onAddSelectedToSendQueue = onAddSelectedToSend,
            isSessionActive = uiState.isSenderReady || uiState.isTransferRunning
        )
    }
}

/**
 * Pre-Permission Rationale Dialog explaining why Android media/storage permissions are requested
 * before launching the system permission prompt, and offering SAF as a privacy-preserving alternative.
 */
@Composable
fun PermissionRationaleDialog(
    onConfirmRequestPermission: () -> Unit,
    onUseSafInstead: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MidnightCard,
        titleContentColor = Color.White,
        textContentColor = TextSecondary,
        icon = {
            Icon(
                imageVector = Icons.Filled.Security,
                contentDescription = null,
                tint = HotspotAmber,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = "لماذا يطلب التطبيق صلاحية الوصول للملفات؟",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "يستخدم «برق sher» صلاحيات أندرويد القياسية لعرض ملفاتك ومجلداتك داخل مدير الملفات الداخلي لتسهيل تحديدها وإرسالها بسرعة:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White
                )
                Text(
                    text = "• صلاحيات الوسائط (READ_MEDIA_IMAGES / VIDEO / AUDIO أو READ_EXTERNAL_STORAGE): تتيح قراءة الصور والفيديوهات والصوتيات والمجلدات العامة تلقائياً.",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                Text(
                    text = "• إطار الوصول للتخزين (Storage Access Framework - SAF): يتيح لك منح التطبيق صلاحية مستمرة لمجلد محدد فقط دون منح وصول شامل لكل الجهاز.",
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricCyan
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirmRequestPermission,
                colors = ButtonDefaults.buttonColors(containerColor = HotspotAmber),
                modifier = Modifier.testTag("confirm_permission_rationale_button")
            ) {
                Text("متابعة وطلب الإذن", color = Color(0xFF1F1200), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = onUseSafInstead) {
                    Text("استخدام SAF فقط", color = ElectricCyan, fontSize = 12.sp)
                }
                TextButton(onClick = onDismiss) {
                    Text("إلغاء", color = TextSecondary)
                }
            }
        }
    )
}

/**
 * Honest explanation dialog regarding Android 11+ Scoped Storage, `MANAGE_EXTERNAL_STORAGE` policy,
 * and how to send game files (`.apk`, `.xapk`, `.obb`) and protected folders (`Android/data` & `Android/obb`).
 */
@Composable
fun AndroidStoragePolicyDialog(
    onPickSafFolderToBrowse: () -> Unit,
    onPickSafFolderToSendImmediately: () -> Unit,
    onSwitchToApksAndObbTab: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MidnightCard,
        titleContentColor = Color.White,
        textContentColor = TextSecondary,
        icon = {
            Icon(
                imageVector = Icons.Filled.Info,
                contentDescription = null,
                tint = ElectricCyan,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = "ملفات الألعاب (APK / OBB) وسياسة صلاحيات أندرويد",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "1. دعم ملفات الألعاب والحزم (.apk, .xapk, .apks, .obb):",
                    style = MaterialTheme.typography.labelLarge,
                    color = NeonEmerald,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "يمكنك تصفح وإرسال جميع ملفات التثبيت وملفات توسعة الألعاب (.obb) الموجودة في مجلد التنزيلات (Download) أو أي مجلد عام عبر تبويب (ملفات APK و OBB).",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White
                )
                Text(
                    text = "2. قيود نظام أندرويد 11+ على مجلدي Android/data و Android/obb:",
                    style = MaterialTheme.typography.labelLarge,
                    color = HotspotAmber,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "يفرض نظام Android 11+ (API 30+) قيود أمان صارمة تمنع التطبيقات الأخرى من قراءة محتويات مجلدي (Android/data) و(Android/obb) مباشرة لحماية بيانات التطبيقات، كما تقيد سياسات التوزيع صلاحية MANAGE_EXTERNAL_STORAGE.",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                Text(
                    text = "3. الحل الرسمي الآمن (SAF):",
                    style = MaterialTheme.typography.labelLarge,
                    color = ElectricCyan,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "استخدم زر (فتح مجلد عبر النظام SAF) لاختيار أي مجلد مسموح من النظام مع الاحتفاظ التلقائي بصلاحية الوصول إليه.",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onSwitchToApksAndObbTab,
                colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald)
            ) {
                Text("عرض ملفات APK و OBB", color = Color(0xFF002619), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = onPickSafFolderToBrowse) {
                    Text("تصفح مجلد SAF", color = ElectricCyan, fontSize = 11.sp)
                }
                TextButton(onClick = onDismiss) {
                    Text("إغلاق", color = TextSecondary)
                }
            }
        }
    )
}

/**
 * Android File Manager–style folder row card:
 * - Tapping the folder row directly opens/browses the folder (`onBrowseInside`).
 * - Tapping the circular checkbox selects/deselects the entire folder for multi-selection (`onToggleSelect`).
 * - Long-pressing the folder row opens a context menu with Open, Select, Send Entire Folder Immediately, and Folder Details.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SelectableFolderRowCard(
    folder: StorageFolderItem,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onBrowseInside: (() -> Unit)? = null,
    onInspectInfo: (() -> Unit)? = null,
    onSendFolderDirectly: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var showContextMenu by remember { mutableStateOf(false) }

    val folderDateText = remember(folder.lastModifiedMillis) {
        if (folder.lastModifiedMillis <= 0L) ""
        else SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(folder.lastModifiedMillis))
    }

    val (folderIcon, arabicCategoryHint) = remember(folder.name, folder.relativeDisplayPath) {
        when (folder.name.lowercase(Locale.ROOT)) {
            "download", "downloads" -> Icons.Filled.Download to "التنزيلات"
            "dcim", "camera" -> Icons.Filled.PhotoCamera to "الكاميرا والصور"
            "pictures", "screenshots" -> Icons.Filled.Image to "الصور"
            "movies", "video", "videos" -> Icons.Filled.Movie to "الفيديوهات"
            "documents" -> Icons.Filled.Description to "المستندات"
            "music", "audio", "recordings", "podcasts", "ringtones", "alarms", "notifications" -> Icons.Filled.LibraryMusic to "الصوتيات"
            "android" -> Icons.Filled.Android to "نظام أندرويد"
            "sdcard" -> Icons.Filled.SdStorage to "بطاقة الذاكرة الخارجية SD"
            else -> Icons.Filled.Folder to "مجلد"
        }
    }

    Box(modifier = modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(if (isSelected) Color(0xFF142B27) else MidnightSurface)
                .border(
                    width = if (isSelected) 1.5.dp else 1.dp,
                    color = if (isSelected) NeonEmerald else HotspotAmber.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(12.dp)
                )
                .combinedClickable(
                    onClick = {
                        if (onBrowseInside != null) onBrowseInside() else onToggleSelect()
                    },
                    onLongClick = { showContextMenu = true }
                )
                .padding(horizontal = 10.dp, vertical = 7.dp)
                .testTag("folder_item_card_${folder.name}")
        ) {
            // Independent Circular Selection Button (دائرة اختيار بجانب كل مجلد)
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected) NeonEmerald.copy(alpha = 0.22f) else HotspotAmber.copy(alpha = 0.12f)
                    )
                    .border(
                        width = 1.5.dp,
                        color = if (isSelected) NeonEmerald else HotspotAmber.copy(alpha = 0.7f),
                        shape = CircleShape
                    )
                    .clickable(onClick = onToggleSelect)
                    .testTag("folder_select_circle_${folder.name}")
            ) {
                Icon(
                    imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                    contentDescription = if (isSelected) "إلغاء تحديد المجلد ${folder.name}" else "تحديد المجلد ${folder.name} بالكامل",
                    tint = if (isSelected) NeonEmerald else HotspotAmber,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(HotspotAmber.copy(alpha = 0.18f))
                ) {
                    Icon(
                        imageVector = folderIcon,
                        contentDescription = "مجلد ${folder.name}",
                        tint = HotspotAmber,
                        modifier = Modifier.size(21.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = folder.name.ifBlank { folder.relativeDisplayPath },
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Surface(
                            color = if (isSelected) NeonEmerald.copy(alpha = 0.2f) else HotspotAmber.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(999.dp)
                        ) {
                            Text(
                                text = if (isSelected) "محدد" else arabicCategoryHint,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) NeonEmerald else HotspotAmber,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                            )
                        }
                    }

                    val subfolderMeta = if (folder.subfolderCount > 0) {
                        " • ${folder.subfolderCount} مجلد فرعي"
                    } else ""
                    val datePart = if (folderDateText.isNotEmpty()) " • $folderDateText" else ""
                    val detailsLabel = when {
                        folder.isProtectedSystemFolder ->
                            "🔒 مقيد في أندرويد 11+ • اضغط للتوضيح أو فتح SAF"
                        (folder.statsStatus == FolderStatsStatus.CALCULATING || folder.statsStatus == FolderStatsStatus.NOT_CALCULATED) &&
                            folder.fileCount == 0 && folder.subfolderCount == 0 && folder.totalBytes == 0L ->
                            "⏳ جارٍ الحساب… • اضغط لفتح المحتويات$datePart"
                        folder.statsStatus == FolderStatsStatus.APPROXIMATE_CAPPED ->
                            "+${folder.fileCount} ملف$subfolderMeta • ${formatBytesArabic(folder.totalBytes)} (تقريبي)$datePart"
                        folder.safTreeUri != null && folder.statsStatus != FolderStatsStatus.COMPLETED && folder.fileCount == 0 && folder.totalBytes == 0L ->
                            "⏳ جارٍ الحساب… (SAF) • اضغط لفتحه أو الدائرة لتحديده"
                        folder.statsStatus == FolderStatsStatus.COMPLETED && folder.fileCount == 0 && folder.subfolderCount == 0 && folder.totalBytes == 0L ->
                            "مجلد فارغ (${folder.relativeDisplayPath}) • اضغط لفتح المحتويات$datePart"
                        else ->
                            "${folder.fileCount} ملف$subfolderMeta • ${formatBytesArabic(folder.totalBytes)}$datePart"
                    }
                    Text(
                        text = detailsLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) ElectricCyan else TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                if (onInspectInfo != null) {
                    IconButton(
                        onClick = onInspectInfo,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(MidnightCard)
                            .border(1.dp, GlassBorder, CircleShape)
                            .testTag("folder_info_button_${folder.name}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = "معلومات المجلد ${folder.name}",
                            tint = HotspotAmber,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
                if (onBrowseInside != null) {
                    IconButton(
                        onClick = onBrowseInside,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(MidnightCard)
                            .border(1.dp, GlassBorder, CircleShape)
                            .testTag("browse_inside_folder_${folder.name}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FolderOpen,
                            contentDescription = "فتح المجلد ${folder.name}",
                            tint = ElectricCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                IconButton(
                    onClick = { showContextMenu = true },
                    modifier = Modifier
                        .size(30.dp)
                        .testTag("folder_options_menu_${folder.name}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.MoreVert,
                        contentDescription = "خيارات المجلد ${folder.name}",
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Long-press / More options context menu for folder
        DropdownMenu(
            expanded = showContextMenu,
            onDismissRequest = { showContextMenu = false },
            modifier = Modifier.background(MidnightCard)
        ) {
            if (onBrowseInside != null) {
                DropdownMenuItem(
                    text = { Text("📂 فتح واستعراض المجلد", color = ElectricCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    onClick = {
                        showContextMenu = false
                        onBrowseInside()
                    }
                )
            }
            DropdownMenuItem(
                text = {
                    Text(
                        text = if (isSelected) "✕ إلغاء تحديد المجلد" else "✓ تحديد المجلد بالكامل",
                        color = NeonEmerald,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                onClick = {
                    showContextMenu = false
                    onToggleSelect()
                }
            )
            if (onSendFolderDirectly != null) {
                DropdownMenuItem(
                    text = { Text("🚀 إرسال المجلد بالكامل الآن (مع الفرعية)", color = HotspotAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    onClick = {
                        showContextMenu = false
                        onSendFolderDirectly()
                    }
                )
            }
            if (onInspectInfo != null) {
                DropdownMenuItem(
                    text = { Text("ℹ️ خصائص وتفاصيل المجلد", color = Color.White, fontSize = 12.sp) },
                    onClick = {
                        showContextMenu = false
                        onInspectInfo()
                    }
                )
            }
        }
    }
}

private val sharedShortDateFormat = object : ThreadLocal<SimpleDateFormat>() {
    override fun initialValue(): SimpleDateFormat = SimpleDateFormat("yyyy/MM/dd", Locale.US)
}

private fun formatShortDateThreadSafe(millis: Long): String {
    if (millis <= 0L) return ""
    return sharedShortDateFormat.get()?.format(Date(millis)) ?: ""
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MediaGridItemCard(
    item: DeviceMediaItem,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onInspectInfo: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val badgeColor = Color(item.category.badgeColorHex)
    val durationText = remember(item.durationMillis) { formatDurationArabic(item.durationMillis) }

    val lazyThumbnail by produceState<ImageBitmap?>(
        initialValue = item.thumbnailBitmap ?: DeviceMediaRepository.getCachedThumbnail(item.id),
        key1 = item.id
    ) {
        if (value == null && (item.category == FileCategory.IMAGE || item.category == FileCategory.VIDEO)) {
            value = DeviceMediaRepository.getOrLoadThumbnailAsync(context, item)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(148.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) Color(0xFF102A3A) else MidnightCard)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) ElectricCyan else GlassBorder,
                shape = RoundedCornerShape(14.dp)
            )
            .combinedClickable(
                onClick = onToggleSelect,
                onLongClick = { onInspectInfo?.invoke() }
            )
            .testTag("media_item_card_${item.id}")
    ) {
        val thumb = lazyThumbnail
        if (thumb != null) {
            Image(
                bitmap = thumb,
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .background(badgeColor.copy(alpha = 0.14f))
            ) {
                Icon(
                    imageVector = categoryIcon(item.category),
                    contentDescription = item.category.arabicLabel,
                    tint = badgeColor,
                    modifier = Modifier.size(34.dp)
                )
            }
        }

        // Top selection + info overlay
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(6.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected) ElectricCyan else Color(0xAA07111A)
                    )
                    .border(1.dp, if (isSelected) Color.White else GlassBorder, CircleShape)
                    .clickable(onClick = onToggleSelect)
                    .testTag("file_select_circle_${item.id}")
            ) {
                Icon(
                    imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                    contentDescription = if (isSelected) "محدد" else "غير محدد",
                    tint = if (isSelected) Color(0xFF002229) else Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            if (onInspectInfo != null) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(0xAA07111A))
                        .clickable(onClick = onInspectInfo)
                        .testTag("file_info_button_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Info,
                        contentDescription = "معلومات الملف ${item.name}",
                        tint = ElectricCyan,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        // Bottom metadata bar (name, size, video duration)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color(0xCC060F18))
                .padding(horizontal = 8.dp, vertical = 5.dp)
        ) {
            Text(
                text = item.name,
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = formatBytesArabic(item.sizeBytes),
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricCyan,
                    fontSize = 9.sp,
                    maxLines = 1
                )
                if (durationText.isNotEmpty()) {
                    Text(
                        text = durationText,
                        style = MaterialTheme.typography.labelSmall,
                        color = HotspotAmber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MediaItemRowCard(
    item: DeviceMediaItem,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onInspectInfo: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val badgeColor = Color(item.category.badgeColorHex)
    val durationText = remember(item.durationMillis) { formatDurationArabic(item.durationMillis) }
    val dateText = remember(item.dateModifiedMillis) {
        formatShortDateThreadSafe(item.dateModifiedMillis)
    }
    var showFileContextMenu by remember { mutableStateOf(false) }

    // Load thumbnail lazily on-demand only for visible rows, backed by two-tier LruCache + DiskCache + in-flight deduplication
    val lazyThumbnail by produceState<ImageBitmap?>(
        initialValue = item.thumbnailBitmap ?: DeviceMediaRepository.getCachedThumbnail(item.id),
        key1 = item.id
    ) {
        if (value == null && (item.category == FileCategory.IMAGE || item.category == FileCategory.VIDEO)) {
            value = DeviceMediaRepository.getOrLoadThumbnailAsync(context, item)
        }
    }

    Box(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(if (isSelected) Color(0xFF102A3A) else MidnightCard)
                .border(
                    width = if (isSelected) 1.5.dp else 1.dp,
                    color = if (isSelected) ElectricCyan else GlassBorder,
                    shape = RoundedCornerShape(12.dp)
                )
                .combinedClickable(
                    onClick = onToggleSelect,
                    onLongClick = { showFileContextMenu = true }
                )
                .padding(horizontal = 10.dp, vertical = 7.dp)
                .testTag("media_item_card_${item.id}")
        ) {
            // Circular selection button matching folder rows
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) ElectricCyan.copy(alpha = 0.2f) else MidnightSurface)
                    .border(
                        width = 1.5.dp,
                        color = if (isSelected) ElectricCyan else GlassBorder,
                        shape = CircleShape
                    )
                    .clickable(onClick = onToggleSelect)
                    .testTag("file_select_circle_${item.id}")
            ) {
                Icon(
                    imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                    contentDescription = if (isSelected) "محدد" else "غير محدد",
                    tint = if (isSelected) ElectricCyan else TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(badgeColor.copy(alpha = 0.18f))
                ) {
                    val thumb = lazyThumbnail
                    if (thumb != null) {
                        Image(
                            bitmap = thumb,
                            contentDescription = item.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(
                            imageVector = categoryIcon(item.category),
                            contentDescription = item.category.arabicLabel,
                            tint = badgeColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = item.name,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Surface(
                            color = badgeColor.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = item.fileExtensionBadge,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 9.sp,
                                color = badgeColor,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                    val metaParts = buildList {
                        add(formatBytesArabic(item.sizeBytes))
                        if (durationText.isNotEmpty()) add("المدة: $durationText")
                        if (item.bucketOrFolderName.isNotEmpty()) add(item.bucketOrFolderName)
                        if (dateText.isNotEmpty()) add(dateText)
                    }
                    Text(
                        text = metaParts.joinToString(" • "),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (onInspectInfo != null) {
                IconButton(
                    onClick = onInspectInfo,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(MidnightSurface)
                        .border(1.dp, GlassBorder, CircleShape)
                        .testTag("file_info_button_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Info,
                        contentDescription = "معلومات الملف ${item.name}",
                        tint = ElectricCyan,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
        }

        DropdownMenu(
            expanded = showFileContextMenu,
            onDismissRequest = { showFileContextMenu = false },
            modifier = Modifier.background(MidnightCard)
        ) {
            DropdownMenuItem(
                text = {
                    Text(
                        text = if (isSelected) "✕ إلغاء تحديد الملف" else "✓ تحديد الملف للإرسال",
                        color = ElectricCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                onClick = {
                    showFileContextMenu = false
                    onToggleSelect()
                }
            )
            if (onInspectInfo != null) {
                DropdownMenuItem(
                    text = { Text("ℹ️ تفاصيل ومعلومات الملف", color = Color.White, fontSize = 12.sp) },
                    onClick = {
                        showFileContextMenu = false
                        onInspectInfo()
                    }
                )
            }
        }
    }
}

@Composable
fun InspectedItemDetailsDialog(
    details: InspectedItemDetails,
    onDismiss: () -> Unit
) {
    val dateFormatted = remember(details.lastModifiedMillis) {
        if (details.lastModifiedMillis <= 0L) "غير معروف"
        else SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.US).format(Date(details.lastModifiedMillis))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MidnightCard,
        titleContentColor = Color.White,
        textContentColor = TextSecondary,
        icon = {
            Icon(
                imageVector = if (details.isDirectory) Icons.Filled.Folder else Icons.Filled.Info,
                contentDescription = null,
                tint = if (details.isDirectory) HotspotAmber else ElectricCyan,
                modifier = Modifier.size(30.dp)
            )
        },
        title = {
            Text(
                text = if (details.isDirectory) "معلومات المجلد" else "معلومات الملف",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.testTag("inspected_item_details_dialog")
            ) {
                Text(
                    text = "الاسم: ${details.title}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "النوع / الفئة: ${details.categoryLabel}",
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricCyan
                )
                Text(
                    text = "الحجم الفعلي: ${formatBytesArabic(details.sizeBytes)} (${details.sizeBytes} بايت)",
                    style = MaterialTheme.typography.labelMedium,
                    color = NeonEmerald
                )
                Text(
                    text = "آخر تعديل: $dateFormatted",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                if (details.extraDetails.isNotBlank()) {
                    Text(
                        text = "تفاصيل إضافية: ${details.extraDetails}",
                        style = MaterialTheme.typography.labelMedium,
                        color = HotspotAmber
                    )
                }
                Text(
                    text = "المسار / URI:\n${details.pathOrUri}",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                modifier = Modifier.testTag("close_inspected_item_dialog_button")
            ) {
                Text("حسناً", color = Color(0xFF002229), fontWeight = FontWeight.Bold)
            }
        }
    )
}

/**
 * Section 8: Received APKs Screen ("التطبيقات المستلمة") displaying received/downloaded APK files
 * with real app name, app icon, package name, version, file size, integrity/validity check,
 * and official Android system package installer button.
 */
@Composable
fun ReceivedApksScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onRefreshApks: () -> Unit,
    onInstallApk: (ReceivedApkItem) -> Unit,
    onOpenFilesManager: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    ScreenTopBar(
                        title = "التطبيقات المستلمة (${uiState.receivedApks.size})",
                        subtitle = "فحص سلامة حزم APK المستلمة وتثبيتها عبر مثبت أندرويد الرسمي",
                        accentColor = NeonEmerald,
                        onBack = onBack
                    )
                }
                IconButton(
                    onClick = onRefreshApks,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, CircleShape)
                        .testTag("refresh_received_apks_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "تحديث التطبيقات المستلمة",
                        tint = ElectricCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF0B241E))
                    .border(1.dp, NeonEmerald.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "🔒 التثبيت الآمن: يتحقق التطبيق من اكتمال وبنية كل ملف APK مستلم في (Downloads/BarqSher)، ويستخدم مثبت الحزم الرسمي في أندرويد مع طلب موافقتك الصريحة قبل التثبيت.",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (uiState.isLoadingReceivedApks) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = NeonEmerald)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("جاري فحص ملفات APK المستلمة والتحقق من صلاحيتها...", color = TextSecondary)
                    }
                }
            } else if (uiState.receivedApks.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, RoundedCornerShape(18.dp))
                        .padding(24.dp)
                        .testTag("empty_received_apks_state")
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.Android,
                            contentDescription = null,
                            tint = NeonEmerald,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "لا توجد ملفات APK مستلمة حالياً في مجلد (Downloads/BarqSher).",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "عند استلام أي تطبيق بصيغة APK من جهاز آخر أو استخراج حزمة التطبيق، سيظهر هنا تلقائياً مع أيقونته وحالته وزر التثبيت المباشر.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(onClick = onOpenFilesManager) {
                            Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = ElectricCyan)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("فتح مدير الملفات الداخلي", color = ElectricCyan)
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("received_apks_lazy_column")
                ) {
                    items(uiState.receivedApks, key = { it.id }) { apk ->
                        ReceivedApkRowCard(
                            apk = apk,
                            onInstallClick = { onInstallApk(apk) }
                        )
                    }
                }
            }
        }

        CopyrightFooter()
    }
}

@Composable
private fun ReceivedApkRowCard(
    apk: ReceivedApkItem,
    onInstallClick: () -> Unit
) {
    val statusColor = if (apk.isValidArchive) NeonEmerald else CoralRose
    val dateStr = remember(apk.lastModifiedMillis) {
        if (apk.lastModifiedMillis <= 0L) ""
        else SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(apk.lastModifiedMillis))
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MidnightCard)
            .border(1.2.dp, statusColor.copy(alpha = 0.55f), RoundedCornerShape(16.dp))
            .padding(12.dp)
            .testTag("received_apk_card_${apk.id}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0A1424))
                        .padding(4.dp)
                ) {
                    if (apk.iconBitmap != null) {
                        Image(
                            bitmap = apk.iconBitmap,
                            contentDescription = apk.appName,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.Android,
                            contentDescription = apk.appName,
                            tint = statusColor,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = apk.appName,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (apk.packageName.isNotBlank()) {
                        Text(
                            text = apk.packageName,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                            color = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = "الحجم: ${formatBytesArabic(apk.sizeBytes)} • v${apk.versionName}" +
                            if (dateStr.isNotEmpty()) " • $dateStr" else "",
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricCyan
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Surface(
                        color = statusColor.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = apk.installStatusLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onInstallClick,
                enabled = apk.isValidArchive,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (apk.isValidArchive) NeonEmerald else CoralRose.copy(alpha = 0.35f)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("install_apk_button_${apk.id}")
            ) {
                Text(
                    text = if (apk.isValidArchive) "تثبيت" else "تالف",
                    color = if (apk.isValidArchive) Color(0xFF002418) else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}

/**
 * Section 6: Transfer History Screen showing all sent and received files,
 * SHA-256 verification status, saved paths, and transfer speeds.
 */
@Composable
fun TransferHistoryScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onClearHistory: () -> Unit,
    onPlayOrPreviewInApp: (TransferHistoryRecord) -> Unit = {},
    onOpenExternally: (TransferHistoryRecord) -> Unit = {},
    onClosePreview: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = {
        if (uiState.previewingHistoryRecord != null) {
            onClosePreview()
        } else {
            onBack()
        }
    })

    var selectedFilterIndex by remember { mutableIntStateOf(0) }
    val filterLabels = listOf(
        "الكل (${uiState.transferHistory.size})",
        "المكتملة (${uiState.transferHistory.count { it.isCompleted }})",
        "فيديو وصور (${uiState.transferHistory.count { it.isCompleted && (it.isVideoFile || it.isImageFile) }})",
        "غير مكتملة (${uiState.transferHistory.count { !it.isCompleted }})"
    )

    val filteredRecords = remember(uiState.transferHistory, selectedFilterIndex) {
        when (selectedFilterIndex) {
            1 -> uiState.transferHistory.filter { it.isCompleted }
            2 -> uiState.transferHistory.filter { it.isCompleted && (it.isVideoFile || it.isImageFile) }
            3 -> uiState.transferHistory.filter { !it.isCompleted }
            else -> uiState.transferHistory
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    ScreenTopBar(
                        title = "التنزيلات وسجل النقل (${uiState.transferHistory.size})",
                        subtitle = "تشغيل الفيديوهات وعرض الصور المستلمة مباشرة والتحقق SHA-256",
                        accentColor = ElectricCyan,
                        onBack = onBack
                    )
                }
                if (uiState.transferHistory.isNotEmpty()) {
                    IconButton(
                        onClick = onClearHistory,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MidnightCard)
                            .border(1.dp, GlassBorder, CircleShape)
                            .testTag("clear_history_button")
                    ) {
                        Icon(Icons.Filled.DeleteSweep, contentDescription = "مسح السجل", tint = CoralRose)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Chips Row separating Completed, Media (Video/Image), and Incomplete records
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("history_filter_chips_row")
            ) {
                items(filterLabels.size) { index ->
                    val isSelected = selectedFilterIndex == index
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedFilterIndex = index },
                        label = {
                            Text(
                                text = filterLabels[index],
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricCyan.copy(alpha = 0.22f),
                            selectedLabelColor = ElectricCyan,
                            containerColor = MidnightCard,
                            labelColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("history_filter_chip_$index")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (filteredRecords.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, RoundedCornerShape(18.dp))
                        .padding(24.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.History,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (uiState.transferHistory.isEmpty()) {
                                "سجل التنزيلات والنقل فارغ حالياً. ستظهر هنا جميع الملفات والفيديوهات والصور المكتملة مع أزرار التشغيل والعرض المباشر."
                            } else {
                                "لا توجد عناصر تطابق التصفية المحددة حالياً."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("transfer_history_lazy_column")
                ) {
                    items(filteredRecords, key = { it.id }) { record ->
                        HistoryRecordCard(
                            record = record,
                            onPlayOrPreviewInApp = { onPlayOrPreviewInApp(record) },
                            onOpenExternally = { onOpenExternally(record) }
                        )
                    }
                }
            }
        }

        CopyrightFooter()
    }

    // Direct In-App Video Player / Full-Screen Image Viewer Dialog
    uiState.previewingHistoryRecord?.let { previewRecord ->
        HistoryMediaPreviewDialog(
            record = previewRecord,
            onDismiss = onClosePreview,
            onOpenExternally = { onOpenExternally(previewRecord) }
        )
    }
}

@Composable
private fun HistoryRecordCard(
    record: TransferHistoryRecord,
    onPlayOrPreviewInApp: () -> Unit,
    onOpenExternally: () -> Unit
) {
    val context = LocalContext.current
    val isSuccess = record.isCompleted
    val statusColor = if (isSuccess) NeonEmerald else CoralRose
    val timeStr = remember(record.timestampMillis) {
        SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(record.timestampMillis))
    }

    // Memory-safe lazy thumbnail for completed images and videos
    val thumbBitmap by produceState<ImageBitmap?>(initialValue = null, key1 = record.savedPath, key2 = isSuccess) {
        val existing = record.resolveExistingFile()
        if (isSuccess && existing != null && (record.isImageFile || record.isVideoFile)) {
            value = DeviceMediaRepository.getOrLoadThumbnailAsync(
                context = context,
                item = DeviceMediaItem(
                    id = "hist_${record.id}_${existing.lastModified()}",
                    name = existing.name,
                    sizeBytes = existing.length(),
                    category = if (record.isVideoFile) FileCategory.VIDEO else FileCategory.IMAGE,
                    dateModifiedMillis = existing.lastModified(),
                    localFile = existing
                )
            )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MidnightCard)
            .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(12.dp)
            .testTag("history_record_card_${record.id}")
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Thumbnail or Category/Status Icon
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0A1424))
                            .border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .then(
                                if (isSuccess && (record.isVideoFile || record.isImageFile)) {
                                    Modifier.clickable { onPlayOrPreviewInApp() }
                                } else {
                                    Modifier
                                }
                            )
                    ) {
                        val bmp = thumbBitmap
                        if (bmp != null) {
                            Image(
                                bitmap = bmp,
                                contentDescription = record.fileName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            if (record.isVideoFile) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.65f))
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.PlayArrow,
                                        contentDescription = null,
                                        tint = ElectricCyan,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        } else {
                            Icon(
                                imageVector = when {
                                    !isSuccess -> Icons.Filled.ErrorOutline
                                    record.isVideoFile -> Icons.Filled.Movie
                                    record.isImageFile -> Icons.Filled.Image
                                    else -> categoryIcon(record.category)
                                },
                                contentDescription = null,
                                tint = statusColor,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = record.fileName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${record.category.arabicLabel} • ${formatBytesArabic(record.sizeBytes)} • $timeStr",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                Surface(
                    color = statusColor.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(999.dp)
                ) {
                    Text(
                        text = when {
                            !isSuccess -> record.status.arabicLabel
                            record.direction == TransferDirection.SENDING -> "مكتمل • إرسال"
                            else -> "مكتمل • استلام"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "متوسط السرعة: ${formatSpeedArabic(record.averageSpeedBytesPerSec)} • الجهاز: ${record.peerAddress.ifBlank { "محلي" }}",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )

            if (record.sha256Verified || record.sha256Hash.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.VerifiedUser,
                        contentDescription = null,
                        tint = NeonEmerald,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "SHA-256 سليم ومطابق: ${record.sha256Hash.take(16)}...",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        color = NeonEmerald
                    )
                }
            }

            record.savedPath?.let { path ->
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "المسار: $path",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 10.sp,
                    color = ElectricCyan,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            record.errorMessage?.let { err ->
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "السبب: $err",
                    style = MaterialTheme.typography.labelSmall,
                    color = CoralRose
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Direct Media Playback & File Action Buttons (ONLY enabled for verified COMPLETED files)
            if (isSuccess) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (record.isVideoFile) {
                        Button(
                            onClick = onPlayOrPreviewInApp,
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("history_play_video_${record.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = null,
                                tint = Color(0xFF001F29),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "▶ تشغيل الفيديو",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF001F29)
                            )
                        }

                        OutlinedButton(
                            onClick = onOpenExternally,
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(40.dp)
                                .testTag("history_open_external_${record.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.OpenInNew,
                                contentDescription = null,
                                tint = NeonEmerald,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "مشغل خارجي",
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonEmerald,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else if (record.isImageFile) {
                        Button(
                            onClick = onPlayOrPreviewInApp,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("history_view_image_${record.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Visibility,
                                contentDescription = null,
                                tint = Color(0xFF002418),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "عرض الصورة",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF002418)
                            )
                        }

                        OutlinedButton(
                            onClick = onOpenExternally,
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(40.dp)
                                .testTag("history_open_external_${record.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.OpenInNew,
                                contentDescription = null,
                                tint = ElectricCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "فتح بالمعرض",
                                style = MaterialTheme.typography.labelSmall,
                                color = ElectricCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        OutlinedButton(
                            onClick = onOpenExternally,
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("history_open_external_${record.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.OpenInNew,
                                contentDescription = null,
                                tint = ElectricCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "فتح الملف (${record.category.arabicLabel})",
                                style = MaterialTheme.typography.labelMedium,
                                color = ElectricCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            } else {
                Surface(
                    color = CoralRose.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("history_incomplete_badge_${record.id}")
                ) {
                    Text(
                        text = "ملف غير مكتمل (${record.status.arabicLabel}) — لا يمكن تشغيله أو فتحه قبل اكتمال التنزيل والتحقق",
                        style = MaterialTheme.typography.labelSmall,
                        color = CoralRose,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

/**
 * In-App Video Player & Full-Resolution Downsampled Image Viewer Dialog for Completed History Items.
 */
@Composable
fun HistoryMediaPreviewDialog(
    record: TransferHistoryRecord,
    onDismiss: () -> Unit,
    onOpenExternally: () -> Unit
) {
    val existingFile = remember(record.savedPath) { record.resolveExistingFile() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xF2050B14))
                .padding(16.dp)
                .testTag("history_media_preview_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(22.dp))
                    .background(MidnightSurface)
                    .border(1.2.dp, ElectricCyan.copy(alpha = 0.7f), RoundedCornerShape(22.dp))
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (record.isVideoFile) "▶ مشغل الفيديو المباشر" else "معاينة الصورة المستلمة",
                            style = MaterialTheme.typography.labelMedium,
                            color = NeonEmerald,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = record.fileName,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("preview_dialog_file_name")
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MidnightCard)
                            .testTag("close_media_preview_button")
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "إغلاق", tint = CoralRose)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Media Content Area
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black)
                        .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                ) {
                    if (existingFile == null) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ErrorOutline,
                                contentDescription = null,
                                tint = CoralRose,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "الملف غير موجود في المسار المحفوظ (ربما تم نقله أو حذفه من التخزين)",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CoralRose,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else if (record.isVideoFile) {
                        var videoError by remember { mutableStateOf<String?>(null) }
                        if (videoError != null) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(20.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Movie,
                                    contentDescription = null,
                                    tint = ElectricCyan,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = videoError ?: "تعذر تشغيل هذا الترميز داخل المشغل المدمج، يمكنك فتحه بمشغل خارجي",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White,
                                    textAlign = TextAlign.Center
                                )
                            }
                        } else {
                            AndroidView(
                                factory = { ctx ->
                                    VideoView(ctx).apply {
                                        val controller = MediaController(ctx)
                                        controller.setAnchorView(this)
                                        setMediaController(controller)
                                        setVideoURI(Uri.fromFile(existingFile))
                                        setOnPreparedListener { mp ->
                                            mp.isLooping = false
                                            start()
                                        }
                                        setOnErrorListener { _, _, _ ->
                                            videoError = "تعذر تشغيل ترميز الفيديو داخل المشغل المدمج؛ اضغط (فتح بتطبيق خارجي) بالأسفل."
                                            true
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("in_app_video_player_view")
                            )
                        }
                    } else if (record.isImageFile) {
                        val fullImageBitmap by produceState<ImageBitmap?>(initialValue = null, key1 = existingFile.absolutePath) {
                            value = withContext(Dispatchers.IO) {
                                try {
                                    val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                                    BitmapFactory.decodeFile(existingFile.absolutePath, boundsOpts)
                                    val maxDim = 1600
                                    var sampleSize = 1
                                    while ((boundsOpts.outWidth / sampleSize) > maxDim || (boundsOpts.outHeight / sampleSize) > maxDim) {
                                        sampleSize *= 2
                                    }
                                    val decodeOpts = BitmapFactory.Options().apply {
                                        inSampleSize = sampleSize.coerceAtLeast(1)
                                        inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                                    }
                                    BitmapFactory.decodeFile(existingFile.absolutePath, decodeOpts)?.asImageBitmap()
                                } catch (_: Throwable) {
                                    null
                                }
                            }
                        }

                        val bmp = fullImageBitmap
                        if (bmp != null) {
                            Image(
                                bitmap = bmp,
                                contentDescription = record.fileName,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("in_app_image_preview_view")
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = ElectricCyan, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "جاري تحضير الصورة بدقة عالية (${formatBytesArabic(existingFile.length())})...",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "الحجم الفعلي: ${formatBytesArabic(existingFile?.length() ?: record.sizeBytes)} • المسار: ${existingFile?.absolutePath ?: record.savedPath.orEmpty()}",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onOpenExternally,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("preview_dialog_open_external_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.OpenInNew,
                            contentDescription = null,
                            tint = Color(0xFF001F29),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (record.isVideoFile) "فتح بمشغل فيديو خارجي" else "فتح بتطبيق المعرض الخارجي",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF001F29)
                        )
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(44.dp)
                            .testTag("preview_dialog_dismiss_button")
                    ) {
                        Text(
                            text = "إغلاق",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}
